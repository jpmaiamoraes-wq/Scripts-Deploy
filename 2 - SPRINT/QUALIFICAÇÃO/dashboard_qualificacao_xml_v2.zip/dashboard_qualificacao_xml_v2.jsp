<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false"%>
<%@ taglib uri="http://java.sun.com/jstl/core_rt" prefix="c" %>
<%@ taglib prefix="snk" uri="/WEB-INF/tld/sankhyaUtil.tld" %>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <snk:load/>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Qualificação de XML</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" rel="stylesheet">
</head>

<snk:query var="q_resumo_geral">
WITH CAB_BASE AS (
    SELECT
        C.CODEMP,
        C.DTNEG,
        T.CODMODDOC,
        T.NFE,
        T.NFSE,
        T.CTE
    FROM TGFCAB C
    INNER JOIN TGFTOP T
        ON T.CODTIPOPER = C.CODTIPOPER
       AND T.DHALTER = C.DHTIPOPER
    WHERE C.TIPMOV <> 'Z'
      AND (:P_DATA_INI IS NULL OR C.DTNEG >= :P_DATA_INI)
      AND (:P_DATA_FIM IS NULL OR C.DTNEG <= :P_DATA_FIM)
      AND (:P_EMPRESA IS NULL OR C.CODEMP IN (:P_EMPRESA))
),
XML_BASE AS (
    SELECT
        COUNT(*) AS VOLUME_XML,
        SUM(CASE WHEN NVL(TRIM(UPPER(STATUS)), 'P') NOT IN ('E','D') THEN 1 ELSE 0 END) AS XML_PROCESSADO,
        SUM(CASE WHEN TRIM(UPPER(STATUS)) IN ('E','D') THEN 1 ELSE 0 END) AS PENDENCIAS,
        SUM(CASE WHEN TRIM(UPPER(STATUS)) = 'D' THEN 1 ELSE 0 END) AS DUPLICADAS,
        SUM(CASE
            WHEN TRIM(UPPER(STATUS)) = 'E'
             AND NVL(TRIM(UPPER(TIPO)), 'OUTROS') <> 'OUTROS'
            THEN 1 ELSE 0 END) AS ERROS_QUALIFICACAO
    FROM TTKEVT
),
CAB_AGR AS (
    SELECT
        COUNT(*) AS LANCAMENTOS,
        MIN(DTNEG) AS MENOR_DATA,
        MAX(DTNEG) AS MAIOR_DATA,
        TRUNC(MONTHS_BETWEEN(MAX(DTNEG), MIN(DTNEG))) AS QTD_MESES,
        TRUNC(MONTHS_BETWEEN(MAX(DTNEG), MIN(DTNEG)) / 12) AS QTD_ANOS
    FROM CAB_BASE
)
SELECT
    TO_CHAR(NVL(X.VOLUME_XML, 0), 'FM999G999G999G990', 'NLS_NUMERIC_CHARACTERS = '',.''') AS VOLUME_XML_FMT,
    TO_CHAR(NVL(X.XML_PROCESSADO, 0), 'FM999G999G999G990', 'NLS_NUMERIC_CHARACTERS = '',.''') AS XML_PROCESSADO_FMT,
    TO_CHAR(NVL(X.PENDENCIAS, 0), 'FM999G999G999G990', 'NLS_NUMERIC_CHARACTERS = '',.''') AS PENDENCIAS_FMT,
    TO_CHAR(NVL(X.DUPLICADAS, 0), 'FM999G999G999G990', 'NLS_NUMERIC_CHARACTERS = '',.''') AS DUPLICADAS_FMT,
    TO_CHAR(NVL(X.ERROS_QUALIFICACAO, 0), 'FM999G999G999G990', 'NLS_NUMERIC_CHARACTERS = '',.''') AS ERROS_QUALIFICACAO_FMT,
    TO_CHAR(NVL(ROUND((X.XML_PROCESSADO / NULLIF(X.VOLUME_XML, 0)) * 100), 0), 'FM990') AS PERC_PROCESSADO_FMT,
    TO_CHAR(NVL(C.MENOR_DATA, :P_DATA_INI), 'DD-MM-YYYY') AS MENOR_DATA_FMT,
    TO_CHAR(NVL(C.MAIOR_DATA, :P_DATA_FIM), 'DD-MM-YYYY') AS MAIOR_DATA_FMT,
    TO_CHAR(NVL(C.QTD_MESES, 0), 'FM999G999G990', 'NLS_NUMERIC_CHARACTERS = '',.''') AS QTD_MESES_FMT,
    TO_CHAR(NVL(C.QTD_ANOS, 0), 'FM999G990', 'NLS_NUMERIC_CHARACTERS = '',.''') AS QTD_ANOS_FMT,
    NVL(C.QTD_ANOS, 0) || ' ano(s) e ' || MOD(NVL(C.QTD_MESES, 0), 12) || ' mes(es)' AS TEMPO_TOTAL_FMT,
    TO_CHAR(NVL(C.LANCAMENTOS, 0), 'FM999G999G999G990', 'NLS_NUMERIC_CHARACTERS = '',.''') AS LANCAMENTOS_FMT
FROM XML_BASE X
CROSS JOIN CAB_AGR C
</snk:query>

<snk:query var="q_pendencias_mensagem">
WITH AGG AS (
    SELECT
        SUM(CASE WHEN STATUS_EVT = 'D' THEN 1 ELSE 0 END) AS Q_DUPLICADAS,
        SUM(CASE
            WHEN STATUS_EVT = 'E'
             AND TIPO_EVT <> 'OUTROS'
             AND MENSAGEM_TEXTO IS NOT NULL
             AND MENSAGEM_TEXTO LIKE '%Falha ao definir c_digo do produto%'
            THEN 1 ELSE 0 END) AS Q_PRODUTO,
        SUM(CASE
            WHEN STATUS_EVT = 'E'
             AND TIPO_EVT <> 'OUTROS'
             AND MENSAGEM_TEXTO IS NOT NULL
             AND MENSAGEM_TEXTO LIKE '%N_o existem arquivos v_lidos para as empresas cadastradas%'
            THEN 1 ELSE 0 END) AS Q_EMPRESA,
        SUM(CASE
            WHEN STATUS_EVT = 'E'
             AND TIPO_EVT <> 'OUTROS'
             AND MENSAGEM_TEXTO IS NOT NULL
             AND MENSAGEM_TEXTO LIKE '%est_ em um modelo que ainda n_o _ suportado.%'
            THEN 1 ELSE 0 END) AS Q_MODELO,
        SUM(CASE
            WHEN STATUS_EVT = 'E'
             AND TIPO_EVT <> 'OUTROS'
             AND (
                 MENSAGEM_TEXTO IS NULL
                 OR (
                     MENSAGEM_TEXTO NOT LIKE '%Falha ao definir c_digo do produto%'
                     AND MENSAGEM_TEXTO NOT LIKE '%Erro input string%'
                     AND MENSAGEM_TEXTO NOT LIKE '%N_o existem arquivos v_lidos para as empresas cadastradas%'
                     AND MENSAGEM_TEXTO NOT LIKE '%Cancelamento ignorado para a NF-e null: dados obrigat_rios ausentes%'
                     AND MENSAGEM_TEXTO NOT LIKE '%O arquivo XML enviado cont_m anexos um retorno de consulta%'
                     AND MENSAGEM_TEXTO NOT LIKE '%est_ em um modelo que ainda n_o _ suportado.%'
                     AND MENSAGEM_TEXTO NOT LIKE '%N_o foi poss_vel localizar um CFOP no xml importado:%'
                     AND MENSAGEM_TEXTO NOT LIKE '%Nota j_ cadastrada%'
                 )
             )
            THEN 1 ELSE 0 END) AS Q_ERROS,
        SUM(CASE
            WHEN STATUS_EVT = 'E'
             AND TIPO_EVT = 'OUTROS'
            THEN 1 ELSE 0 END) AS Q_OUTROS
    FROM (
        SELECT
            TRIM(UPPER(STATUS)) AS STATUS_EVT,
            NVL(TRIM(UPPER(TIPO)), 'OUTROS') AS TIPO_EVT,
            DBMS_LOB.SUBSTR(MENSAGEM, 4000, 1) AS MENSAGEM_TEXTO
        FROM TTKEVT
        WHERE TRIM(UPPER(STATUS)) IN ('D','E')
    )
)
SELECT
    CATEGORIA,
    CARD_CLASS,
    TO_CHAR(QTD, 'FM999G999G999G990', 'NLS_NUMERIC_CHARACTERS = '',.''') AS QTD_FMT,
    QTD
FROM (
    SELECT 1 AS ORDEM, 'Arquivos duplicados' AS CATEGORIA, 'pend-duplicada' AS CARD_CLASS,
           NVL(Q_DUPLICADAS, 0) AS QTD
    FROM AGG

    UNION ALL

    SELECT 2, 'Falha ao definir codigo do produto', 'pend-produto',
           NVL(Q_PRODUTO, 0)
    FROM AGG

    UNION ALL

    SELECT 3, 'Sem arquivo valido para empresa cadastrada', 'pend-empresa',
           NVL(Q_EMPRESA, 0)
    FROM AGG

    UNION ALL

    SELECT 4, 'Modelo ainda nao suportado', 'pend-modelo',
           NVL(Q_MODELO, 0)
    FROM AGG

    UNION ALL

    SELECT 5, 'Erros de qualificacao', 'pend-erro',
           NVL(Q_ERROS, 0)
    FROM AGG

    UNION ALL

    SELECT 6, 'Outros arquivos com erro', 'pend-outros',
           NVL(Q_OUTROS, 0)
    FROM AGG
)
ORDER BY ORDEM
</snk:query>

<snk:query var="q_erros_configuraveis">
SELECT
    REGEXP_REPLACE(DBMS_LOB.SUBSTR(MENSAGEM, 4000, 1), '[[:cntrl:]]', ' ') AS MENSAGEM_TEXTO,
    COUNT(*) AS QTD
FROM TTKEVT
WHERE TRIM(UPPER(STATUS)) = 'E'
  AND NVL(TRIM(UPPER(TIPO)), 'OUTROS') <> 'OUTROS'
  AND MENSAGEM IS NOT NULL
GROUP BY DBMS_LOB.SUBSTR(MENSAGEM, 4000, 1)
</snk:query>

<snk:query var="q_motivos_illegal_state">
WITH ERROS_EXTRAIDOS AS (
    SELECT
        TRIM(
            REGEXP_SUBSTR(
                TO_CHAR(
                    DBMS_LOB.SUBSTR(
                        MENSAGEM,
                        2000,
                        DBMS_LOB.INSTR(MENSAGEM, 'java.lang.IllegalStateException:')
                    )
                ),
                'java\.lang\.IllegalStateException:\s*(.*)',
                1, 1, 'i', 1
            )
        ) AS MOTIVO_ERRO
    FROM TTKEVT
    WHERE TRIM(UPPER(STATUS)) = 'E'
      AND DBMS_LOB.INSTR(MENSAGEM, 'java.lang.IllegalStateException:') > 0
)
SELECT
    REGEXP_REPLACE(MOTIVO_ERRO, '[[:cntrl:]]', ' ') AS MOTIVO_ERRO,
    COUNT(*) AS QTD
FROM ERROS_EXTRAIDOS
WHERE MOTIVO_ERRO IS NOT NULL
GROUP BY REGEXP_REPLACE(MOTIVO_ERRO, '[[:cntrl:]]', ' ')
ORDER BY QTD DESC
</snk:query>

<snk:query var="q_modelos_nao_suportados">
SELECT
    TIPO,
    EVENTO,
    TO_CHAR(QTD, 'FM999G999G999G990', 'NLS_NUMERIC_CHARACTERS = '',.''') AS QTD_FMT,
    QTD
FROM (
    SELECT
        TIPO_EVT AS TIPO,
        EVENTO_EVT AS EVENTO,
        COUNT(*) AS QTD
    FROM (
        SELECT
            NVL(TRIM(TIPO), 'OUTROS') AS TIPO_EVT,
            NVL(TRIM(EVENTO), 'SEM EVENTO') AS EVENTO_EVT,
            DBMS_LOB.SUBSTR(MENSAGEM, 4000, 1) AS MENSAGEM_TEXTO
        FROM TTKEVT
        WHERE TRIM(UPPER(STATUS)) = 'E'
          AND NVL(TRIM(UPPER(TIPO)), 'OUTROS') <> 'OUTROS'
    )
    WHERE MENSAGEM_TEXTO LIKE '%est_ em um modelo que ainda n_o _ suportado.%'
    GROUP BY TIPO_EVT, EVENTO_EVT
)
ORDER BY QTD DESC, TIPO, EVENTO
</snk:query>

<snk:query var="q_cards_documentos">
WITH DOCS AS (
    SELECT 'NFE' AS TIPO, 'Nota Fiscal Eletrônica' AS TITULO, 'NF-e' AS SIGLA, 'fa-file-invoice' AS ICONE, 1 AS ORDEM FROM DUAL UNION ALL
    SELECT 'NFCE', 'Nota Fiscal de Consumidor Eletrônica', 'NFC-e', 'fa-receipt', 2 FROM DUAL UNION ALL
    SELECT 'CTE', 'Conhecimento de Transporte Eletrônico', 'CT-e', 'fa-truck-fast', 3 FROM DUAL UNION ALL
    SELECT 'CFE', 'Cupom Fiscal Eletrônico', 'CF-e', 'fa-cash-register', 4 FROM DUAL UNION ALL
    SELECT 'NFCOM', 'Nota Fiscal Fatura de Serviço de Comunicação Eletrônica', 'NFCom', 'fa-tower-cell', 5 FROM DUAL UNION ALL
    SELECT 'NFSE', 'Nota Fiscal de Serviços Eletrônica', 'NFS-e', 'fa-file-signature', 6 FROM DUAL UNION ALL
    SELECT 'EFD', 'Escrituração Fiscal Digital', 'EFD', 'fa-file-lines', 7 FROM DUAL UNION ALL
    SELECT 'ESOCIAL', 'Sistema de Escrituração Digital das Obrigações Fiscais', 'eSocial', 'fa-users-gear', 8 FROM DUAL UNION ALL
    SELECT 'OUTROS', 'Outros documentos', 'Outros', 'fa-file-circle-question', 9 FROM DUAL
),
XML_AGR AS (
    SELECT
        CASE
            WHEN TRIM(UPPER(TIPO)) IN ('NFE', 'NF-E') THEN 'NFE'
            WHEN TRIM(UPPER(TIPO)) IN ('NFCE', 'NFC-E') THEN 'NFCE'
            WHEN TRIM(UPPER(TIPO)) IN ('CTE', 'CT-E') THEN 'CTE'
            WHEN TRIM(UPPER(TIPO)) IN ('CFE', 'CF-E') THEN 'CFE'
            WHEN TRIM(UPPER(TIPO)) IN ('NFCOM', 'NF-COM') THEN 'NFCOM'
            WHEN TRIM(UPPER(TIPO)) IN ('NFSE', 'NFS-E') THEN 'NFSE'
            WHEN TRIM(UPPER(TIPO)) = 'EFD' THEN 'EFD'
            WHEN TRIM(UPPER(TIPO)) = 'ESOCIAL' THEN 'ESOCIAL'
            ELSE 'OUTROS'
        END AS TIPO_DOC,
        COUNT(*) AS TOTAL_ARQUIVOS,
        SUM(CASE WHEN NVL(TRIM(UPPER(STATUS)), 'P') NOT IN ('E','D') THEN 1 ELSE 0 END) AS PROCESSADOS,
        SUM(CASE WHEN TRIM(UPPER(STATUS)) IN ('E','D') THEN 1 ELSE 0 END) AS PENDENTES
    FROM TTKEVT
    GROUP BY
        CASE
            WHEN TRIM(UPPER(TIPO)) IN ('NFE', 'NF-E') THEN 'NFE'
            WHEN TRIM(UPPER(TIPO)) IN ('NFCE', 'NFC-E') THEN 'NFCE'
            WHEN TRIM(UPPER(TIPO)) IN ('CTE', 'CT-E') THEN 'CTE'
            WHEN TRIM(UPPER(TIPO)) IN ('CFE', 'CF-E') THEN 'CFE'
            WHEN TRIM(UPPER(TIPO)) IN ('NFCOM', 'NF-COM') THEN 'NFCOM'
            WHEN TRIM(UPPER(TIPO)) IN ('NFSE', 'NFS-E') THEN 'NFSE'
            WHEN TRIM(UPPER(TIPO)) = 'EFD' THEN 'EFD'
            WHEN TRIM(UPPER(TIPO)) = 'ESOCIAL' THEN 'ESOCIAL'
            ELSE 'OUTROS'
        END
),
ERP_AGR AS (
    SELECT
        TIPO_DOC,
        SUM(PROPRIO) AS PROPRIO,
        SUM(TERCEIRO) AS TERCEIRO
    FROM (
        SELECT
            CASE
                WHEN T.CODMODDOC = 55 THEN 'NFE'
                WHEN T.CODMODDOC = 65 THEN 'NFCE'
                WHEN T.CODMODDOC = 59 THEN 'CFE'
                WHEN T.CODMODDOC = 1 THEN 'NFSE'
                WHEN (T.CODMODDOC NOT IN (1,55) AND T.CTE IS NOT NULL) THEN 'CTE'
                WHEN T.CODMODDOC = 62 THEN 'NFCOM'
                ELSE 'OUTROS'
            END AS TIPO_DOC,
            CASE
                WHEN T.CODMODDOC = 55 AND T.NFE IN ('N','D') THEN 1
                WHEN T.CODMODDOC IN (59,65) AND T.NFE IN ('N','D') THEN 1
                WHEN T.CODMODDOC = 1 AND T.NFSE = 'N' THEN 1
                WHEN (T.CODMODDOC NOT IN (1,55) AND T.CTE = 'N') THEN 1
                ELSE 0
            END AS PROPRIO,
            CASE
                WHEN T.CODMODDOC = 55 AND T.NFE = 'T' THEN 1
                WHEN T.CODMODDOC IN (59,65) AND T.NFE = 'T' THEN 1
                WHEN T.CODMODDOC = 1 AND T.NFSE = 'M' THEN 1
                WHEN (T.CODMODDOC NOT IN (1,55) AND T.CTE = 'T') THEN 1
                ELSE 0
            END AS TERCEIRO
        FROM TGFCAB C
        INNER JOIN TSIEMP E ON E.CODEMP = C.CODEMP
        INNER JOIN TGFTOP T
            ON T.CODTIPOPER = C.CODTIPOPER
           AND T.DHALTER = C.DHTIPOPER
        WHERE C.TIPMOV <> 'Z'
          AND (:P_DATA_INI IS NULL OR C.DTNEG >= :P_DATA_INI)
          AND (:P_DATA_FIM IS NULL OR C.DTNEG <= :P_DATA_FIM)
          AND (:P_EMPRESA IS NULL OR C.CODEMP IN (:P_EMPRESA))
    )
    GROUP BY TIPO_DOC
)
SELECT
    D.TIPO,
    D.TITULO,
    D.SIGLA,
    D.ICONE,
    TO_CHAR(NVL(X.TOTAL_ARQUIVOS, 0), 'FM999G999G999G990', 'NLS_NUMERIC_CHARACTERS = '',.''') AS TOTAL_ARQUIVOS_FMT,
    TO_CHAR(NVL(X.PROCESSADOS, 0), 'FM999G999G999G990', 'NLS_NUMERIC_CHARACTERS = '',.''') AS PROCESSADOS_FMT,
    TO_CHAR(NVL(X.PENDENTES, 0), 'FM999G999G990', 'NLS_NUMERIC_CHARACTERS = '',.''') AS PENDENTES_FMT,
    TO_CHAR(NVL(E.PROPRIO, 0), 'FM999G999G999G990', 'NLS_NUMERIC_CHARACTERS = '',.''') AS PROPRIO_FMT,
    TO_CHAR(NVL(E.TERCEIRO, 0), 'FM999G999G999G990', 'NLS_NUMERIC_CHARACTERS = '',.''') AS TERCEIRO_FMT,
    TO_CHAR(NVL(E.PROPRIO, 0) + NVL(E.TERCEIRO, 0), 'FM999G999G999G990', 'NLS_NUMERIC_CHARACTERS = '',.''') AS CLASSIFICADOS_ERP_FMT,
    TO_CHAR(NVL(ROUND((X.PROCESSADOS / NULLIF(X.TOTAL_ARQUIVOS, 0)) * 100), 0), 'FM990') AS PERC_FMT,
    CASE
        WHEN NVL(X.TOTAL_ARQUIVOS, 0) > 0 AND NVL(E.PROPRIO, 0) + NVL(E.TERCEIRO, 0) = 0 THEN 'Arquivo recebido, sem classificação Próprio/Terceiro no ERP para o período filtrado.'
        WHEN NVL(X.PENDENTES, 0) > 0 THEN 'Existem arquivos pendentes no processamento.'
        ELSE 'Arquivos conciliados com lançamentos classificados no ERP.'
    END AS STATUS_CARD
FROM DOCS D
LEFT JOIN XML_AGR X ON X.TIPO_DOC = D.TIPO
LEFT JOIN ERP_AGR E ON E.TIPO_DOC = D.TIPO
ORDER BY D.ORDEM
</snk:query>

<snk:query var="q_tendencia_anual">
WITH BASE AS (
    SELECT
        TO_CHAR(C.DTNEG, 'YYYY') AS ANO,
        COUNT(*) AS QTD
    FROM TGFCAB C
    WHERE C.TIPMOV <> 'Z'
      AND (:P_DATA_INI IS NULL OR C.DTNEG >= :P_DATA_INI)
      AND (:P_DATA_FIM IS NULL OR C.DTNEG <= :P_DATA_FIM)
      AND (:P_EMPRESA IS NULL OR C.CODEMP IN (:P_EMPRESA))
    GROUP BY TO_CHAR(C.DTNEG, 'YYYY')
),
AGR AS (
    SELECT
        ANO,
        QTD,
        MAX(QTD) OVER() AS MAX_QTD
    FROM BASE
)
SELECT
    ANO,
    TO_CHAR(QTD, 'FM999G999G999G990', 'NLS_NUMERIC_CHARACTERS = '',.''') AS QTD_FMT,
    TO_CHAR(NVL(ROUND((QTD / NULLIF(MAX_QTD, 0)) * 100), 0), 'FM990') AS PERC_FMT
FROM AGR
ORDER BY ANO
</snk:query>

<snk:query var="q_empresas">
WITH BASE AS (
    SELECT
        C.CODEMP,
        E.CGC,
        E.RAZAOSOCIAL,
        MIN(C.DTNEG) AS MENOR_DATA,
        MAX(C.DTNEG) AS MAIOR_DATA,
        SUM(CASE WHEN T.CODMODDOC = 55 AND T.NFE IN ('N','D') THEN 1 ELSE 0 END) AS QTD_NFE_PROP,
        SUM(CASE WHEN T.CODMODDOC = 55 AND T.NFE = 'T' THEN 1 ELSE 0 END) AS QTD_NFE_TERC,
        SUM(CASE WHEN T.CODMODDOC = 65 AND T.NFE IN ('N','D') THEN 1 ELSE 0 END) AS QTD_NFCE_PROP,
        SUM(CASE WHEN T.CODMODDOC = 65 AND T.NFE = 'T' THEN 1 ELSE 0 END) AS QTD_NFCE_TERC,
        SUM(CASE WHEN T.CODMODDOC = 1 AND T.NFSE = 'N' THEN 1 ELSE 0 END) AS QTD_NFSE_PROP,
        SUM(CASE WHEN T.CODMODDOC = 1 AND T.NFSE = 'M' THEN 1 ELSE 0 END) AS QTD_NFSE_TERC,
        SUM(CASE WHEN T.CODMODDOC NOT IN (1,55) AND T.CTE = 'N' THEN 1 ELSE 0 END) AS QTD_CTE_PROP,
        SUM(CASE WHEN T.CODMODDOC NOT IN (1,55) AND T.CTE = 'T' THEN 1 ELSE 0 END) AS QTD_CTE_TERC
    FROM TGFCAB C
    INNER JOIN TSIEMP E ON E.CODEMP = C.CODEMP
    INNER JOIN TGFTOP T
        ON T.CODTIPOPER = C.CODTIPOPER
       AND T.DHALTER = C.DHTIPOPER
    WHERE C.TIPMOV <> 'Z'
      AND (:P_DATA_INI IS NULL OR C.DTNEG >= :P_DATA_INI)
      AND (:P_DATA_FIM IS NULL OR C.DTNEG <= :P_DATA_FIM)
      AND (:P_EMPRESA IS NULL OR C.CODEMP IN (:P_EMPRESA))
    GROUP BY C.CODEMP, E.CGC, E.RAZAOSOCIAL
)
SELECT
    CODEMP,
    CGC,
    RAZAOSOCIAL,
    TO_CHAR(MENOR_DATA, 'DD-MM-YYYY') AS MENOR_DATA_FMT,
    TO_CHAR(MAIOR_DATA, 'DD-MM-YYYY') AS MAIOR_DATA_FMT,
    TO_CHAR(QTD_NFE_PROP, 'FM999G999G990', 'NLS_NUMERIC_CHARACTERS = '',.''') AS QTD_NFE_PROP_FMT,
    TO_CHAR(QTD_NFE_TERC, 'FM999G999G990', 'NLS_NUMERIC_CHARACTERS = '',.''') AS QTD_NFE_TERC_FMT,
    TO_CHAR(QTD_NFCE_PROP, 'FM999G999G990', 'NLS_NUMERIC_CHARACTERS = '',.''') AS QTD_NFCE_PROP_FMT,
    TO_CHAR(QTD_NFCE_TERC, 'FM999G999G990', 'NLS_NUMERIC_CHARACTERS = '',.''') AS QTD_NFCE_TERC_FMT,
    TO_CHAR(QTD_NFSE_PROP, 'FM999G999G990', 'NLS_NUMERIC_CHARACTERS = '',.''') AS QTD_NFSE_PROP_FMT,
    TO_CHAR(QTD_NFSE_TERC, 'FM999G999G990', 'NLS_NUMERIC_CHARACTERS = '',.''') AS QTD_NFSE_TERC_FMT,
    TO_CHAR(QTD_CTE_PROP, 'FM999G999G990', 'NLS_NUMERIC_CHARACTERS = '',.''') AS QTD_CTE_PROP_FMT,
    TO_CHAR(QTD_CTE_TERC, 'FM999G999G990', 'NLS_NUMERIC_CHARACTERS = '',.''') AS QTD_CTE_TERC_FMT
FROM BASE
ORDER BY CODEMP
</snk:query>

<body>
<div id="loadingOverlay" class="loading-overlay">
    <div class="loading-box">
        <div class="loading-spinner"></div>
        <div class="loading-text">
            <strong id="loadingTitle">Carregando painel</strong>
            <span id="loadingMessage">Consultando e organizando os dados do Deploy Agent...</span>
        </div>
    </div>
</div>
<style>
    :root {
            --bg-page: #f5f7fa;
            --bg-card: #ffffff;
            --text-title: #303b4f;
            --text-body: #59677d;
            --text-muted: #8a96a8;
            --green: #00896f;
            --green-soft: #e5f4ef;
            --blue: #2f6fed;
            --blue-soft: #eaf2ff;
            --teal: #0f766e;
            --amber: #d97706;
            --amber-soft: #fff5df;
            --red: #dc2626;
            --red-soft: #fff1f2;
            --purple: #6d5bd0;
            --purple-soft: #f0edff;
            --slate-soft: #f4f6f9;
            --border: #e2e8f0;
            --shadow: 0 4px 14px rgba(15, 23, 42, .08);
    }
    * { box-sizing: border-box; }
    html { scroll-behavior: smooth; }
    body {
        margin: 0;
        background: var(--bg-page);
        color: var(--text-title);
        font-family: "Segoe UI", Arial, sans-serif;
    }
    .app-shell {
        min-height: 100vh;
        display: grid;
        grid-template-columns: 238px minmax(0, 1fr);
        transition: grid-template-columns .18s ease;
    }
    body.sidebar-collapsed .app-shell {
        grid-template-columns: 76px minmax(0, 1fr);
    }
    .sidebar {
        position: sticky;
        top: 0;
        height: 100vh;
        background: #ffffff;
        border-right: 1px solid var(--border);
        padding: 28px 16px;
        overflow: hidden auto;
        z-index: 5;
    }
    .sidebar-brand {
        display: flex;
        align-items: center;
        gap: 12px;
        margin-bottom: 30px;
        min-width: 0;
    }
    .side-toggle {
        width: 38px;
        height: 38px;
        border: 0;
        border-radius: 12px;
        background: var(--green-soft);
        color: var(--green);
        display: inline-grid;
        place-items: center;
        cursor: pointer;
        font-size: 16px;
        flex: 0 0 auto;
    }
    .sidebar-title {
        font-size: 16px;
        font-weight: 950;
        color: #111827;
        white-space: nowrap;
    }
    .sidebar-section {
        margin: 0 0 12px 2px;
        color: var(--text-muted);
        font-size: 11px;
        font-weight: 950;
        text-transform: uppercase;
        letter-spacing: .12em;
        white-space: nowrap;
    }
    .side-nav {
        display: grid;
        gap: 6px;
    }
    .side-link {
        min-height: 39px;
        display: flex;
        align-items: center;
        gap: 11px;
        border-radius: 11px;
        padding: 9px 11px;
        color: var(--text-body);
        text-decoration: none;
        font-size: 14px;
        font-weight: 700;
        line-height: 1.1;
        transition: background .16s ease, color .16s ease;
    }
    .side-link i {
        width: 18px;
        text-align: center;
        color: #64748b;
        flex: 0 0 auto;
    }
    .side-link:hover,
    .side-link.active {
        background: var(--green-soft);
        color: var(--green);
    }
    .side-link:hover i,
    .side-link.active i {
        color: var(--green);
    }
    body.sidebar-collapsed .sidebar {
        padding-left: 14px;
        padding-right: 14px;
    }
    body.sidebar-collapsed .sidebar-title,
    body.sidebar-collapsed .sidebar-section,
    body.sidebar-collapsed .side-label {
        display: none;
    }
    body.sidebar-collapsed .sidebar-brand {
        justify-content: center;
    }
    body.sidebar-collapsed .side-link {
        justify-content: center;
        padding-left: 0;
        padding-right: 0;
    }
    .main { padding: 22px 28px 30px; }
    .topbar, .card {
        background: var(--bg-card);
        border: 1px solid var(--border);
        border-radius: 16px;
        box-shadow: var(--shadow);
    }
    .topbar {
        min-height: 72px;
        padding: 16px 18px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 16px;
        margin-bottom: 18px;
    }
    .topbar-left { display: flex; align-items: center; gap: 12px; }
    .title-icon, .doc-icon {
        display: grid;
        place-items: center;
        background: var(--green-soft);
        color: var(--green);
    }
    .title-icon { width: 42px; height: 42px; border-radius: 14px; font-size: 20px; }
    h1 { margin: 0; font-size: 20px; font-weight: 900; }
    .subtitle { margin-top: 4px; font-size: 12px; color: var(--text-muted); }
    .filter-note {
        font-size: 12px;
        color: var(--text-body);
        background: #f8fafc;
        border: 1px solid var(--border);
        border-radius: 999px;
        padding: 8px 12px;
        white-space: nowrap;
    }
    .grid {
        display: grid;
        grid-template-columns: repeat(12, minmax(0, 1fr));
        gap: 18px;
    }
    .span-12 { grid-column: span 12; }
    .span-8 { grid-column: span 8; }
    .span-4 { grid-column: span 4; }
    .card { padding: 18px; min-width: 0; }
    .hero {
        display: grid;
        grid-template-columns: 1.35fr .62fr .75fr .7fr .9fr;
        gap: 14px;
        align-items: stretch;
    }
    .hero-main, .hero-kpi {
        border: 1px solid var(--border);
        border-radius: 14px;
        padding: 16px;
        background: var(--slate-soft);
    }
    .hero-main { background: var(--amber-soft); }
    .hero-kpi.kpi-info { background: var(--blue-soft); border-color: #cfe0ff; }
    .hero-kpi.kpi-warn { background: var(--amber-soft); border-color: #f2d39a; }
    .hero-kpi.kpi-danger { background: var(--red-soft); border-color: #fecaca; }
    .hero-kpi.kpi-success { background: var(--green-soft); border-color: #bfead7; }
    .hero-main { display: flex; align-items: center; gap: 14px; }
    .hero-icon {
        width: 54px;
        height: 54px;
        border-radius: 16px;
        display: grid;
        place-items: center;
        color: var(--green);
        background: var(--green-soft);
        font-size: 24px;
    }
    .label {
        color: var(--text-muted);
        font-size: 11px;
        font-weight: 900;
        text-transform: uppercase;
        letter-spacing: .06em;
    }
    .value {
        margin-top: 6px;
        font-size: 30px;
        line-height: 1;
        font-weight: 950;
    }
    .desc { margin-top: 6px; color: var(--text-body); font-size: 12px; }
    .progress {
        margin-top: 12px;
        height: 10px;
        border-radius: 999px;
        background: #edf2f7;
        overflow: hidden;
        border: 1px solid #dbe4ef;
    }
    .progress span {
        display: block;
        height: 100%;
        border-radius: 999px;
        background: linear-gradient(90deg, #00876c, #10b981);
    }
    .temporal-grid {
        margin-top: 14px;
        display: grid;
        grid-template-columns: 2fr repeat(2, minmax(0, 1fr));
        gap: 10px;
    }
    .temporal-card, .period-card {
        border: 1px solid var(--border);
        border-radius: 14px;
        background: #ffffff;
        padding: 12px 13px;
        min-height: 78px;
    }
    .period-card {
        background: linear-gradient(135deg, #ffffff, #f7fbff);
    }
    .temporal-card strong, .period-card strong {
        display: block;
        margin-top: 7px;
        color: var(--text-title);
        font-size: 19px;
        font-weight: 950;
        line-height: 1.05;
        font-variant-numeric: tabular-nums;
    }
    .period-card strong {
        font-size: 24px;
    }
    .period-card span {
        display: block;
        margin-top: 6px;
        color: var(--text-body);
        font-size: 12px;
        font-weight: 750;
    }
    .temporal-card .label, .period-card .label {
        font-size: 10px;
        letter-spacing: .04em;
    }
    .pending-list {
        display: grid;
        grid-template-columns: repeat(3, minmax(0, 1fr));
        gap: 10px;
    }
    .pending-item {
        border: 1px solid var(--border);
        border-radius: 13px;
        background: #ffffff;
        padding: 12px 13px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
        min-height: 66px;
        cursor: pointer;
        transition: transform .16s ease, box-shadow .16s ease, border-color .16s ease;
    }
    .pending-item:hover {
        transform: translateY(-1px);
        box-shadow: 0 8px 18px rgba(15, 23, 42, .08);
    }
    .pending-item span {
        color: var(--text-body);
        font-size: 12px;
        font-weight: 800;
        line-height: 1.25;
    }
    .pending-item strong {
        color: var(--text-title);
        font-size: 22px;
        font-weight: 950;
        font-variant-numeric: tabular-nums;
        white-space: nowrap;
    }
    .pending-item.pend-duplicada { background: var(--amber-soft); border-color: #f2d39a; }
    .pending-item.pend-produto { background: var(--red-soft); border-color: #fecaca; }
    .pending-item.pend-empresa { background: var(--blue-soft); border-color: #cfe0ff; }
    .pending-item.pend-modelo { background: var(--purple-soft); border-color: #d8d1ff; }
    .pending-item.pend-erro { background: #fff7ed; border-color: #fed7aa; }
    .pending-item.pend-outros { background: #f1f5f9; border-color: #dbe3ee; }
    .pending-item.pend-neutra { background: #ffffff; }
    .pending-item.is-zero {
        background: #f7faf9;
        border-color: #dcebe5;
    }
    .pending-item.is-zero strong {
        color: #64748b;
    }
    .pending-item.has-pendency {
        background: #fff7ed;
        border-color: #fb923c;
        box-shadow: inset 0 0 0 1px rgba(251, 146, 60, .12);
    }
    .pending-item.pend-erro.has-pendency,
    .pending-item.pend-produto.has-pendency {
        background: #fff1f2;
        border-color: #f87171;
    }
    .pending-item.has-pendency strong {
        color: #243047;
    }
    .custom-pending-list {
        margin-top: 10px;
    }
    .pending-detail {
        margin-top: 12px;
        border: 1px solid var(--border);
        border-radius: 14px;
        background: #ffffff;
        overflow: hidden;
    }
    .pending-detail.is-hidden {
        display: none;
    }
    .pending-detail-head {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 10px;
        padding: 11px 13px;
        border-bottom: 1px solid var(--border);
        background: #f8fafc;
    }
    .pending-detail-head strong {
        color: var(--text-title);
        font-size: 13px;
        font-weight: 950;
    }
    .pending-detail-head span {
        color: var(--text-muted);
        font-size: 11px;
        font-weight: 800;
    }
    .pending-detail-row {
        display: grid;
        grid-template-columns: minmax(0, 1fr) 100px;
        gap: 12px;
        padding: 10px 13px;
        border-bottom: 1px solid var(--border);
        color: var(--text-body);
        font-size: 12px;
        line-height: 1.35;
    }
    .pending-detail-row:last-child {
        border-bottom: 0;
    }
    .pending-detail-row strong {
        color: var(--text-title);
        text-align: right;
        font-variant-numeric: tabular-nums;
    }
    .pending-tools {
        display: inline-flex;
        align-items: center;
        gap: 8px;
    }
    .export-actions {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        flex-wrap: wrap;
        justify-content: flex-end;
    }
    .sql-toast {
        position: fixed;
        left: 50%;
        bottom: 22px;
        transform: translateX(-50%) translateY(18px);
        opacity: 0;
        pointer-events: none;
        z-index: 20;
        background: #0f172a;
        color: #ffffff;
        border-radius: 999px;
        padding: 10px 15px;
        font-size: 12px;
        font-weight: 800;
        box-shadow: 0 12px 24px rgba(15, 23, 42, .22);
        transition: opacity .2s ease, transform .2s ease;
    }
    .sql-toast.show {
        opacity: 1;
        transform: translateX(-50%) translateY(0);
    }
    .loading-overlay {
        position: fixed;
        inset: 0;
        z-index: 9999;
        display: flex;
        align-items: center;
        justify-content: center;
        background: rgba(245, 247, 250, .88);
        backdrop-filter: blur(3px);
        transition: opacity .22s ease, visibility .22s ease;
    }
    .loading-overlay.is-hidden {
        opacity: 0;
        visibility: hidden;
        pointer-events: none;
    }
    .loading-box {
        display: flex;
        align-items: center;
        gap: 13px;
        min-width: 280px;
        max-width: min(440px, calc(100vw - 36px));
        padding: 17px 18px;
        border: 1px solid #cde8dd;
        border-radius: 16px;
        background: #ffffff;
        box-shadow: 0 16px 40px rgba(15, 23, 42, .14);
        color: var(--text-title);
    }
    .loading-spinner {
        width: 34px;
        height: 34px;
        border-radius: 999px;
        border: 4px solid #d8f2e8;
        border-top-color: var(--green);
        animation: spin .8s linear infinite;
        flex: 0 0 auto;
    }
    .loading-text strong {
        display: block;
        font-size: 14px;
        font-weight: 950;
    }
    .loading-text span {
        display: block;
        margin-top: 4px;
        color: var(--text-body);
        font-size: 12px;
        font-weight: 700;
        line-height: 1.35;
    }
    @keyframes spin {
        to { transform: rotate(360deg); }
    }
    .config-modal {
        position: fixed;
        inset: 0;
        z-index: 30;
        display: grid;
        place-items: center;
        padding: 22px;
        background: rgba(15, 23, 42, .36);
    }
    .config-modal.is-hidden {
        display: none;
    }
    .config-box {
        width: min(720px, 100%);
        border-radius: 16px;
        background: #ffffff;
        border: 1px solid var(--border);
        box-shadow: 0 22px 45px rgba(15, 23, 42, .24);
        padding: 18px;
    }
    .config-head {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
        margin-bottom: 14px;
    }
    .config-head h3 {
        margin: 0;
        font-size: 16px;
        font-weight: 950;
    }
    .config-grid {
        display: grid;
        grid-template-columns: 1fr 1.4fr auto;
        gap: 10px;
        align-items: end;
    }
    .config-field label {
        display: block;
        margin-bottom: 5px;
        color: var(--text-muted);
        font-size: 10px;
        font-weight: 950;
        text-transform: uppercase;
        letter-spacing: .05em;
    }
    .config-field input {
        width: 100%;
        border: 1px solid var(--border);
        border-radius: 10px;
        padding: 10px 11px;
        color: var(--text-title);
        font: inherit;
        outline: none;
    }
    .config-field input:focus {
        border-color: #9bdcbd;
        box-shadow: 0 0 0 3px rgba(16, 185, 129, .12);
    }
    .config-list {
        margin-top: 14px;
        display: grid;
        gap: 8px;
        max-height: 220px;
        overflow: auto;
    }
    .config-rule {
        border: 1px solid var(--border);
        border-radius: 12px;
        padding: 10px 12px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
        color: var(--text-body);
        font-size: 12px;
    }
    .config-rule strong {
        color: var(--text-title);
        display: block;
        font-size: 13px;
    }
    .config-rule button {
        border: 0;
        background: var(--red-soft);
        color: var(--red);
        border-radius: 999px;
        padding: 6px 9px;
        cursor: pointer;
        font-weight: 900;
    }
    .doc-grid {
        display: grid;
        grid-template-columns: repeat(3, minmax(0, 1fr));
        gap: 14px;
    }
    .timeline-list {
        display: grid;
        gap: 10px;
    }
    .timeline-row {
        display: grid;
        grid-template-columns: 72px minmax(0, 1fr) 110px;
        align-items: center;
        gap: 12px;
    }
    .timeline-year {
        color: var(--text-title);
        font-size: 13px;
        font-weight: 950;
    }
    .timeline-track {
        height: 12px;
        border-radius: 999px;
        overflow: hidden;
        background: #edf2f7;
        border: 1px solid #dbe4ef;
    }
    .timeline-fill {
        height: 100%;
        min-width: 3px;
        border-radius: 999px;
        background: linear-gradient(90deg, #0f766e, #2f6fed);
    }
    .timeline-value {
        color: var(--text-body);
        font-size: 12px;
        font-weight: 900;
        text-align: right;
        font-variant-numeric: tabular-nums;
    }
    .doc-card {
        border: 1px solid var(--border);
        border-radius: 14px;
        padding: 22px;
        background: #ffffff;
        min-height: 210px;
        display: grid;
        grid-template-columns: 104px minmax(0, 1fr);
        gap: 18px;
        align-items: center;
        box-shadow: 0 3px 10px rgba(15, 23, 42, .07);
    }
    .doc-card.has-files {
        background: #ffffff;
    }
    .doc-card.attention {
        background: var(--amber-soft);
        border-color: #f2d39a;
    }
    .doc-logo-area {
        display: grid;
        justify-items: center;
        align-content: center;
        gap: 8px;
        min-width: 0;
    }
    .doc-icon.logo-mark {
        position: relative;
        width: 116px;
        height: 76px;
        border: 0;
        background: transparent;
        color: var(--teal);
        font-size: 36px;
        font-weight: 950;
        line-height: 1;
        letter-spacing: -1px;
        white-space: nowrap;
        display: flex;
        align-items: center;
        justify-content: center;
        overflow: hidden;
        text-shadow: 0 1px 0 rgba(255,255,255,.75);
    }
    .doc-card.type-NFE .logo-mark,
    .doc-card.type-NFCE .logo-mark,
    .doc-card.type-CTE .logo-mark,
    .doc-card.type-NFCOM .logo-mark,
    .doc-card.type-EFD .logo-mark {
        padding-left: 24px;
        justify-content: flex-start;
    }
    .doc-card.type-NFE .logo-mark::before,
    .doc-card.type-NFCE .logo-mark::before,
    .doc-card.type-CTE .logo-mark::before,
    .doc-card.type-NFCOM .logo-mark::before,
    .doc-card.type-EFD .logo-mark::before {
        content: "";
        position: absolute;
        left: 4px;
        top: 7px;
        width: 56px;
        height: 61px;
        background:
            linear-gradient(135deg, rgba(77, 181, 170, .9), rgba(109, 203, 111, .9));
        clip-path: polygon(24% 0, 53% 7%, 73% 1%, 95% 20%, 88% 43%, 100% 64%, 74% 95%, 48% 85%, 29% 99%, 10% 75%, 0 54%, 11% 30%);
        opacity: .82;
        z-index: 0;
    }
    .doc-card.type-NFE .logo-mark::after,
    .doc-card.type-NFCE .logo-mark::after,
    .doc-card.type-CTE .logo-mark::after,
    .doc-card.type-NFCOM .logo-mark::after,
    .doc-card.type-EFD .logo-mark::after {
        content: "";
        position: absolute;
        left: 13px;
        top: 15px;
        width: 39px;
        height: 42px;
        background: rgba(255,255,255,.88);
        clip-path: polygon(21% 0, 54% 5%, 75% 0, 100% 23%, 88% 45%, 96% 65%, 70% 100%, 45% 84%, 20% 96%, 0 70%, 11% 47%, 2% 28%);
        z-index: 0;
    }
    .doc-card .logo-mark span {
        position: relative;
        z-index: 1;
    }
    .doc-card.type-NFE .logo-mark,
    .doc-card.type-NFCE .logo-mark,
    .doc-card.type-NFCOM .logo-mark,
    .doc-card.type-EFD .logo-mark { color: #2486bf; }
    .doc-card.type-CTE .logo-mark { color: #2d91c7; }
    .doc-card.type-CFE .logo-mark {
        color: #111827;
        font-style: italic;
        font-size: 38px;
        letter-spacing: -2px;
    }
    .doc-card.type-NFSE .logo-mark {
        color: #3f8f55;
        font-size: 39px;
        letter-spacing: -2px;
    }
    .doc-card.type-NFSE .logo-mark span::first-letter { color: #8aa23d; }
    .doc-card.type-NFCOM .logo-mark { font-size: 25px; letter-spacing: -2px; }
    .doc-card.type-ESOCIAL .logo-mark {
        color: #1465a8;
        font-size: 30px;
        letter-spacing: -2px;
    }
    .doc-card.type-ESOCIAL .logo-mark::before {
        content: "";
        position: absolute;
        left: 22px;
        top: 9px;
        width: 24px;
        height: 28px;
        border: 4px solid #0ea5a4;
        border-top-color: #f4b000;
        background: rgba(255,255,255,.7);
        transform: skewY(-8deg);
    }
    .doc-card.type-OUTROS .logo-mark {
        color: #64748b;
        font-size: 0;
    }
    .doc-card.type-OUTROS .logo-mark::before {
        content: "\f15b";
        font-family: "Font Awesome 6 Free";
        font-weight: 900;
        font-size: 46px;
        color: #64748b;
    }
    .doc-title { font-size: 14px; font-weight: 850; color: #526176; line-height: 1.25; }
    .source-label {
        display: inline-flex;
        margin-top: 10px;
        color: var(--text-muted);
        font-size: 10px;
        font-weight: 950;
        text-transform: uppercase;
        letter-spacing: .05em;
    }
    .doc-total { margin-top: 4px; font-size: 20px; font-weight: 950; color: var(--teal); display: flex; align-items: center; gap: 8px; }
    .doc-total i { color: var(--teal); font-size: 16px; }
    .doc-total small { font-size: 12px; color: var(--text-muted); font-weight: 800; }
    .erp-box {
        margin-top: 12px;
        border: 1px solid #e1e8f0;
        border-radius: 12px;
        background: rgba(255,255,255,.86);
        overflow: hidden;
    }
    .erp-title {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 8px;
        padding: 8px 10px;
        color: #6b7a90;
        font-size: 10px;
        font-weight: 950;
        text-transform: uppercase;
        letter-spacing: .04em;
        border-bottom: 1px solid #e1e8f0;
    }
    .erp-total {
        color: var(--text-title);
        font-size: 12px;
        letter-spacing: 0;
    }
    .erp-split {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
    }
    .erp-item {
        padding: 9px 10px;
        text-align: center;
    }
    .erp-item + .erp-item { border-left: 1px solid #e1e8f0; }
    .erp-item strong {
        display: block;
        color: var(--text-title);
        font-size: 21px;
        font-weight: 950;
        font-variant-numeric: tabular-nums;
        line-height: 1.05;
    }
    .erp-item span {
        display: block;
        margin-top: 3px;
        color: var(--text-muted);
        font-size: 10px;
        font-weight: 950;
        text-transform: uppercase;
    }
    .status {
        margin-top: 8px;
        color: var(--text-muted);
        font-size: 11px;
        line-height: 1.35;
    }
    .status.warn { color: #a45100; font-weight: 850; }
    .card-head {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
        margin-bottom: 12px;
    }
    .card-title { margin: 0; font-size: 15px; font-weight: 900; }
    .card-title i { color: var(--green); margin-right: 7px; }
    .badge {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        border: 1px solid #c7ecd8;
        background: var(--green-soft);
        color: var(--green);
        border-radius: 999px;
        padding: 6px 10px;
        font-size: 11px;
        font-weight: 900;
        white-space: nowrap;
    }
    .toggle-button {
        border: 1px solid #c7ecd8;
        background: var(--green-soft);
        color: var(--green);
        border-radius: 999px;
        padding: 8px 12px;
        font-size: 11px;
        font-weight: 900;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 7px;
        white-space: nowrap;
        transition: background .16s ease, border-color .16s ease, transform .16s ease;
    }
    .toggle-button:hover {
        background: #d8f5e7;
        border-color: #a7e6c6;
        transform: translateY(-1px);
    }
    .company-detail-body {
        margin-top: 12px;
    }
    .company-detail-body.is-collapsed {
        display: none;
    }
    .table-wrapper {
        max-height: 430px;
        overflow: auto;
        border: 1px solid var(--border);
        border-radius: 14px;
    }
    .data-table {
        width: 100%;
        border-collapse: collapse;
        table-layout: fixed;
        font-size: 13px;
    }
    .data-table th {
        position: sticky;
        top: 0;
        z-index: 1;
        background: #f8fafc;
        color: var(--text-muted);
        text-align: left;
        padding: 11px 12px;
        border-bottom: 1px solid var(--border);
        font-size: 11px;
        letter-spacing: .05em;
        text-transform: uppercase;
        white-space: nowrap;
    }
    .data-table td {
        padding: 11px 12px;
        border-bottom: 1px solid var(--border);
        color: var(--text-body);
        vertical-align: middle;
    }
    .align-right { text-align: right; font-variant-numeric: tabular-nums; }
    .align-center { text-align: center; }
    .empresa { width: 82px; }
    .cnpj { width: 150px; }
    .data { width: 112px; }
    .num { width: 112px; }
    @media (max-width: 1200px) {
        .app-shell { grid-template-columns: 1fr; }
        body.sidebar-collapsed .app-shell { grid-template-columns: 1fr; }
        .sidebar {
            position: relative;
            height: auto;
            padding: 14px 18px;
            border-right: 0;
            border-bottom: 1px solid var(--border);
        }
        .sidebar-brand { margin-bottom: 12px; }
        .side-nav {
            grid-template-columns: repeat(4, minmax(0, 1fr));
        }
        body.sidebar-collapsed .sidebar-title,
        body.sidebar-collapsed .sidebar-section,
        body.sidebar-collapsed .side-label {
            display: inline;
        }
        .hero { grid-template-columns: 1fr; }
        .temporal-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
        .pending-list { grid-template-columns: 1fr; }
        .doc-grid { grid-template-columns: 1fr; }
        .span-8, .span-4 { grid-column: span 12; }
        .topbar { align-items: flex-start; flex-direction: column; }
        .filter-note { white-space: normal; }
    }
</style>

<div class="app-shell">
<aside class="sidebar">
    <div class="sidebar-brand">
        <button type="button" class="side-toggle" onclick="toggleSidebar()" title="Expandir ou recolher menu">
            <i class="fa-solid fa-bars"></i>
        </button>
        <div class="sidebar-title">Menu Inicial</div>
    </div>
    <div class="sidebar-section">Dashboard</div>
    <nav class="side-nav">
        <a class="side-link active" href="#sec-resumo"><i class="fa-solid fa-house"></i><span class="side-label">Resumo</span></a>
        <a class="side-link" href="#sec-empresas"><i class="fa-solid fa-building"></i><span class="side-label">Empresas</span></a>
        <a class="side-link" href="#sec-pendencias"><i class="fa-solid fa-triangle-exclamation"></i><span class="side-label">Pendências</span></a>
        <a class="side-link" href="#sec-documentos"><i class="fa-solid fa-file-lines"></i><span class="side-label">Documentos</span></a>
    </nav>
</aside>

<main class="main">
    <section class="topbar" id="sec-resumo">
        <div class="topbar-left">
            <div class="title-icon"><i class="fa-solid fa-file-shield"></i></div>
            <div>
                <h1>Qualificação de XML</h1>
                <div class="subtitle">Qualificação dos arquivos importados via Deploy Agent</div>
            </div>
        </div>
        <div class="filter-note">Empresa e período refinam a classificação fiscal após a importação</div>
    </section>

    <section class="grid">
        <c:forEach items="${q_resumo_geral.rows}" var="res">
            <article class="card span-12 hero">
                <div class="hero-main">
                    <div class="hero-icon"><i class="fa-solid fa-folder-arrow-up"></i></div>
                    <div style="min-width:0; width:100%;">
                        <div class="label">Processamento de arquivos enviados</div>
                        <div class="value">${res.XML_PROCESSADO_FMT} <span style="font-size:18px;color:var(--text-body);font-weight:700;">de ${res.VOLUME_XML_FMT}</span></div>
                        <div class="desc">Arquivos processados pelo Deploy Agent</div>
                        <div class="progress"><span style="width:${res.PERC_PROCESSADO_FMT}%;"></span></div>
                    </div>
                </div>
                <div class="hero-kpi kpi-success">
                    <div class="label">Sucesso Geral</div>
                    <div class="value">${res.PERC_PROCESSADO_FMT}%</div>
                    <div class="desc">Eficiência da importação</div>
                </div>
                <div class="hero-kpi kpi-danger">
                    <div class="label">Pendências</div>
                    <div class="value">${res.ERROS_QUALIFICACAO_FMT}</div>
                    <div class="desc">Erros de qualificação pelo filtro atual</div>
                </div>
                <div class="hero-kpi kpi-warn">
                    <div class="label">Duplicadas</div>
                    <div class="value">${res.DUPLICADAS_FMT}</div>
                    <div class="desc">Arquivos com status duplicado</div>
                </div>
                <div class="hero-kpi kpi-info">
                    <div class="label">Lançamentos no ERP</div>
                    <div class="value">${res.LANCAMENTOS_FMT}</div>
                    <div class="desc">${res.MENOR_DATA_FMT} até ${res.MAIOR_DATA_FMT}</div>
                </div>
                <div class="temporal-grid" style="grid-column: 1 / -1;">
                    <div class="period-card">
                        <div class="label">Período dos Dados Legados</div>
                        <strong>${res.TEMPO_TOTAL_FMT}</strong>
                        <span>${res.MENOR_DATA_FMT} até ${res.MAIOR_DATA_FMT}</span>
                    </div>
                    <div class="temporal-card">
                        <div class="label">Volume XML</div>
                        <strong>${res.VOLUME_XML_FMT}</strong>
                    </div>
                    <div class="temporal-card">
                        <div class="label">XML Processado</div>
                        <strong>${res.XML_PROCESSADO_FMT}</strong>
                    </div>
                </div>
            </article>
        </c:forEach>

        <article class="card span-12 company-detail-card" id="sec-empresas">
            <div class="card-head">
                <h2 class="card-title"><i class="fa-solid fa-building"></i> Detalhamento por empresa</h2>
                <div class="export-actions">
                    <button type="button" class="toggle-button" onclick="exportCompanyDetail('csv')" title="Exportar detalhamento por empresa em CSV">
                        <i class="fa-solid fa-file-csv"></i>
                        <span>CSV</span>
                    </button>
                    <button type="button" class="toggle-button" onclick="exportCompanyDetail('xls')" title="Exportar detalhamento por empresa em XLS">
                        <i class="fa-solid fa-file-excel"></i>
                        <span>XLS</span>
                    </button>
                    <button type="button" class="toggle-button" id="companyDetailToggle" onclick="toggleCompanyDetail()">
                        <i class="fa-solid fa-chevron-down"></i>
                        <span>Mostrar detalhamento</span>
                    </button>
                </div>
            </div>
            <div class="company-detail-body is-collapsed" id="companyDetailBody">
                <div class="table-wrapper">
                    <table class="data-table" id="companyDetailTable">
                        <thead>
                            <tr>
                                <th class="empresa align-center">Empresa</th>
                                <th class="cnpj">CNPJ/CPF</th>
                                <th>Razão Social</th>
                                <th class="data align-center">Menor Data</th>
                                <th class="data align-center">Maior Data</th>
                                <th class="num align-right">NF-e Própria</th>
                                <th class="num align-right">NF-e Terc.</th>
                                <th class="num align-right">NFC-e Própria</th>
                                <th class="num align-right">NFC-e Terc.</th>
                                <th class="num align-right">NFS-e Própria</th>
                                <th class="num align-right">NFS-e Terc.</th>
                                <th class="num align-right">CT-e Próprio</th>
                                <th class="num align-right">CT-e Terc.</th>
                            </tr>
                        </thead>
                        <tbody>
                            <c:forEach items="${q_empresas.rows}" var="emp">
                                <tr>
                                    <td class="align-center">${emp.CODEMP}</td>
                                    <td>${emp.CGC}</td>
                                    <td><c:out value="${emp.RAZAOSOCIAL}"/></td>
                                    <td class="align-center">${emp.MENOR_DATA_FMT}</td>
                                    <td class="align-center">${emp.MAIOR_DATA_FMT}</td>
                                    <td class="align-right">${emp.QTD_NFE_PROP_FMT}</td>
                                    <td class="align-right">${emp.QTD_NFE_TERC_FMT}</td>
                                    <td class="align-right">${emp.QTD_NFCE_PROP_FMT}</td>
                                    <td class="align-right">${emp.QTD_NFCE_TERC_FMT}</td>
                                    <td class="align-right">${emp.QTD_NFSE_PROP_FMT}</td>
                                    <td class="align-right">${emp.QTD_NFSE_TERC_FMT}</td>
                                    <td class="align-right">${emp.QTD_CTE_PROP_FMT}</td>
                                    <td class="align-right">${emp.QTD_CTE_TERC_FMT}</td>
                                </tr>
                            </c:forEach>
                        </tbody>
                    </table>
                </div>
            </div>
        </article>

        <article class="card span-12" id="sec-pendencias">
            <div class="card-head">
                <h2 class="card-title"><i class="fa-solid fa-triangle-exclamation"></i> Pendências por mensagem</h2>
                <div class="pending-tools">
                    <button type="button" class="toggle-button" id="pendingDetailToggleButton" onclick="togglePendingDetail()">
                        <i class="fa-solid fa-chevron-down"></i>
                        <span>Mostrar detalhe</span>
                    </button>
                    <button type="button" class="toggle-button" onclick="openPendencyConfig()">
                        <i class="fa-solid fa-gear"></i>
                        <span>Configurar pendências</span>
                    </button>
                    <span class="badge">Status E/D no TTKEVT</span>
                </div>
            </div>
            <div class="pending-list">
                <c:forEach items="${q_pendencias_mensagem.rows}" var="pend">
                    <div class="pending-item ${pend.CARD_CLASS} ${pend.QTD > 0 ? 'has-pendency' : 'is-zero'}" onclick="handlePendingCardClick('${pend.CARD_CLASS}')" title="Clique para copiar a consulta deste indicador">
                        <span>${pend.CATEGORIA}</span>
                        <strong>${pend.QTD_FMT}</strong>
                    </div>
                </c:forEach>
            </div>
            <div class="pending-list custom-pending-list" id="customPendingList"></div>
            <div class="pending-detail is-hidden" id="pendingDetail">
                <div class="pending-detail-head">
                    <strong id="pendingDetailTitle">Detalhamento</strong>
                    <div class="pending-tools">
                        <span id="pendingDetailHint">Mensagens agrupadas</span>
                        <button type="button" class="toggle-button" onclick="hidePendingDetail()">
                            <i class="fa-solid fa-chevron-up"></i>
                            <span>Ocultar detalhe</span>
                        </button>
                    </div>
                </div>
                <div id="pendingDetailRows"></div>
            </div>
        </article>

        <article class="card span-12">
            <div class="card-head">
                <h2 class="card-title"><i class="fa-solid fa-chart-line"></i> Linha do tempo dos dados</h2>
                <span class="badge">Volume por ano</span>
            </div>
            <div class="timeline-list">
                <c:forEach items="${q_tendencia_anual.rows}" var="ano">
                    <div class="timeline-row">
                        <div class="timeline-year">${ano.ANO}</div>
                        <div class="timeline-track">
                            <div class="timeline-fill" style="width:${ano.PERC_FMT}%;"></div>
                        </div>
                        <div class="timeline-value">${ano.QTD_FMT}</div>
                    </div>
                </c:forEach>
            </div>
        </article>

        <article class="card span-12" id="sec-documentos">
            <div class="doc-grid">
                <c:forEach items="${q_cards_documentos.rows}" var="doc">
                    <div class="doc-card type-${doc.TIPO} ${doc.TOTAL_ARQUIVOS_FMT != '0' ? 'has-files' : ''} ${doc.TIPO == 'CTE' && doc.TOTAL_ARQUIVOS_FMT != '0' ? 'attention' : ''}">
                        <div class="doc-logo-area">
                            <div class="doc-icon logo-mark"><span>${doc.SIGLA}</span></div>
                        </div>
                        <div>
                            <div class="doc-title">${doc.TITULO}</div>
                            <span class="source-label">Arquivos importados via Deploy Agent</span>
                            <div class="doc-total"><i class="fa-solid fa-circle-check"></i>${doc.PROCESSADOS_FMT} <small>processados</small></div>
                            <div class="progress"><span style="width:${doc.PERC_FMT}%;"></span></div>
                            <div class="erp-box">
                                <div class="erp-title">
                                    <span>Classificação fiscal após importação</span>
                                    <span class="erp-total">${doc.CLASSIFICADOS_ERP_FMT}</span>
                                </div>
                                <div class="erp-split">
                                    <div class="erp-item">
                                        <strong>${doc.PROPRIO_FMT}</strong>
                                        <span>Próprio</span>
                                    </div>
                                    <div class="erp-item">
                                        <strong>${doc.TERCEIRO_FMT}</strong>
                                        <span>Terceiro</span>
                                    </div>
                                </div>
                            </div>
                            <div class="status ${doc.TOTAL_ARQUIVOS_FMT != '0' && doc.PROPRIO_FMT == '0' && doc.TERCEIRO_FMT == '0' ? 'warn' : ''}">
                                ${doc.STATUS_CARD}
                            </div>
                        </div>
                    </div>
                </c:forEach>
            </div>
        </article>

    </section>
</main>
</div>
<div id="sqlToast" class="sql-toast">Consulta copiada para usar no DBExplorer</div>
<div id="configurableMessageSource" style="display:none;">
    <c:forEach items="${q_erros_configuraveis.rows}" var="msg">
        <div class="msg-row" data-qtd="${msg.QTD}"><c:out value="${msg.MENSAGEM_TEXTO}"/></div>
    </c:forEach>
</div>
<div id="illegalStateReasonSource" style="display:none;">
    <c:forEach items="${q_motivos_illegal_state.rows}" var="motivo">
        <div class="reason-row" data-qtd="${motivo.QTD}"><c:out value="${motivo.MOTIVO_ERRO}"/></div>
    </c:forEach>
</div>
<div id="unsupportedModelSource" style="display:none;">
    <c:forEach items="${q_modelos_nao_suportados.rows}" var="modelo">
        <div class="model-row" data-qtd="${modelo.QTD}">
            <span class="model-tipo"><c:out value="${modelo.TIPO}"/></span>
            <span class="model-evento"><c:out value="${modelo.EVENTO}"/></span>
        </div>
    </c:forEach>
</div>
<div id="pendencyConfigModal" class="config-modal is-hidden">
    <div class="config-box">
        <div class="config-head">
            <h3>Configurar pendências</h3>
            <button type="button" class="toggle-button" onclick="closePendencyConfig()">
                <i class="fa-solid fa-xmark"></i>
                <span>Fechar</span>
            </button>
        </div>
        <div class="config-grid">
            <div class="config-field">
                <label for="ruleName">Nome do card</label>
                <input id="ruleName" type="text" placeholder="Ex.: Emitente nao cadastrado">
            </div>
            <div class="config-field">
                <label for="rulePattern">Trecho da mensagem</label>
                <input id="rulePattern" type="text" placeholder="Ex.: emitente nao cadastrado">
            </div>
            <button type="button" class="toggle-button" onclick="savePendencyRule()">
                <i class="fa-solid fa-plus"></i>
                <span>Adicionar</span>
            </button>
        </div>
        <div class="config-list" id="pendencyRuleList"></div>
    </div>
</div>
<script>
    const configurableMessages = Array.prototype.map.call(
        document.querySelectorAll('#configurableMessageSource .msg-row'),
        function (row) {
            return {
                text: row.textContent || '',
                qtd: Number(row.getAttribute('data-qtd') || 0)
            };
        }
    );

    const illegalStateReasons = Array.prototype.map.call(
        document.querySelectorAll('#illegalStateReasonSource .reason-row'),
        function (row) {
            return {
                text: row.textContent || '',
                qtd: Number(row.getAttribute('data-qtd') || 0)
            };
        }
    );

    const unsupportedModelRows = Array.prototype.map.call(
        document.querySelectorAll('#unsupportedModelSource .model-row'),
        function (row) {
            const tipo = row.querySelector('.model-tipo');
            const evento = row.querySelector('.model-evento');
            return {
                tipo: tipo ? tipo.textContent : 'OUTROS',
                evento: evento ? evento.textContent : 'SEM EVENTO',
                qtd: Number(row.getAttribute('data-qtd') || 0)
            };
        }
    );

    const pendingSqlMap = {
        'pend-duplicada': "SELECT COUNT(*) AS QTD_DUPLICADAS FROM TTKEVT WHERE TRIM(UPPER(STATUS)) = 'D'",
        'pend-produto': `WITH ERROS_EXTRAIDOS AS (
    SELECT
        TRIM(
            REGEXP_SUBSTR(
                TO_CHAR(
                    DBMS_LOB.SUBSTR(
                        MENSAGEM,
                        2000,
                        DBMS_LOB.INSTR(MENSAGEM, 'java.lang.IllegalStateException:')
                    )
                ),
                'java\\.lang\\.IllegalStateException:\\s*(.*)',
                1, 1, 'i', 1
            )
        ) AS MOTIVO_ERRO
    FROM TTKEVT
    WHERE TRIM(UPPER(STATUS)) = 'E'
      AND NVL(TRIM(UPPER(TIPO)), 'OUTROS') <> 'OUTROS'
      AND DBMS_LOB.INSTR(MENSAGEM, 'java.lang.IllegalStateException:') > 0
)
SELECT
    MOTIVO_ERRO,
    COUNT(*) AS QTD
FROM ERROS_EXTRAIDOS
WHERE MOTIVO_ERRO LIKE '%Falha ao definir c_digo do produto%'
GROUP BY MOTIVO_ERRO
ORDER BY QTD DESC`,
        'pend-empresa': `WITH BASE AS (
    SELECT DBMS_LOB.SUBSTR(MENSAGEM, 4000, 1) AS MENSAGEM_TEXTO
    FROM TTKEVT
    WHERE TRIM(UPPER(STATUS)) = 'E'
      AND NVL(TRIM(UPPER(TIPO)), 'OUTROS') <> 'OUTROS'
)
SELECT COUNT(*) AS QTD
FROM BASE
WHERE MENSAGEM_TEXTO LIKE '%N_o existem arquivos v_lidos para as empresas cadastradas%'`,
        'pend-modelo': `WITH BASE AS (
    SELECT
        NVL(TRIM(TIPO), 'OUTROS') AS TIPO,
        NVL(TRIM(EVENTO), 'SEM EVENTO') AS EVENTO,
        DBMS_LOB.SUBSTR(MENSAGEM, 4000, 1) AS MENSAGEM_TEXTO
    FROM TTKEVT
    WHERE TRIM(UPPER(STATUS)) = 'E'
      AND NVL(TRIM(UPPER(TIPO)), 'OUTROS') <> 'OUTROS'
)
SELECT
    TIPO,
    EVENTO,
    COUNT(*) AS QTD
FROM BASE
WHERE MENSAGEM_TEXTO LIKE '%est_ em um modelo que ainda n_o _ suportado.%'
GROUP BY TIPO, EVENTO
ORDER BY QTD DESC, TIPO, EVENTO`,
        'pend-erro': `WITH BASE AS (
    SELECT
        TIPO,
        DBMS_LOB.SUBSTR(MENSAGEM, 4000, 1) AS MENSAGEM_TEXTO
    FROM TTKEVT
    WHERE TRIM(UPPER(STATUS)) = 'E'
      AND NVL(TRIM(UPPER(TIPO)), 'OUTROS') <> 'OUTROS'
)
SELECT
    TIPO,
    MENSAGEM_TEXTO,
    COUNT(*) AS QTD
FROM BASE
WHERE MENSAGEM_TEXTO IS NULL
   OR (
       MENSAGEM_TEXTO NOT LIKE '%Falha ao definir c_digo do produto%'
       AND MENSAGEM_TEXTO NOT LIKE '%Erro input string%'
       AND MENSAGEM_TEXTO NOT LIKE '%N_o existem arquivos v_lidos para as empresas cadastradas%'
       AND MENSAGEM_TEXTO NOT LIKE '%Cancelamento ignorado para a NF-e null: dados obrigat_rios ausentes%'
       AND MENSAGEM_TEXTO NOT LIKE '%O arquivo XML enviado cont_m anexos um retorno de consulta%'
       AND MENSAGEM_TEXTO NOT LIKE '%est_ em um modelo que ainda n_o _ suportado.%'
       AND MENSAGEM_TEXTO NOT LIKE '%N_o foi poss_vel localizar um CFOP no xml importado:%'
       AND MENSAGEM_TEXTO NOT LIKE '%Nota j_ cadastrada%'
   )
GROUP BY TIPO, MENSAGEM_TEXTO
ORDER BY QTD DESC`,
        'pend-outros': `SELECT
    TIPO,
    DBMS_LOB.SUBSTR(MENSAGEM, 4000, 1) AS MENSAGEM_TEXTO,
    COUNT(*) AS QTD
FROM TTKEVT
WHERE TRIM(UPPER(STATUS)) = 'E'
  AND NVL(TRIM(UPPER(TIPO)), 'OUTROS') = 'OUTROS'
GROUP BY TIPO, DBMS_LOB.SUBSTR(MENSAGEM, 4000, 1)
ORDER BY QTD DESC`
    };

    function showLoading(title, message) {
        const overlay = document.getElementById('loadingOverlay');
        const titleEl = document.getElementById('loadingTitle');
        const messageEl = document.getElementById('loadingMessage');
        if (!overlay) return;
        if (titleEl && title) titleEl.textContent = title;
        if (messageEl && message) messageEl.textContent = message;
        overlay.classList.remove('is-hidden');
    }

    function hideLoading(delay) {
        const overlay = document.getElementById('loadingOverlay');
        if (!overlay) return;
        window.clearTimeout(window.__loadingTimer);
        window.__loadingTimer = window.setTimeout(function () {
            overlay.classList.add('is-hidden');
        }, Number(delay || 0));
    }

    window.addEventListener('load', function () {
        hideLoading(250);
    });

    window.setTimeout(function () {
        hideLoading(0);
    }, 12000);

    function showSqlToast(message) {
        const toast = document.getElementById('sqlToast');
        if (!toast) return;
        toast.textContent = message;
        toast.classList.add('show');
        window.clearTimeout(window.__sqlToastTimer);
        window.__sqlToastTimer = window.setTimeout(() => toast.classList.remove('show'), 2800);
    }

    function toggleSidebar() {
        document.body.classList.toggle('sidebar-collapsed');
    }

    document.querySelectorAll('.side-link').forEach(function (link) {
        link.addEventListener('click', function () {
            document.querySelectorAll('.side-link').forEach(function (item) {
                item.classList.remove('active');
            });
            link.classList.add('active');
        });
    });

    const pendencyRulesKey = 'qualificacaoXml.customPendencies';
    const defaultIgnoredErrorPatterns = [
        'falha ao definir codigo do produto',
        'falha ao definir c_digo do produto',
        'erro input string',
        'nao existem arquivos validos para as empresas cadastradas',
        'n_o existem arquivos v_lidos para as empresas cadastradas',
        'cancelamento ignorado para a nf-e null: dados obrigatorios ausentes',
        'cancelamento ignorado para a nf-e null: dados obrigat_rios ausentes',
        'o arquivo xml enviado contem anexos um retorno de consulta',
        'o arquivo xml enviado cont_m anexos um retorno de consulta',
        'esta em um modelo que ainda nao e suportado',
        'est_ em um modelo que ainda n_o _ suportado',
        'nao foi possivel localizar um cfop no xml importado',
        'n_o foi poss_vel localizar um cfop no xml importado',
        'nota ja cadastrada',
        'nota j cadastrada',
        'nota j_ cadastrada',
        'nota j? cadastrada'
    ];
    const pendingDetailFilters = {
        'pend-produto': {
            title: 'Falha ao definir codigo do produto',
            pattern: 'falha ao definir codigo do produto',
            reasonPattern: 'falha ao definir codigo do produto',
            ignoreDefault: false
        },
        'pend-empresa': {
            title: 'Sem arquivo valido para empresa cadastrada',
            pattern: 'n_o existem arquivos v_lidos para as empresas cadastradas',
            reasonPattern: 'nao existem arquivos validos para as empresas cadastradas',
            ignoreDefault: false
        },
        'pend-modelo': {
            title: 'Modelo ainda nao suportado',
            pattern: 'est_ em um modelo que ainda n_o _ suportado',
            reasonPattern: 'esta em um modelo que ainda nao e suportado',
            ignoreDefault: false
        },
        'pend-erro': {
            title: 'Erros de qualificacao',
            residual: true
        }
    };

    function normalizeText(value) {
        return String(value || '')
            .normalize('NFD')
            .replace(/[\u0300-\u036f]/g, '')
            .replace(/[?]/g, '_')
            .toLowerCase();
    }

    function matchesPattern(row, pattern) {
        if (!row.norm) {
            row.norm = normalizeText(row.text);
        }
        return row.norm.indexOf(normalizeText(pattern)) >= 0;
    }

    function matchesAnyPattern(row, patterns) {
        return patterns.some(function (pattern) {
            return matchesPattern(row, pattern);
        });
    }

    function getExtractedReasonRows(pattern) {
        return illegalStateReasons
            .filter(function (row) {
                return matchesPattern(row, pattern);
            })
            .sort(function (a, b) { return Number(b.qtd || 0) - Number(a.qtd || 0); });
    }

    function ruleMatchesIgnoredPattern(rule) {
        const rulePattern = normalizeText(rule.pattern);
        return defaultIgnoredErrorPatterns.some(function (ignored) {
            const normalizedIgnored = normalizeText(ignored);
            return normalizedIgnored.indexOf(rulePattern) >= 0 || rulePattern.indexOf(normalizedIgnored) >= 0;
        });
    }

    let residualMessagesCache = null;
    let residualMessagesCacheKey = '';

    function getResidualMessages(excludedRules) {
        const rules = excludedRules || getPendencyRules();
        const cacheKey = JSON.stringify(rules);
        if (!excludedRules && residualMessagesCache && residualMessagesCacheKey === cacheKey) {
            return residualMessagesCache;
        }
        const residual = configurableMessages.filter(function (row) {
            if (matchesAnyPattern(row, defaultIgnoredErrorPatterns)) {
                return false;
            }
            return !rules.some(function (rule) {
                if (ruleMatchesIgnoredPattern(rule)) return false;
                return matchesPattern(row, rule.pattern);
            });
        });
        if (!excludedRules) {
            residualMessagesCache = residual;
            residualMessagesCacheKey = cacheKey;
        }
        return residual;
    }

    function sumRows(rows) {
        return rows.reduce(function (total, row) {
            return total + Number(row.qtd || 0);
        }, 0);
    }

    function getPendencyRules() {
        try {
            return JSON.parse(localStorage.getItem(pendencyRulesKey) || '[]');
        } catch (error) {
            return [];
        }
    }

    function setPendencyRules(rules) {
        localStorage.setItem(pendencyRulesKey, JSON.stringify(rules));
    }

    function openPendencyConfig() {
        renderPendencyRuleList();
        const modal = document.getElementById('pendencyConfigModal');
        if (modal) modal.classList.remove('is-hidden');
    }

    function closePendencyConfig() {
        const modal = document.getElementById('pendencyConfigModal');
        if (modal) modal.classList.add('is-hidden');
    }

    function savePendencyRule() {
        const nameInput = document.getElementById('ruleName');
        const patternInput = document.getElementById('rulePattern');
        const name = nameInput ? nameInput.value.trim() : '';
        const pattern = patternInput ? patternInput.value.trim() : '';
        if (!name || !pattern) {
            showSqlToast('Informe nome e trecho da mensagem');
            return;
        }

        const rules = getPendencyRules();
        rules.push({ id: Date.now(), name: name, pattern: pattern });
        setPendencyRules(rules);
        if (nameInput) nameInput.value = '';
        if (patternInput) patternInput.value = '';
        renderPendencyRuleList();
        renderCustomPendencies();
        residualMessagesCache = null;
        updateResidualErrorCard();
    }

    function deletePendencyRule(id) {
        const rules = getPendencyRules().filter(function (rule) {
            return String(rule.id) !== String(id);
        });
        setPendencyRules(rules);
        renderPendencyRuleList();
        renderCustomPendencies();
        residualMessagesCache = null;
        updateResidualErrorCard();
    }

    function renderPendencyRuleList() {
        const list = document.getElementById('pendencyRuleList');
        if (!list) return;
        const rules = getPendencyRules();
        if (!rules.length) {
            list.innerHTML = '<div class="config-rule"><div><strong>Nenhuma pendencia personalizada</strong><span>Adicione um nome e um trecho da mensagem para criar novos cards.</span></div></div>';
            return;
        }

        list.innerHTML = rules.map(function (rule) {
            return '<div class="config-rule"><div><strong>' + escapeHtml(rule.name) + '</strong><span>' + escapeHtml(rule.pattern) + '</span></div><button type="button" data-rule-id="' + rule.id + '">Remover</button></div>';
        }).join('');
        list.querySelectorAll('[data-rule-id]').forEach(function (button) {
            button.addEventListener('click', function () {
                deletePendencyRule(button.getAttribute('data-rule-id'));
            });
        });
    }

    function renderCustomPendencies() {
        const target = document.getElementById('customPendingList');
        if (!target) return;
        const rules = getPendencyRules();
        if (!rules.length) {
            target.innerHTML = '';
            return;
        }

        target.innerHTML = rules.map(function (rule) {
            const rows = getRowsForCustomRule(rule);
            const qtd = sumRows(rows);
            const stateClass = qtd > 0 ? 'has-pendency' : 'is-zero';
            return '<div class="pending-item pend-neutra ' + stateClass + '" data-custom-rule-id="' + rule.id + '"><span>' + escapeHtml(rule.name) + '</span><strong>' + formatNumber(qtd) + '</strong></div>';
        }).join('');
        target.querySelectorAll('[data-custom-rule-id]').forEach(function (card) {
            card.addEventListener('click', function () {
                showCustomPendingDetail(card.getAttribute('data-custom-rule-id'));
            });
        });
    }

    function getRowsForCustomRule(rule) {
        const shouldIgnoreDefault = !ruleMatchesIgnoredPattern(rule);
        return configurableMessages.filter(function (row) {
            if (!matchesPattern(row, rule.pattern)) return false;
            if (shouldIgnoreDefault && matchesAnyPattern(row, defaultIgnoredErrorPatterns)) return false;
            return true;
        });
    }

    function updateResidualErrorCard() {
        const card = document.querySelector('.pending-item.pend-erro');
        if (!card) return;
        const qtd = sumRows(getResidualMessages());
        const value = card.querySelector('strong');
        if (value) value.textContent = formatNumber(qtd);
        card.classList.toggle('has-pendency', qtd > 0);
        card.classList.toggle('is-zero', qtd === 0);
    }

    function escapeHtml(value) {
        return String(value || '')
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    }

    function formatNumber(value) {
        return Number(value || 0).toLocaleString('pt-BR');
    }

    function detailText(value) {
        const text = String(value || '').replace(/\s+/g, ' ').trim();
        return text.length > 650 ? text.slice(0, 650) + '...' : text;
    }

    function getExportFileName(base, extension) {
        const now = new Date();
        const stamp = [
            now.getFullYear(),
            String(now.getMonth() + 1).padStart(2, '0'),
            String(now.getDate()).padStart(2, '0'),
            String(now.getHours()).padStart(2, '0'),
            String(now.getMinutes()).padStart(2, '0')
        ].join('');
        return base + '_' + stamp + '.' + extension;
    }

    function downloadBlob(content, filename, mimeType) {
        const blob = new Blob([content], { type: mimeType });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        window.setTimeout(function () {
            URL.revokeObjectURL(link.href);
        }, 500);
    }

    function getTableMatrix(tableId) {
        const table = document.getElementById(tableId);
        if (!table) return [];
        return Array.prototype.map.call(table.querySelectorAll('tr'), function (tr) {
            return Array.prototype.map.call(tr.children, function (cell) {
                return String(cell.textContent || '').replace(/\s+/g, ' ').trim();
            });
        });
    }

    function exportTableCsv(tableId, filename) {
        const rows = getTableMatrix(tableId);
        if (!rows.length) {
            showSqlToast('Nao ha dados para exportar');
            return;
        }
        const csv = rows.map(function (row) {
            return row.map(function (value) {
                return '"' + value.replace(/"/g, '""') + '"';
            }).join(';');
        }).join('\r\n');
        downloadBlob('\ufeff' + csv, filename, 'text/csv;charset=utf-8;');
        showSqlToast('CSV gerado com sucesso');
    }

    function exportTableXls(tableId, filename) {
        const table = document.getElementById(tableId);
        if (!table) {
            showSqlToast('Nao ha dados para exportar');
            return;
        }
        const html = '<html><head><meta charset="UTF-8"></head><body>' +
            '<table border="1">' + table.innerHTML + '</table>' +
            '</body></html>';
        downloadBlob('\ufeff' + html, filename, 'application/vnd.ms-excel;charset=utf-8;');
        showSqlToast('XLS gerado com sucesso');
    }

    function exportCompanyDetail(type) {
        showLoading('Gerando exportacao', 'Preparando o detalhamento por empresa...');
        window.setTimeout(function () {
            if (type === 'csv') {
                exportTableCsv('companyDetailTable', getExportFileName('detalhamento_por_empresa', 'csv'));
                hideLoading(200);
                return;
            }
            exportTableXls('companyDetailTable', getExportFileName('detalhamento_por_empresa', 'xls'));
            hideLoading(200);
        }, 60);
    }

    function toggleCompanyDetail() {
        const body = document.getElementById('companyDetailBody');
        const button = document.getElementById('companyDetailToggle');
        if (!body || !button) return;

        const isCollapsed = body.classList.toggle('is-collapsed');
        const icon = button.querySelector('i');
        const label = button.querySelector('span');

        if (icon) {
            icon.className = isCollapsed ? 'fa-solid fa-chevron-down' : 'fa-solid fa-chevron-up';
        }
        if (label) {
            label.textContent = isCollapsed ? 'Mostrar detalhamento' : 'Ocultar detalhamento';
        }
    }

    function handlePendingCardClick(cardClass) {
        showLoading('Carregando detalhe', 'Agrupando as mensagens de pendencia...');
        copyPendingSql(cardClass);
        window.setTimeout(function () {
            showPendingDetail(cardClass);
            hideLoading(160);
        }, 60);
    }

    function hidePendingDetail() {
        const detail = document.getElementById('pendingDetail');
        if (detail) detail.classList.add('is-hidden');
        updatePendingDetailToggle(false);
    }

    function updatePendingDetailToggle(isOpen) {
        const button = document.getElementById('pendingDetailToggleButton');
        if (!button) return;
        const icon = button.querySelector('i');
        const label = button.querySelector('span');
        if (icon) icon.className = isOpen ? 'fa-solid fa-chevron-up' : 'fa-solid fa-chevron-down';
        if (label) label.textContent = isOpen ? 'Ocultar detalhe' : 'Mostrar detalhe';
    }

    function togglePendingDetail() {
        const detail = document.getElementById('pendingDetail');
        if (!detail) return;
        if (detail.classList.contains('is-hidden')) {
            showLoading('Carregando detalhe', 'Agrupando as mensagens de pendencia...');
            window.setTimeout(function () {
                showPendingDetail('pend-erro');
                hideLoading(160);
            }, 60);
        } else {
            hidePendingDetail();
        }
    }

    function showPendingDetail(cardClass) {
        const detail = document.getElementById('pendingDetail');
        const title = document.getElementById('pendingDetailTitle');
        const hint = document.getElementById('pendingDetailHint');
        const rows = document.getElementById('pendingDetailRows');
        if (!detail || !title || !hint || !rows) return;

        const filter = pendingDetailFilters[cardClass];
        if (!filter) {
            title.textContent = 'Consulta copiada';
            hint.textContent = 'Use a SQL no DBExplorer para abrir o detalhe';
            rows.innerHTML = '<div class="pending-detail-row"><span>Este indicador depende de status ou tipo geral da TTKEVT.</span><strong>SQL</strong></div>';
            detail.classList.remove('is-hidden');
            updatePendingDetailToggle(true);
            return;
        }

        if (cardClass === 'pend-modelo') {
            const modelos = unsupportedModelRows
                .slice()
                .sort(function (a, b) { return Number(b.qtd || 0) - Number(a.qtd || 0); })
                .slice(0, 10);

            title.textContent = 'Modelo ainda nao suportado';
            hint.textContent = modelos.length ? 'Agrupado por tipo e evento' : 'Nenhum modelo nao suportado encontrado';
            rows.innerHTML = modelos.length
                ? modelos.map(function (row) {
                    return '<div class="pending-detail-row"><span>' + escapeHtml(row.tipo + ' | ' + row.evento) + '</span><strong>' + formatNumber(row.qtd) + '</strong></div>';
                }).join('')
                : '<div class="pending-detail-row"><span>Nao ha modelos agrupados para exibir.</span><strong>0</strong></div>';
            detail.classList.remove('is-hidden');
            updatePendingDetailToggle(true);
            return;
        }

        if (filter.pattern) {
            const motivosExtraidos = getExtractedReasonRows(filter.reasonPattern || filter.pattern).slice(0, 8);
            if (motivosExtraidos.length) {
                title.textContent = filter.title;
                hint.textContent = 'Motivos extraidos do java.lang.IllegalStateException';
                rows.innerHTML = motivosExtraidos.map(function (row) {
                    return '<div class="pending-detail-row"><span>' + escapeHtml(detailText(row.text)) + '</span><strong>' + formatNumber(row.qtd) + '</strong></div>';
                }).join('');
                detail.classList.remove('is-hidden');
                updatePendingDetailToggle(true);
                return;
            }
        }

        let filtered = [];
        if (filter.residual) {
            filtered = getResidualMessages();
        } else {
            filtered = configurableMessages.filter(function (row) {
                if (filter.pattern) {
                    return matchesPattern(row, filter.pattern);
                }
                return false;
            });
        }
        filtered = filtered
            .sort(function (a, b) { return Number(b.qtd || 0) - Number(a.qtd || 0); })
            .slice(0, 8);

        title.textContent = filter.title;
        hint.textContent = filtered.length ? 'Top mensagens agrupadas' : 'Nenhuma mensagem encontrada para este filtro';
        rows.innerHTML = filtered.length
            ? filtered.map(function (row) {
                return '<div class="pending-detail-row"><span>' + escapeHtml(detailText(row.text)) + '</span><strong>' + formatNumber(row.qtd) + '</strong></div>';
            }).join('')
            : '<div class="pending-detail-row"><span>Nao ha mensagens agrupadas para exibir neste card.</span><strong>0</strong></div>';
        detail.classList.remove('is-hidden');
        updatePendingDetailToggle(true);
    }

    function showCustomPendingDetail(ruleId) {
        const rule = getPendencyRules().filter(function (item) {
            return String(item.id) === String(ruleId);
        })[0];
        if (!rule) return;

        const detail = document.getElementById('pendingDetail');
        const title = document.getElementById('pendingDetailTitle');
        const hint = document.getElementById('pendingDetailHint');
        const rows = document.getElementById('pendingDetailRows');
        if (!detail || !title || !hint || !rows) return;

        const filtered = getRowsForCustomRule(rule)
            .sort(function (a, b) { return Number(b.qtd || 0) - Number(a.qtd || 0); })
            .slice(0, 8);

        title.textContent = rule.name;
        hint.textContent = filtered.length ? 'Top mensagens agrupadas' : 'Nenhuma mensagem encontrada para este filtro';
        rows.innerHTML = filtered.length
            ? filtered.map(function (row) {
                return '<div class="pending-detail-row"><span>' + escapeHtml(detailText(row.text)) + '</span><strong>' + formatNumber(row.qtd) + '</strong></div>';
            }).join('')
            : '<div class="pending-detail-row"><span>Nao ha mensagens agrupadas para exibir neste card.</span><strong>0</strong></div>';
        detail.classList.remove('is-hidden');
        updatePendingDetailToggle(true);
    }

    function copyPendingSql(cardClass) {
        const sql = pendingSqlMap[cardClass];
        if (!sql) return;

        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(sql).then(function () {
                showSqlToast('Consulta copiada para usar no DBExplorer');
            }).catch(function () {
                legacyCopySql(sql);
            });
        } else {
            legacyCopySql(sql);
        }
    }

    function legacyCopySql(sql) {
        const textarea = document.createElement('textarea');
        textarea.value = sql;
        textarea.setAttribute('readonly', 'readonly');
        textarea.style.position = 'fixed';
        textarea.style.opacity = '0';
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
        showSqlToast('Consulta copiada para usar no DBExplorer');
    }

    renderCustomPendencies();
    updateResidualErrorCard();
</script>
</body>
</html>
