<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false"%>
<%@ taglib uri="http://java.sun.com/jstl/core_rt" prefix="c" %>
<%@ taglib prefix="snk" uri="/WEB-INF/tld/sankhyaUtil.tld" %>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <snk:load/>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://cdnjs.cloudflare.com">
    <link rel="preconnect" href="https://code.highcharts.com">
    <title>Dashboard de Serviços</title>

    <!-- Highcharts -->
    <script defer src="https://code.highcharts.com/highcharts.js"></script>
    <script defer src="https://code.highcharts.com/modules/accessibility.js"></script>

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" rel="stylesheet">

    <style>
        :root {
            --bg-page: #f4f7fb;
            --bg-panel: #ffffff;
            --bg-sidebar: #ffffff;
            --bg-card: #ffffff;
            --text-title: #172033;
            --text-body: #5e6b7f;
            --text-muted: #8a97a8;
            --green: #21a366;
            --green-soft: #e7f6ee;
            --orange: #f59e0b;
            --red: #ef4444;
            --blue: #2563eb;
            --border: #e5eaf1;
            --shadow: 0 12px 30px rgba(15, 23, 42, .08);
            --radius: 18px;
        }

        * { box-sizing: border-box; }

        body {
            margin: 0;
            background: var(--bg-page);
            color: var(--text-title);
            font-family: "Segoe UI", Arial, sans-serif;
            overflow-x: hidden;
        }

        .app {
            display: grid;
            grid-template-columns: 230px minmax(0, 1fr);
            min-height: 100vh;
        }

        .sidebar {
            background: var(--bg-sidebar);
            border-right: 1px solid var(--border);
            padding: 18px 14px;
        }

        .brand {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 8px 10px 20px;
            font-weight: 800;
            color: var(--text-title);
        }

        .brand-icon {
            width: 34px;
            height: 34px;
            border-radius: 11px;
            display: grid;
            place-items: center;
            background: var(--green-soft);
            color: var(--green);
        }

        .nav-title {
            font-size: 11px;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: .12em;
            margin: 16px 12px 8px;
            font-weight: 700;
        }

        .nav-item {
            display: flex;
            align-items: center;
            gap: 11px;
            width: 100%;
            border: 0;
            background: transparent;
            color: var(--text-body);
            padding: 11px 12px;
            border-radius: 12px;
            font-size: 14px;
            text-align: left;
            cursor: pointer;
            transition: .18s ease;
        }

        .nav-item:hover,
        .nav-item.active {
            background: var(--green-soft);
            color: var(--green);
            font-weight: 700;
        }

        .main {
            padding: 18px 24px 28px;
            min-width: 0;
        }

        .topbar {
            background: var(--bg-panel);
            border: 1px solid var(--border);
            border-radius: 16px;
            min-height: 58px;
            padding: 0 18px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: 0 6px 18px rgba(15, 23, 42, .04);
            margin-bottom: 18px;
        }

        .topbar h1 {
            margin: 0;
            font-size: 17px;
            font-weight: 800;
        }

        .grid-kpi {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 18px;
            margin-bottom: 18px;
        }

        .kpi {
            background: var(--bg-card);
            border: 1px solid var(--border);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            padding: 18px;
            display: flex;
            align-items: center;
            gap: 16px;
            min-height: 112px;
        }

        .kpi-icon {
            width: 50px;
            height: 50px;
            min-width: 50px;
            border-radius: 16px;
            display: grid;
            place-items: center;
            background: var(--green-soft);
            color: var(--green);
            font-size: 22px;
        }

        .kpi-label {
            display: block;
            color: var(--text-muted);
            font-size: 12px;
            letter-spacing: .06em;
            text-transform: uppercase;
            font-weight: 700;
            margin-bottom: 6px;
        }

        .kpi-value {
            font-size: 25px;
            font-weight: 850;
            color: var(--text-title);
            line-height: 1.1;
        }

        .dash-grid {
            display: grid;
            grid-template-columns: repeat(12, minmax(0, 1fr));
            gap: 18px;
        }

        .card {
            background: var(--bg-card);
            border: 1px solid var(--border);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            padding: 18px;
            min-width: 0;
        }

        .span-12 { grid-column: span 12; }
        .span-7 { grid-column: span 7; }
        .span-5 { grid-column: span 5; }

        .card-head {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            margin-bottom: 10px;
        }

        .card-title {
            margin: 0;
            font-size: 15px;
            font-weight: 800;
            color: var(--text-title);
        }

        .card-title i {
            color: var(--green);
            margin-right: 7px;
        }

        .chart { height: 330px; }
        .chart-large { height: 360px; }
        .hidden-data { display: none; }
        .detail-card { display: none; }
        .detail-card.is-open { display: block; }
        .detail-actions {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            margin-bottom: 12px;
        }
        .detail-subtitle {
            color: var(--text-muted);
            font-size: 12px;
            font-weight: 700;
        }
        .detail-close {
            border: 0;
            background: var(--green-soft);
            color: var(--green);
            border-radius: 10px;
            padding: 8px 12px;
            cursor: pointer;
            font-weight: 800;
        }
        .table-wrapper {
            overflow: auto;
            border: 1px solid var(--border);
            border-radius: 14px;
        }
        .data-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 13px;
        }
        .data-table th,
        .data-table td {
            padding: 10px 12px;
            border-bottom: 1px solid var(--border);
            vertical-align: top;
        }
        .data-table th {
            background: #f8fafc;
            color: var(--text-muted);
            font-size: 11px;
            letter-spacing: .05em;
            text-transform: uppercase;
            text-align: left;
            white-space: nowrap;
        }
        .data-table .filter-row th {
            background: #ffffff;
            padding: 8px;
        }
        .column-filter {
            width: 100%;
            min-width: 92px;
            border: 1px solid var(--border);
            border-radius: 8px;
            padding: 7px 8px;
            color: var(--text-title);
            font: 12px "Segoe UI", Arial, sans-serif;
            outline: none;
        }
        .column-filter:focus {
            border-color: var(--green);
            box-shadow: 0 0 0 3px rgba(33, 163, 102, .12);
        }
        .data-table tr:last-child td { border-bottom: 0; }
        .align-right { text-align: right; }
        .nota-link {
            border: 0;
            background: transparent;
            color: var(--blue);
            cursor: pointer;
            font: inherit;
            font-weight: 800;
            padding: 0;
            text-decoration: underline;
        }
        .empty-detail {
            padding: 18px;
            color: var(--text-muted);
            font-weight: 700;
        }

        @media (max-width: 1100px) {
            .app { grid-template-columns: 1fr; }
            .sidebar { display: none; }
            .grid-kpi { grid-template-columns: 1fr; }
            .span-7, .span-5 { grid-column: span 12; }
            .main { padding: 12px; }
        }
    
        /* Otimizações de renderização: limita reflows/repaints em blocos independentes */
        .card, .kpi, .resumo-total, .mini-card, .table-wrap, .ranking-list {
            contain: layout paint;
        }
        table { table-layout: fixed; }
</style>
</head>

<body>

<%-- CONSULTA 1 - Série mensal do faturamento total. --%>
<snk:query var="q_faturamento_mensal">
SELECT
    TO_CHAR(TRUNC(CAB.DTNEG,'MM'),'MM/YYYY') MES_ANO,
    SUM(ITE.VLRTOT) VALOR
FROM TGFCAB CAB
INNER JOIN TGFITE ITE ON ITE.NUNOTA = CAB.NUNOTA
INNER JOIN TGFPRO PRO ON PRO.CODPROD = ITE.CODPROD
INNER JOIN TGFPAR PAR ON CAB.CODPARC = PAR.CODPARC
INNER JOIN TSIEND EDN ON PAR.CODEND = EDN.CODEND
INNER JOIN TSICID CID ON PAR.CODCID = CID.CODCID
INNER JOIN TSIUFS UFS ON CID.UF = UFS.CODUF
WHERE CAB.STATUSNOTA = 'L'
  AND CAB.TIPMOV = 'V'
  AND PRO.USOPROD = 'S'
  AND (CAB.DTNEG >= :P_DATA_INI OR :P_DATA_INI IS NULL)
  AND (CAB.DTNEG <= :P_DATA_FIM OR :P_DATA_FIM IS NULL)
  AND (:P_UF IS NULL OR UFS.CODUF IN (:P_UF))
  AND (:P_TOP IS NULL OR CAB.CODTIPOPER IN (:P_TOP))
  AND (:P_EMPRESA IS NULL OR CAB.CODEMP IN (:P_EMPRESA))
GROUP BY TRUNC(CAB.DTNEG,'MM')
ORDER BY TRUNC(CAB.DTNEG,'MM')
</snk:query>

<%-- CONSULTA 2 - Evolução de serviços. --%>
<snk:query var="q_evolucao_servicos">
SELECT
    TO_CHAR(CAB.DTNEG, 'MM/YYYY') AS MES_ANO,
    SUM(ITE.VLRTOT) AS TOTAL,
    COUNT(DISTINCT CAB.NUNOTA) AS QTD_NOTAS,
    ROUND(SUM(ITE.VLRTOT) / NULLIF(COUNT(DISTINCT CAB.NUNOTA), 0), 2) AS TICKET_MEDIO,
    TO_CHAR(CAB.DTNEG, 'YYYYMM') AS ORDENACAO
FROM TGFCAB CAB
INNER JOIN TGFITE ITE ON CAB.NUNOTA = ITE.NUNOTA
INNER JOIN TGFPRO PRO ON PRO.CODPROD = ITE.CODPROD
INNER JOIN TGFPAR PAR ON CAB.CODPARC = PAR.CODPARC
INNER JOIN TSICID CID ON PAR.CODCID = CID.CODCID
INNER JOIN TSIUFS UFS ON CID.UF = UFS.CODUF
WHERE CAB.STATUSNOTA = 'L'
  AND CAB.TIPMOV = 'V'
  AND PRO.USOPROD = 'S'
  AND (CAB.DTNEG >= :P_DATA_INI OR :P_DATA_INI IS NULL)
  AND (CAB.DTNEG <= :P_DATA_FIM OR :P_DATA_FIM IS NULL)
  AND (:P_EMPRESA IS NULL OR CAB.CODEMP IN (:P_EMPRESA))
  AND (:P_TOP IS NULL OR CAB.CODTIPOPER IN (:P_TOP))
  AND (:P_UF IS NULL OR UFS.CODUF IN (:P_UF))
GROUP BY TO_CHAR(CAB.DTNEG, 'MM/YYYY'), TO_CHAR(CAB.DTNEG, 'YYYYMM')
ORDER BY ORDENACAO
</snk:query>

<%-- CONSULTA 3 - KPIs superiores. --%>
<snk:query var="q_kpis">
SELECT
    NVL(SUM(ITE.VLRTOT), 0) AS TOTAL_FAT,
    COUNT(DISTINCT ITE.CODPROD) AS QTD_SERVICOS,
    COUNT(DISTINCT CAB.NUNOTA) AS QTD_TOTAL
FROM TGFITE ITE
INNER JOIN TGFCAB CAB ON ITE.NUNOTA = CAB.NUNOTA
INNER JOIN TGFPRO PRO ON ITE.CODPROD = PRO.CODPROD
INNER JOIN TGFPAR PAR ON CAB.CODPARC = PAR.CODPARC
INNER JOIN TSICID CID ON PAR.CODCID = CID.CODCID
INNER JOIN TSIUFS UFS ON CID.UF = UFS.CODUF
WHERE CAB.STATUSNOTA = 'L'
  AND PRO.USOPROD = 'S'
  AND CAB.TIPMOV = 'V'
  AND (CAB.DTNEG >= :P_DATA_INI OR :P_DATA_INI IS NULL)
  AND (CAB.DTNEG <= :P_DATA_FIM OR :P_DATA_FIM IS NULL)
  AND (:P_UF IS NULL OR UFS.CODUF IN (:P_UF))
  AND (:P_TOP IS NULL OR CAB.CODTIPOPER IN (:P_TOP))
  AND (:P_EMPRESA IS NULL OR CAB.CODEMP IN (:P_EMPRESA))
</snk:query>

<%-- CONSULTA 4 - Serviços mais utilizados. --%>
<snk:query var="q_servicos_pizza">
SELECT
    PRO.CODPROD AS CODPROD,
    PRO.DESCRPROD AS SERVICO,
    SUM(ITE.QTDNEG) AS QTD,
    SUM(ITE.VLRTOT) AS VALOR
FROM TGFITE ITE
INNER JOIN TGFCAB CAB ON ITE.NUNOTA = CAB.NUNOTA
INNER JOIN TGFPRO PRO ON ITE.CODPROD = PRO.CODPROD
INNER JOIN TGFPAR PAR ON CAB.CODPARC = PAR.CODPARC
INNER JOIN TSICID CID ON PAR.CODCID = CID.CODCID
INNER JOIN TSIUFS UFS ON CID.UF = UFS.CODUF
WHERE CAB.STATUSNOTA = 'L'
  AND PRO.USOPROD = 'S'
  AND CAB.TIPMOV = 'V'
  AND (CAB.DTNEG >= :P_DATA_INI OR :P_DATA_INI IS NULL)
  AND (CAB.DTNEG <= :P_DATA_FIM OR :P_DATA_FIM IS NULL)
  AND (:P_UF IS NULL OR UFS.CODUF IN (:P_UF))
  AND (:P_TOP IS NULL OR CAB.CODTIPOPER IN (:P_TOP))
  AND (:P_EMPRESA IS NULL OR CAB.CODEMP IN (:P_EMPRESA))
GROUP BY PRO.CODPROD, PRO.DESCRPROD
ORDER BY SUM(ITE.QTDNEG) DESC
</snk:query>

<%-- CONSULTA 5 - Detalhamento das notas para cliques nos gráficos. --%>
<snk:query var="q_detalhe_notas">
SELECT
    TO_CHAR(TRUNC(CAB.DTNEG, 'MM'), 'MM/YYYY') AS MES_ANO,
    CAB.NUNOTA,
    CAB.CODEMP,
    EMP.RAZAOSOCIAL,
    PRO.CODPROD,
    PRO.DESCRPROD AS SERVICO,
    SUM(ITE.VLRTOT) AS VLRNOTA,
    TO_CHAR(SUM(ITE.VLRTOT), 'FM999G999G999G990D00', 'NLS_NUMERIC_CHARACTERS = '',.''') AS VLRNOTA_FMT
FROM TGFCAB CAB
INNER JOIN TGFITE ITE ON ITE.NUNOTA = CAB.NUNOTA
INNER JOIN TGFPRO PRO ON PRO.CODPROD = ITE.CODPROD
INNER JOIN TGFPAR PAR ON CAB.CODPARC = PAR.CODPARC
INNER JOIN TSIEMP EMP ON EMP.CODEMP = CAB.CODEMP
INNER JOIN TSICID CID ON PAR.CODCID = CID.CODCID
INNER JOIN TSIUFS UFS ON CID.UF = UFS.CODUF
WHERE CAB.STATUSNOTA = 'L'
  AND CAB.TIPMOV = 'V'
  AND PRO.USOPROD = 'S'
  AND (CAB.DTNEG >= :P_DATA_INI OR :P_DATA_INI IS NULL)
  AND (CAB.DTNEG <= :P_DATA_FIM OR :P_DATA_FIM IS NULL)
  AND (:P_UF IS NULL OR UFS.CODUF IN (:P_UF))
  AND (:P_TOP IS NULL OR CAB.CODTIPOPER IN (:P_TOP))
  AND (:P_EMPRESA IS NULL OR CAB.CODEMP IN (:P_EMPRESA))
GROUP BY
    TO_CHAR(TRUNC(CAB.DTNEG, 'MM'), 'MM/YYYY'),
    TRUNC(CAB.DTNEG, 'MM'),
    CAB.NUNOTA,
    CAB.CODEMP,
    EMP.RAZAOSOCIAL,
    PRO.CODPROD,
    PRO.DESCRPROD
ORDER BY TRUNC(CAB.DTNEG, 'MM'), CAB.NUNOTA, PRO.DESCRPROD
</snk:query>

<c:set var="kpi" value="${q_kpis.rows[0]}" />

<!--
    Bloco oculto de dados.
    Correção aplicada:
    Os textos vindos do banco não são mais injetados diretamente dentro do JavaScript.
    Isso evita SyntaxError quando a descrição possui &, aspas, acentos, barra, quebra de linha etc.
-->
<div id="dados-dashboard" class="hidden-data">

    <div id="dados-kpi"
         data-total-fat="<c:out value='${kpi.TOTAL_FAT}'/>"
         data-qtd-servicos="<c:out value='${kpi.QTD_SERVICOS}'/>"
         data-qtd-total="<c:out value='${kpi.QTD_TOTAL}'/>">
    </div>

    <div id="dados-faturamento">
        <c:forEach items="${q_faturamento_mensal.rows}" var="row">
            <span class="fat-row"
                  data-mes="<c:out value='${row.MES_ANO}'/>"
                  data-valor="<c:out value='${row.VALOR}'/>"></span>
        </c:forEach>
    </div>

    <div id="dados-evolucao">
        <c:forEach items="${q_evolucao_servicos.rows}" var="row">
            <span class="ev-row"
                  data-mes="<c:out value='${row.MES_ANO}'/>"
                  data-total="<c:out value='${row.TOTAL}'/>"
                  data-ticket="<c:out value='${row.TICKET_MEDIO}'/>"
                  data-notas="<c:out value='${row.QTD_NOTAS}'/>"></span>
        </c:forEach>
    </div>

    <div id="dados-pizza">
        <c:forEach items="${q_servicos_pizza.rows}" var="row">
            <span class="pizza-row"
                  data-codprod="<c:out value='${row.CODPROD}'/>"
                  data-qtd="<c:out value='${row.QTD}'/>"><c:out value="${row.SERVICO}"/></span>
        </c:forEach>
    </div>

    <div id="dados-detalhe-notas">
        <c:forEach items="${q_detalhe_notas.rows}" var="row">
            <span class="nota-detalhe-row"
                  data-mes="<c:out value='${row.MES_ANO}'/>"
                  data-nunota="<c:out value='${row.NUNOTA}'/>"
                  data-codemp="<c:out value='${row.CODEMP}'/>"
                  data-razaosocial="<c:out value='${row.RAZAOSOCIAL}'/>"
                  data-codprod="<c:out value='${row.CODPROD}'/>"
                  data-vlrnota="<c:out value='${row.VLRNOTA_FMT}'/>"><c:out value="${row.SERVICO}"/></span>
        </c:forEach>
    </div>

</div>

<div class="app">

    <aside class="sidebar">

        <div class="brand">
            <span class="brand-icon"><i class="fa-solid fa-bars"></i></span>
            <span>Menu Inicial</span>
        </div>

        <div class="nav-title">Dashboard</div>

        <button class="nav-item active" type="button" onclick="abrirNivel('lvl_serv_capa')">
            <i class="fa-solid fa-house"></i> Início
        </button>

        <button class="nav-item" type="button" onclick="abrirNivel('lvl_tomadores')">
            <i class="fa-solid fa-briefcase"></i> Análise Tomadores
        </button>

        <button class="nav-item" type="button" onclick="abrirNivel('lvl_fat_cidade')">
            <i class="fa-solid fa-city"></i> Movimento por Município
        </button>

        <button class="nav-item" type="button" onclick="abrirIssMunicipio()">
            <i class="fa-solid fa-map-location-dot"></i> ISS por Município
        </button>

        <button class="nav-item" type="button" onclick="abrirNivel('lvl_mapa_tributario')">
            <i class="fa-solid fa-layer-group"></i> Auditoria de Impostos
        </button>

        <button class="nav-item" type="button" onclick="abrirServicosSemMovimento()">
            <i class="fa-solid fa-screwdriver-wrench"></i> Serviços
        </button>

    </aside>

    <main class="main">

        <header class="topbar">
            <div class="topbar-left">
                <h1>Dashboard Comercial de Serviços</h1>
            </div>
        </header>

        <section class="grid-kpi">

            <article class="kpi">
                <div class="kpi-icon"><i class="fa-solid fa-sack-dollar"></i></div>
                <div>
                    <span class="kpi-label">Faturamento Total</span>
                    <div class="kpi-value" id="kpiFaturamento">R$ 0,00</div>
                </div>
            </article>

            <article class="kpi">
                <div class="kpi-icon"><i class="fa-solid fa-briefcase"></i></div>
                <div>
                    <span class="kpi-label">Serviços Distintos</span>
                    <div class="kpi-value" id="kpiServicos">0</div>
                </div>
            </article>

            <article class="kpi">
                <div class="kpi-icon"><i class="fa-solid fa-layer-group"></i></div>
                <div>
                    <span class="kpi-label">Quantidade Total</span>
                    <div class="kpi-value" id="kpiQuantidade">0</div>
                </div>
            </article>

        </section>

        <section class="dash-grid">

            <article class="card span-12">
                <div class="card-head">
                    <h2 class="card-title"><i class="fa-solid fa-chart-line"></i> Faturamento Total</h2>
                </div>
                <div id="chartFaturamento" class="chart-large"></div>
            </article>

            <article class="card span-7">
                <div class="card-head">
                    <h2 class="card-title"><i class="fa-solid fa-chart-area"></i> Evolução de Serviços</h2>
                </div>
                <div id="chartEvolucao" class="chart"></div>
            </article>

            <article class="card span-5">
                <div class="card-head">
                    <h2 class="card-title"><i class="fa-solid fa-chart-pie"></i> Serviços Mais Utilizados</h2>
                </div>
                <div id="chartPizza" class="chart"></div>
            </article>

            <article class="card detail-card span-12" id="cardDetalheNotas">
                <div class="card-head">
                    <h2 class="card-title"><i class="fa-solid fa-table-list"></i> Detalhamento de Notas</h2>
                </div>
                <div class="detail-actions">
                    <div class="detail-subtitle" id="detalheNotasTitulo">Selecione um ponto do grafico para visualizar as notas.</div>
                    <button class="detail-close" type="button" onclick="fecharDetalheNotas()">Ocultar</button>
                </div>
                <div class="table-wrapper" id="detalheNotasTabela"></div>
            </article>

        </section>

    </main>

</div>

<script>
    var gadGetID = '${param.gadGetID}';
    var nuGdg = '${param.nuGdg}';
    var contextPage = null;

    try {
        if (window.parent && window.parent.dashboard && window.parent.dashboard[nuGdg]) {
            contextPage = window.parent.dashboard[nuGdg];
        }
    } catch (e) {
        contextPage = null;
    }

    function toNumber(value) {
        if (value === null || value === undefined || value === '') {
            return 0;
        }

        value = String(value).trim();

        if (value === '') {
            return 0;
        }

        if (value.indexOf(',') >= 0) {
            value = value.replace(/\./g, '').replace(',', '.');
        }

        var number = Number(value);
        return isNaN(number) ? 0 : number;
    }

    function formatBRL(v) {
        return new Intl.NumberFormat('pt-BR', {
            style: 'currency',
            currency: 'BRL'
        }).format(v || 0);
    }

    function formatNumber(v) {
        return new Intl.NumberFormat('pt-BR', {
            maximumFractionDigits: 0
        }).format(v || 0);
    }

    function hcBase() {
        return {
            chart: {
                backgroundColor: 'transparent',
                style: {
                    fontFamily: 'Segoe UI, Arial, sans-serif'
                }
            },
            title: { text: null },
            credits: { enabled: false },
            accessibility: { enabled: false },
            legend: {
                itemStyle: {
                    color: '#5e6b7f',
                    fontWeight: '600'
                }
            },
            xAxis: {
                labels: { style: { color: '#8a97a8' } },
                lineColor: '#e5eaf1',
                tickColor: '#e5eaf1'
            },
            yAxis: {
                title: { text: null },
                labels: { style: { color: '#8a97a8' } },
                gridLineColor: '#edf1f6'
            }
        };
    }

    function abrirNivel(levelId, params) {
        params = params || {};

        if (typeof openLevel === 'function') {
            openLevel(levelId, params);
            return;
        }

        if (window.parent && typeof window.parent.openLevel === 'function') {
            window.parent.openLevel(levelId, params);
            return;
        }

        if (typeof JX !== 'undefined' && JX.openLevel) {
            JX.openLevel(levelId, params);
            return;
        }

        if (window.parent && window.parent.postMessage) {
            window.parent.postMessage({
                type: 'openLevel',
                levelId: levelId,
                params: params
            }, '*');
            return;
        }

        alert('Não foi possível abrir o nível: ' + levelId);
    }

    function abrirServicosSemMovimento() {
        try {
            if (window.parent) {
                window.parent.__abrirServicosSemMov = true;
            }
        } catch (e) {}
        abrirNivel('lvl_mapa_tributario', { ABRIR_SERVICOS: 'S' });
    }

    function abrirIssMunicipio() {
        try {
            if (window.parent) {
                window.parent.__abrirIssMunicipio = true;
            }
        } catch (e) {}
        abrirNivel('lvl_fat_cidade', { ABRIR_ISS_MUNICIPIO: 'S' });
    }

    var detalhesNotas = [];

    function abrirNotaCentral(nunota) {
        var resourceId = 'br.com.sankhya.com.mov.CentralNotas';
        var params = { NUNOTA: String(nunota) };
        var paramsLista = [{ name: 'NUNOTA', value: String(nunota) }];

        function tentar(fn) {
            try {
                fn();
                return true;
            } catch (e) {
                return false;
            }
        }

        var alvos = [
            contextPage,
            window.parent && window.parent.dashboard && window.parent.dashboard[nuGdg],
            window.parent,
            window.parent && window.parent.JX,
            window.parent && window.parent.sankhya,
            typeof JX !== 'undefined' ? JX : null
        ];

        for (var i = 0; i < alvos.length; i++) {
            var alvo = alvos[i];
            if (!alvo) continue;

            if (typeof alvo.openApp === 'function' && tentar(function() { alvo.openApp(resourceId, params); })) return;
            if (typeof alvo.openApp === 'function' && tentar(function() { alvo.openApp(resourceId, paramsLista); })) return;
            if (typeof alvo.openResource === 'function' && tentar(function() { alvo.openResource(resourceId, params); })) return;
            if (typeof alvo.openResource === 'function' && tentar(function() { alvo.openResource(resourceId, paramsLista); })) return;
            if (typeof alvo.launcher === 'function' && tentar(function() { alvo.launcher(resourceId, params); })) return;
            if (typeof alvo.launcher === 'function' && tentar(function() { alvo.launcher(resourceId, paramsLista); })) return;
            if (typeof alvo.openPage === 'function' && tentar(function() { alvo.openPage(resourceId, params); })) return;
            if (typeof alvo.openPage === 'function' && tentar(function() { alvo.openPage(resourceId, paramsLista); })) return;
        }

        if (window.parent && window.parent.postMessage) {
            window.parent.postMessage({
                type: 'openApp',
                resourceId: resourceId,
                params: params
            }, '*');
            return;
        }

        alert('Nao foi possivel abrir a nota ' + nunota + ' na Central de Notas.');
    }

    function fecharDetalheNotas() {
        var card = document.getElementById('cardDetalheNotas');
        if (card) {
            card.classList.remove('is-open');
        }
    }

    function criarCelula(texto, classe) {
        var td = document.createElement('td');
        if (classe) td.className = classe;
        td.textContent = texto || '';
        return td;
    }

    function aplicarFiltrosTabela(table) {
        var filtros = table.querySelectorAll('.column-filter');
        var linhas = table.querySelectorAll('tbody tr');

        for (var i = 0; i < linhas.length; i++) {
            var tr = linhas[i];
            var visivel = true;

            for (var j = 0; j < filtros.length; j++) {
                var filtro = (filtros[j].value || '').toLowerCase().trim();
                if (!filtro) continue;

                var td = tr.children[j];
                var texto = td ? (td.textContent || '').toLowerCase() : '';
                if (texto.indexOf(filtro) === -1) {
                    visivel = false;
                    break;
                }
            }

            tr.style.display = visivel ? '' : 'none';
        }
    }

    function mostrarDetalheNotas(titulo, filtro) {
        var card = document.getElementById('cardDetalheNotas');
        var tituloNode = document.getElementById('detalheNotasTitulo');
        var tabelaWrap = document.getElementById('detalheNotasTabela');
        if (!card || !tituloNode || !tabelaWrap) return;

        var linhas = detalhesNotas.filter(filtro);
        tituloNode.textContent = titulo + ' - ' + formatNumber(linhas.length) + ' registro(s)';
        tabelaWrap.innerHTML = '';

        if (!linhas.length) {
            var vazio = document.createElement('div');
            vazio.className = 'empty-detail';
            vazio.textContent = 'Nenhuma nota encontrada para este recorte.';
            tabelaWrap.appendChild(vazio);
            card.classList.add('is-open');
            card.scrollIntoView({ behavior: 'smooth', block: 'start' });
            return;
        }

        var table = document.createElement('table');
        table.className = 'data-table';
        var thead = document.createElement('thead');
        thead.innerHTML =
            '<tr><th>NUNOTA</th><th>CODEMP</th><th>RAZAOSOCIAL</th><th>SERVICO</th><th class="align-right">VLRNOTA</th></tr>' +
            '<tr class="filter-row">' +
            '<th><input class="column-filter" type="text" placeholder="Filtrar nota"></th>' +
            '<th><input class="column-filter" type="text" placeholder="Filtrar empresa"></th>' +
            '<th><input class="column-filter" type="text" placeholder="Filtrar razao"></th>' +
            '<th><input class="column-filter" type="text" placeholder="Filtrar servico"></th>' +
            '<th><input class="column-filter" type="text" placeholder="Filtrar valor"></th>' +
            '</tr>';
        table.appendChild(thead);

        var tbody = document.createElement('tbody');
        linhas.forEach(function (row) {
            var tr = document.createElement('tr');

            var tdNota = document.createElement('td');
            var link = document.createElement('a');
            link.href = '#';
            link.className = 'nota-link';
            link.textContent = row.nunota;
            link.setAttribute('data-nunota', row.nunota);
            link.onclick = function (event) {
                if (event && event.preventDefault) event.preventDefault();
                abrirNotaCentral(this.getAttribute('data-nunota'));
                return false;
            };
            tdNota.appendChild(link);

            tr.appendChild(tdNota);
            tr.appendChild(criarCelula(row.codemp));
            tr.appendChild(criarCelula(row.razaosocial));
            tr.appendChild(criarCelula(row.servico));
            tr.appendChild(criarCelula('R$ ' + row.vlrnota, 'align-right'));
            tbody.appendChild(tr);
        });

        table.appendChild(tbody);
        tabelaWrap.appendChild(table);

        var filtros = table.querySelectorAll('.column-filter');
        for (var i = 0; i < filtros.length; i++) {
            filtros[i].onkeyup = function () { aplicarFiltrosTabela(table); };
            filtros[i].onchange = function () { aplicarFiltrosTabela(table); };
        }

        card.classList.add('is-open');
        card.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }

    function mostrarDetalheMes(mes, origem) {
        mostrarDetalheNotas(origem + ' - ' + mes, function (row) {
            return row.mes === mes;
        });
    }

    function mostrarDetalheServico(codprod, servico) {
        mostrarDetalheNotas('Servico - ' + servico, function (row) {
            return row.codprod === String(codprod);
        });
    }

    document.addEventListener('DOMContentLoaded', function () {

        if (typeof Highcharts === 'undefined') {
            document.getElementById('chartFaturamento').innerHTML =
                '<div style="padding:20px;color:#b91c1c;font-weight:700;">Highcharts não carregou.</div>';

            document.getElementById('chartEvolucao').innerHTML =
                '<div style="padding:20px;color:#b91c1c;font-weight:700;">Highcharts não carregou.</div>';

            document.getElementById('chartPizza').innerHTML =
                '<div style="padding:20px;color:#b91c1c;font-weight:700;">Highcharts não carregou.</div>';

            return;
        }

        Highcharts.setOptions({
            chart: { animation: false },
            plotOptions: { series: { animation: false } },
            accessibility: { enabled: false }
        });

        var kpiNode = document.getElementById('dados-kpi');

        var totalFat = toNumber(kpiNode ? kpiNode.getAttribute('data-total-fat') : 0);
        var qtdServicos = toNumber(kpiNode ? kpiNode.getAttribute('data-qtd-servicos') : 0);
        var qtdTotal = toNumber(kpiNode ? kpiNode.getAttribute('data-qtd-total') : 0);

        document.getElementById('kpiFaturamento').innerText = formatBRL(totalFat);
        document.getElementById('kpiServicos').innerText = formatNumber(qtdServicos);
        document.getElementById('kpiQuantidade').innerText = formatNumber(qtdTotal);

        var fatCats = [];
        var fatData = [];

        document.querySelectorAll('#dados-faturamento .fat-row').forEach(function (el) {
            fatCats.push(el.getAttribute('data-mes') || '');
            fatData.push(toNumber(el.getAttribute('data-valor')));
        });

        var evCats = [];
        var evTotal = [];
        var evTicket = [];
        var evNotas = [];

        document.querySelectorAll('#dados-evolucao .ev-row').forEach(function (el) {
            evCats.push(el.getAttribute('data-mes') || '');
            evTotal.push(toNumber(el.getAttribute('data-total')));
            evTicket.push(toNumber(el.getAttribute('data-ticket')));
            evNotas.push(toNumber(el.getAttribute('data-notas')));
        });

        var pizzaData = [];

        document.querySelectorAll('#dados-pizza .pizza-row').forEach(function (el) {
            var nome = (el.textContent || '').trim();

            pizzaData.push({
                name: nome,
                y: toNumber(el.getAttribute('data-qtd')),
                codprod: el.getAttribute('data-codprod') || ''
            });
        });

        detalhesNotas = [];
        document.querySelectorAll('#dados-detalhe-notas .nota-detalhe-row').forEach(function (el) {
            detalhesNotas.push({
                mes: el.getAttribute('data-mes') || '',
                nunota: el.getAttribute('data-nunota') || '',
                codemp: el.getAttribute('data-codemp') || '',
                razaosocial: el.getAttribute('data-razaosocial') || '',
                codprod: el.getAttribute('data-codprod') || '',
                servico: (el.textContent || '').trim(),
                vlrnota: el.getAttribute('data-vlrnota') || '0,00'
            });
        });

        Highcharts.chart('chartFaturamento', Highcharts.merge(hcBase(), {
            chart: {
                type: 'areaspline',
                backgroundColor: 'transparent'
            },
            xAxis: {
                categories: fatCats,
                labels: { style: { color: '#8a97a8' } }
            },
            tooltip: {
                pointFormatter: function () {
                    return '<b>' + formatBRL(this.y) + '</b>';
                }
            },
            plotOptions: {
                areaspline: {
                    fillOpacity: .12,
                    marker: { enabled: true, radius: 4 },
                    lineWidth: 3,
                    cursor: 'pointer',
                    point: {
                        events: {
                            click: function () {
                                mostrarDetalheMes(this.category, 'Faturamento');
                            }
                        }
                    }
                }
            },
            series: [{
                name: 'Faturamento',
                data: fatData,
                color: '#21a366'
            }]
        }));

        Highcharts.chart('chartEvolucao', Highcharts.merge(hcBase(), {
            chart: {
                type: 'column',
                backgroundColor: 'transparent'
            },
            xAxis: {
                categories: evCats,
                labels: { style: { color: '#8a97a8' } }
            },
            yAxis: [{
                title: { text: null },
                labels: { style: { color: '#8a97a8' } },
                gridLineColor: '#edf1f6'
            }, {
                title: { text: null },
                opposite: true,
                labels: { style: { color: '#8a97a8' } }
            }],
            tooltip: { shared: true },
            plotOptions: {
                series: {
                    cursor: 'pointer',
                    point: {
                        events: {
                            click: function () {
                                mostrarDetalheMes(this.category, this.series.name);
                            }
                        }
                    }
                }
            },
            series: [{
                name: 'Total',
                type: 'column',
                data: evTotal,
                color: '#21a366',
                tooltip: { valuePrefix: 'R$ ' }
            }, {
                name: 'Ticket Médio',
                type: 'spline',
                yAxis: 1,
                data: evTicket,
                color: '#2563eb'
            }, {
                name: 'Notas',
                type: 'spline',
                yAxis: 1,
                data: evNotas,
                color: '#f59e0b',
                visible: false
            }]
        }));

        Highcharts.chart('chartPizza', Highcharts.merge(hcBase(), {
            chart: {
                type: 'pie',
                backgroundColor: 'transparent'
            },
            tooltip: {
                pointFormat: '<b>{point.y:,.0f}</b> ({point.percentage:.1f}%)'
            },
            plotOptions: {
                pie: {
                    innerSize: '58%',
                    borderWidth: 0,
                    cursor: 'pointer',
                    dataLabels: { enabled: false },
                    point: {
                        events: {
                            click: function () {
                                mostrarDetalheServico(this.codprod, this.name);
                            }
                        }
                    }
                }
            },
            series: [{
                name: 'Quantidade',
                data: pizzaData
            }]
        }));

    });
</script>

</body>
</html>
