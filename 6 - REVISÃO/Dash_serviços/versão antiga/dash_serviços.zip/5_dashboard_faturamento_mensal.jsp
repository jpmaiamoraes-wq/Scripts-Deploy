<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false"%>
<%@ taglib uri="http://java.sun.com/jstl/core_rt" prefix="c" %>
<%@ taglib prefix="snk" uri="/WEB-INF/tld/sankhyaUtil.tld" %>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Evolução de Faturamento</title>
    <script src="https://code.highcharts.com/highcharts.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" rel="stylesheet">
    <snk:load/>
    <style>

        :root {
            --bg-page: #1a202c;
            --bg-card: #2d3748;
            --text-primary: #ffffff;
            --text-muted: #a0aec0;
            --brand-color: #38a169;
            --brand-blue: #4299e1;
            --danger: #f56565;
            --warning: #ecc94b;
            --border-soft: #4a5568;
        }
        * { box-sizing: border-box; }
        body { color: var(--text-primary); font-family: "Segoe UI", sans-serif; background-color: var(--bg-page); margin: 0; padding: 20px; }
        .header-analise { background-color: var(--bg-card); padding: 15px 20px; border-left: 6px solid var(--brand-color); box-shadow: 0 2px 4px rgba(0,0,0,.2); margin-bottom: 20px; border-radius: 4px; }
        .header-analise h2 { margin: 0; color: var(--text-primary); font-size: 22px; }
        .header-analise p { margin: 6px 0 0 0; color: var(--text-muted); }
        .dashboard-grid { display: grid; grid-template-columns: repeat(12, 1fr); gap: 20px; align-items: stretch; }
        .content-card { background: var(--bg-card); padding: 20px; border-radius: 12px; border: 1px solid var(--border-soft); box-shadow: 0 4px 6px -1px rgba(0,0,0,.2); min-width: 0; }
        .span-12 { grid-column: span 12; } .span-8 { grid-column: span 8; } .span-6 { grid-column: span 6; } .span-4 { grid-column: span 4; } .span-3 { grid-column: span 3; }
        h3 { font-size: 16px; margin: 0 0 15px 0; color: var(--brand-color); display: flex; align-items: center; gap: 8px; }
        .kpi-card { display: flex; flex-direction: column; justify-content: center; min-height: 120px; }
        .kpi-label { color: var(--text-muted); font-size: 12px; text-transform: uppercase; letter-spacing: .05em; margin-bottom: 8px; }
        .kpi-value { font-size: 30px; font-weight: 700; color: var(--text-primary); word-break: break-word; }
        .table-wrapper { max-height: 520px; overflow: auto; margin-top: 10px; border: 1px solid var(--border-soft); border-radius: 8px; }
        .table-wrapper::-webkit-scrollbar { width: 10px; height: 10px; }
        .table-wrapper::-webkit-scrollbar-track { background: #2d3748; border-radius: 8px; }
        .table-wrapper::-webkit-scrollbar-thumb { background: #4a5568; border-radius: 10px; }
        .table-wrapper::-webkit-scrollbar-thumb:hover { background: #718096; }
        .data-table { width: 100%; border-collapse: collapse; }
        .data-table th { position: sticky; top: 0; background: #1a202c; text-align: left; padding: 12px; color: var(--text-muted); border-bottom: 2px solid var(--border-soft); font-size: 11px; text-transform: uppercase; white-space: nowrap; z-index: 1; }
        .data-table td { padding: 10px 12px; border-bottom: 1px solid var(--border-soft); font-size: 13px; vertical-align: top; }
        .align-right { text-align: right; }
        .chart-box { height: 420px; }
        .note-box { color: var(--text-muted); font-size: 13px; line-height: 1.5; }
        @media (max-width: 1100px) { .span-8,.span-6,.span-4,.span-3 { grid-column: span 12; } body { padding: 12px; } }

    </style>
</head>
<body>
    <div class="header-analise">
        <h2>Evolução de Faturamento</h2>
        <p><i class="fa-regular fa-calendar-days"></i> Período: <b>:P_DATA_INI</b> até <b>:P_DATA_FIM</b></p>
    </div>

    <snk:query var="q_grd_fat_mensal">
SELECT TO_CHAR(TRUNC(CAB.DTNEG,'MM'),'MM/YYYY') MES_ANO, SUM(ITE.VLRTOT) VALOR FROM TGFCAB CAB INNER JOIN TGFITE ITE ON ITE.NUNOTA = CAB.NUNOTA INNER JOIN TGFPRO PRO ON PRO.CODPROD = ITE.CODPROD INNER JOIN TGFPAR PAR ON CAB.CODPARC = PAR.CODPARC INNER JOIN TSIEND EDN ON PAR.CODEND = EDN.CODEND INNER JOIN TSICID CID ON PAR.CODCID = CID.CODCID INNER JOIN TSIUFS UFS ON CID.UF = UFS.CODUF WHERE CAB.STATUSNOTA='L' AND CAB.TIPMOV='V' AND PRO.USOPROD='S' AND (CAB.DTNEG >= :P_DATA_INI OR :P_DATA_INI IS NULL) AND (CAB.DTNEG <= :P_DATA_FIM OR :P_DATA_FIM IS NULL) AND (:P_UF IS NULL OR UFS.CODUF IN (:P_UF)) AND (:P_TOP IS NULL OR CAB.CODTIPOPER IN (:P_TOP)) AND (:P_EMPRESA IS NULL OR CAB.CODEMP IN (:P_EMPRESA)) GROUP BY TRUNC(CAB.DTNEG,'MM') ORDER BY TRUNC(CAB.DTNEG,'MM')
    </snk:query>

    <snk:query var="q_cht_evolucao_fat">
SELECT TO_CHAR(TRUNC(CAB.DTNEG,'MM'),'MM/YYYY') MES_ANO, SUM(ITE.VLRTOT) VALOR FROM TGFCAB CAB INNER JOIN TGFITE ITE ON ITE.NUNOTA = CAB.NUNOTA INNER JOIN TGFPRO PRO ON PRO.CODPROD = ITE.CODPROD INNER JOIN TGFPAR PAR ON CAB.CODPARC = PAR.CODPARC INNER JOIN TSIEND EDN ON PAR.CODEND = EDN.CODEND INNER JOIN TSICID CID ON PAR.CODCID = CID.CODCID INNER JOIN TSIUFS UFS ON CID.UF = UFS.CODUF WHERE CAB.STATUSNOTA='L' AND CAB.TIPMOV='V' AND PRO.USOPROD='S' AND (CAB.DTNEG >= :P_DATA_INI OR :P_DATA_INI IS NULL) AND (CAB.DTNEG <= :P_DATA_FIM OR :P_DATA_FIM IS NULL) AND (:P_UF IS NULL OR UFS.CODUF IN (:P_UF)) AND (:P_TOP IS NULL OR CAB.CODTIPOPER IN (:P_TOP)) AND (:P_EMPRESA IS NULL OR CAB.CODEMP IN (:P_EMPRESA)) GROUP BY TRUNC(CAB.DTNEG,'MM') ORDER BY TRUNC(CAB.DTNEG,'MM')
    </snk:query>

    <div class="dashboard-grid">
        <div class="content-card span-6">
            <h3><i class="fa-solid fa-table-list"></i> grd_fat_mensal</h3>
            <div class="table-wrapper">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Mês/Ano</th>
                            <th>Faturamento</th>
                        </tr>
                    </thead>
                    <tbody>
                        <c:forEach items="${q_grd_fat_mensal.rows}" var="row">
                        <tr>
                            <td>${row.MES_ANO}</td>
                            <td>${row.VALOR}</td>
                        </tr>
                        </c:forEach>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="content-card span-6">
            <h3><i class="fa-solid fa-chart-column"></i> Evolução de Faturamento</h3>
            <div id="cht_evolucao_fat_chart" class="chart-box"></div>
        </div>
    </div>

        <script>
        document.addEventListener('DOMContentLoaded', function() {
            const cats_cht_evolucao_fat = [];
            const data_cht_evolucao_fat_0 = [];
            <c:forEach items="${q_cht_evolucao_fat.rows}" var="row">
                cats_cht_evolucao_fat.push('<c:out value="${row.MES_ANO}"/>');
                data_cht_evolucao_fat_0.push(parseFloat('${row.VALOR}'.replace(',', '.')) || 0);
            </c:forEach>
            Highcharts.chart('cht_evolucao_fat_chart', {
                chart: { type: 'line', backgroundColor: 'transparent' },
                accessibility: { enabled: false },
                title: { text: null },
                xAxis: { categories: cats_cht_evolucao_fat, labels: { style: { color: '#ffffff' } } },
                yAxis: { title: { text: null }, labels: { style: { color: '#ffffff' } }, gridLineColor: '#4a5568' },
                legend: { itemStyle: { color: '#ffffff' }, itemHoverStyle: { color: '#38a169' } },
                tooltip: { shared: true },
                plotOptions: { series: { dataLabels: { enabled: true, style: { color: '#ffffff', textOutline: 'none' } } } },
                series: [
                    { name: 'Faturamento', type: 'line', data: data_cht_evolucao_fat_0 }
                ],
                credits: { enabled: false }
            });
        });
        </script>
</body>
</html>
