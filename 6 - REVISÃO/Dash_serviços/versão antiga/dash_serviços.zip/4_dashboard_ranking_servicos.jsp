<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false"%>
<%@ taglib uri="http://java.sun.com/jstl/core_rt" prefix="c" %>
<%@ taglib prefix="snk" uri="/WEB-INF/tld/sankhyaUtil.tld" %>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Dashboard - Ranking de Serviços</title>
    <script src="https://code.highcharts.com/highcharts.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" rel="stylesheet">
    <snk:load/>

    <style>
        :root {
            --bg-page: #1a202c;
            --bg-card: #2d3748;
            --text-primary: #ffffff;
            --text-muted: #a0aec0;
            --brand-color: #38a169;
            --blue-chart: #4299e1;
            --border-soft: #4a5568;
        }

        body {
            color: var(--text-primary);
            font-family: "Segoe UI", sans-serif;
            background-color: var(--bg-page);
            margin: 0;
            padding: 20px;
        }

        .header-analise {
            background-color: var(--bg-card);
            padding: 15px 20px;
            border-left: 6px solid var(--brand-color);
            box-shadow: 0 2px 4px rgba(0,0,0,0.2);
            margin-bottom: 20px;
            border-radius: 4px;
        }

        .header-analise h2,
        .header-analise p {
            color: var(--text-primary);
            margin: 0;
        }

        .header-analise h2 {
            margin-bottom: 8px;
            font-size: 22px;
        }

        .kpi-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
            margin-bottom: 20px;
        }

        .layout-grid {
            display: grid;
            grid-template-columns: 1fr;
            gap: 20px;
        }

        .content-card,
        .kpi-card {
            background: var(--bg-card);
            padding: 20px;
            border-radius: 12px;
            border: 1px solid var(--border-soft);
            box-shadow: 0 4px 6px -1px rgba(0,0,0,0.2);
        }

        .kpi-card {
            display: flex;
            align-items: center;
            gap: 15px;
            min-height: 90px;
        }

        .kpi-icon {
            width: 48px;
            height: 48px;
            border-radius: 14px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: rgba(56, 161, 105, 0.16);
            color: var(--brand-color);
            font-size: 22px;
            flex-shrink: 0;
        }

        .kpi-label {
            color: var(--text-muted);
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: .5px;
            margin-bottom: 6px;
        }

        .kpi-value {
            color: var(--text-primary);
            font-size: 24px;
            font-weight: 700;
            line-height: 1.1;
        }

        .table-wrapper {
            height: 360px;
            overflow-y: auto;
            margin-top: 10px;
            border: 1px solid var(--border-soft);
            border-radius: 8px;
        }

        .table-wrapper::-webkit-scrollbar { width: 10px; }
        .table-wrapper::-webkit-scrollbar-track { background: #2d3748; border-radius: 8px; }
        .table-wrapper::-webkit-scrollbar-thumb { background: #4a5568; border-radius: 10px; }
        .table-wrapper::-webkit-scrollbar-thumb:hover { background: #718096; }

        .data-table {
            width: 100%;
            border-collapse: collapse;
        }

        .data-table th {
            position: sticky;
            top: 0;
            background: #1a202c;
            text-align: left;
            padding: 12px;
            color: var(--text-muted);
            border-bottom: 2px solid var(--border-soft);
            font-size: 11px;
            text-transform: uppercase;
            z-index: 1;
        }

        .data-table td {
            padding: 10px 12px;
            border-bottom: 1px solid var(--border-soft);
            font-size: 13px;
        }

        .data-table tr:hover td {
            background: rgba(255,255,255,0.03);
        }

        .align-right {
            text-align: right;
        }

        h3 {
            font-size: 16px;
            margin: 0 0 15px 0;
            color: var(--brand-color);
            display: flex;
            align-items: center;
            gap: 8px;
        }

        @media (max-width: 900px) {
            .kpi-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>

    <div class="header-analise">
        <h2>Dashboard - Ranking de Serviços</h2>
        <p><i class="fa-regular fa-calendar-days"></i> Período: <b>:P_DATA_INI</b> até <b>:P_DATA_FIM</b></p>
    </div>

    <%-- KPIs principais --%>
    <snk:query var="kpi_servicos">
        SELECT
            NVL(SUM(ITE.VLRTOT), 0) AS TOTAL_FAT,
            COUNT(DISTINCT ITE.CODPROD) AS QTD_SERVICOS,
            NVL(SUM(ITE.QTDNEG), 0) AS QTD_TOTAL
        FROM TGFITE ITE
        INNER JOIN TGFCAB CAB ON ITE.NUNOTA = CAB.NUNOTA
        INNER JOIN TGFPRO PRO ON ITE.CODPROD = PRO.CODPROD
        INNER JOIN TGFPAR PAR ON CAB.CODPARC = PAR.CODPARC
        INNER JOIN TSICID CID ON PAR.CODCID = CID.CODCID
        INNER JOIN TSIUFS UFS ON CID.UF = UFS.CODUF
        WHERE CAB.STATUSNOTA = 'L'
          AND PRO.USOPROD = 'S'
          AND CAB.TIPMOV = 'V'
          AND (CAB.DTNEG >= :P_DATA_INI OR :P_DATA_INI IS NULL)
          AND (CAB.DTNEG <= :P_DATA_FIM OR :P_DATA_FIM IS NULL)
          AND (:P_UF IS NULL OR UFS.CODUF IN (:P_UF))
          AND (:P_TOP IS NULL OR CAB.CODTIPOPER IN (:P_TOP))
          AND (:P_EMPRESA IS NULL OR CAB.CODEMP IN (:P_EMPRESA))
    </snk:query>

    <%-- Ranking e grid de serviços --%>
    <snk:query var="servicos_rank">
        SELECT
            ITE.CODPROD,
            PRO.DESCRPROD,
            PRO.CODLST,
            SUM(ITE.QTDNEG) AS QTD,
            SUM(ITE.VLRTOT) AS TOTAL,
            (SUM(ITE.VLRTOT) / NULLIF(SUM(SUM(ITE.VLRTOT)) OVER(), 0)) * 100 AS PERC
        FROM TGFITE ITE
        INNER JOIN TGFCAB CAB ON ITE.NUNOTA = CAB.NUNOTA
        INNER JOIN TGFPRO PRO ON ITE.CODPROD = PRO.CODPROD
        INNER JOIN TGFPAR PAR ON CAB.CODPARC = PAR.CODPARC
        INNER JOIN TSICID CID ON PAR.CODCID = CID.CODCID
        INNER JOIN TSIUFS UFS ON CID.UF = UFS.CODUF
        WHERE CAB.STATUSNOTA = 'L'
          AND PRO.USOPROD = 'S'
          AND CAB.TIPMOV = 'V'
          AND (CAB.DTNEG >= :P_DATA_INI OR :P_DATA_INI IS NULL)
          AND (CAB.DTNEG <= :P_DATA_FIM OR :P_DATA_FIM IS NULL)
          AND (:P_UF IS NULL OR UFS.CODUF IN (:P_UF))
          AND (:P_TOP IS NULL OR CAB.CODTIPOPER IN (:P_TOP))
          AND (:P_EMPRESA IS NULL OR CAB.CODEMP IN (:P_EMPRESA))
        GROUP BY ITE.CODPROD, PRO.DESCRPROD, PRO.CODLST
        ORDER BY TOTAL DESC
    </snk:query>

    <div class="kpi-grid">
        <c:forEach items="${kpi_servicos.rows}" var="kpi">
            <div class="kpi-card">
                <div class="kpi-icon"><i class="fa-solid fa-sack-dollar"></i></div>
                <div>
                    <div class="kpi-label">Faturamento Total</div>
                    <div class="kpi-value">R$ ${kpi.TOTAL_FAT}</div>
                </div>
            </div>

            <div class="kpi-card">
                <div class="kpi-icon"><i class="fa-solid fa-briefcase"></i></div>
                <div>
                    <div class="kpi-label">Serviços</div>
                    <div class="kpi-value">${kpi.QTD_SERVICOS}</div>
                </div>
            </div>

            <div class="kpi-card">
                <div class="kpi-icon"><i class="fa-solid fa-layer-group"></i></div>
                <div>
                    <div class="kpi-label">Quantidade Total</div>
                    <div class="kpi-value">${kpi.QTD_TOTAL}</div>
                </div>
            </div>
        </c:forEach>
    </div>

    <div class="layout-grid">
        <div class="content-card">
            <h3><i class="fa-solid fa-chart-column"></i> Top 10 Serviços por Faturamento</h3>
            <div id="grafico_servicos" style="height: 360px;"></div>
        </div>

        <div class="content-card">
            <h3><i class="fa-solid fa-table-list"></i> Detalhamento dos Serviços</h3>
            <div class="table-wrapper">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Cód. Serviço</th>
                            <th>Descrição do Serviço</th>
                            <th>Tipo de Serviço</th>
                            <th class="align-right">Qtd Vendida</th>
                            <th class="align-right">Faturamento</th>
                            <th class="align-right">%</th>
                        </tr>
                    </thead>
                    <tbody>
                        <c:forEach items="${servicos_rank.rows}" var="row">
                            <tr>
                                <td>${row.CODPROD}</td>
                                <td>${row.DESCRPROD}</td>
                                <td>${row.CODLST}</td>
                                <td class="align-right">${row.QTD}</td>
                                <td class="align-right">R$ ${row.TOTAL}</td>
                                <td class="align-right">${row.PERC}%</td>
                            </tr>
                        </c:forEach>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const servicos = [];
            const valores = [];

            <c:forEach items="${servicos_rank.rows}" var="row" varStatus="loop">
                <c:if test="${loop.index < 10}">
                    servicos.push('${row.DESCRPROD}'.substring(0, 30));
                    valores.push(parseFloat('${row.TOTAL}'));
                </c:if>
            </c:forEach>

            Highcharts.chart('grafico_servicos', {
                chart: {
                    type: 'column',
                    backgroundColor: 'transparent'
                },
                accessibility: { enabled: false },
                title: { text: null },
                xAxis: {
                    categories: servicos,
                    labels: {
                        style: { color: '#ffffff' },
                        rotation: -35
                    }
                },
                yAxis: {
                    title: { text: null },
                    labels: { style: { color: '#ffffff' } },
                    gridLineColor: '#4a5568'
                },
                legend: { enabled: false },
                tooltip: {
                    pointFormat: '<b>R$ {point.y:,.2f}</b>'
                },
                plotOptions: {
                    column: {
                        color: '#4299e1',
                        borderWidth: 0,
                        borderRadius: 4,
                        dataLabels: {
                            enabled: true,
                            format: 'R$ {point.y:,.2f}',
                            style: {
                                color: '#ffffff',
                                textOutline: 'none'
                            }
                        }
                    }
                },
                series: [{
                    name: 'Faturamento',
                    data: valores
                }],
                credits: { enabled: false }
            });
        });
    </script>
</body>
</html>
