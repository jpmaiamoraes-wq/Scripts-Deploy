<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false"%>
<%@ taglib uri="http://java.sun.com/jstl/core_rt" prefix="c" %>
<%@ taglib prefix="snk" uri="/WEB-INF/tld/sankhyaUtil.tld" %>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Análise de ISS por Município</title>
    <script src="https://code.highcharts.com/highcharts.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" rel="stylesheet">
    <snk:load/>

    <style>
        :root {
            --bg-page: #1a202c;         /* Fundo principal: azul-cinza escuro */
            --bg-card: #2d3748;         /* Fundo dos cards: um tom mais claro */
            --text-primary: #ffffff;    /* Texto principal: branco */
            --brand-color: #38a169;      /* Destaques: verde brilhante */
            --border-soft: #4a5568;      /* Bordas: cinza sutil */
        }

        body {
            color: var(--text-primary);
            font-family: "Segoe UI", sans-serif;
            background-color: var(--bg-page);
            margin: 0;
            padding: 20px;
        }

        .header-analise {
            background-color: var(--bg-card);
            padding: 15px 20px;
            border-left: 6px solid var(--brand-color);
            box-shadow: 0 2px 4px rgba(0,0,0,0.2);
            margin-bottom: 20px;
            border-radius: 4px;
        }
        
        .header-analise h2, .header-analise p {
             color: var(--text-primary);
        }

        .layout-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }

        .content-card {
            background: var(--bg-card);
            padding: 20px;
            border-radius: 12px;
            border: 1px solid var(--border-soft);
            box-shadow: 0 4px 6px -1px rgba(0,0,0,0.2);
        }

        .table-wrapper {
            height: 350px;
            overflow-y: auto;
            margin-top: 10px;
            border: 1px solid var(--border-soft);
            border-radius: 8px;
        }
        
        /* Estilização da Scrollbar */
        .table-wrapper::-webkit-scrollbar { width: 10px; }
        .table-wrapper::-webkit-scrollbar-track { background: #2d3748; border-radius: 8px; }
        .table-wrapper::-webkit-scrollbar-thumb { background: #4a5568; border-radius: 10px; }
        .table-wrapper::-webkit-scrollbar-thumb:hover { background: #718096; }


        .data-table {
            width: 100%;
            border-collapse: collapse;
        }

        .data-table th {
            position: sticky;
            top: 0;
            background: #1a202c; /* Fundo do cabeçalho da tabela */
            text-align: left;
            padding: 12px;
            color: #a0aec0; /* Cor do texto do cabeçalho */
            border-bottom: 2px solid var(--border-soft);
            font-size: 11px;
            text-transform: uppercase;
        }

        .data-table td {
            padding: 10px 12px;
            border-bottom: 1px solid var(--border-soft);
            font-size: 13px;
        }

        .align-right {
            text-align: right;
        }

        .perc-tag {
            background: var(--brand-color); /* Fundo da tag de % */
            color: var(--text-primary); /* Texto da tag de % */
            padding: 3px 8px;
            border-radius: 12px;
            font-weight: bold;
            font-size: 11px;
        }

        h3 {
            font-size: 16px;
            margin: 0 0 15px 0;
            color: var(--brand-color); /* Cor dos títulos dos cards */
            display: flex;
            align-items: center;
            gap: 8px;
        }
    </style>
</head>
<body>

    <div class="header-analise">
        <h2>Análise de ISS por Município</h2>
        <p><i class="fa-regular fa-calendar-days"></i> Período: <b>:P_DATA_INI</b> até <b>:P_DATA_FIM</b></p>
    </div>

    <%-- 
       Ajuste Crítico: Usamos filtros que aceitam nulo ou múltiplos valores de forma segura.
       Se o parâmetro estiver vazio, a condição (1=1) ou o tratamento de string evita o erro 500.
    --%>
    <snk:query var="iss_municipios">
        SELECT NOMECID, UF, VALOR_ISS, (VALOR_ISS / NULLIF(SUM(VALOR_ISS) OVER(), 0)) * 100 AS PERC 
        FROM ( 
            SELECT CID.NOMECID, UFS.UF, SUM(ITE.VLRISS) AS VALOR_ISS 
            FROM TGFITE ITE 
            INNER JOIN TGFCAB CAB ON ITE.NUNOTA = CAB.NUNOTA 
            INNER JOIN TSICID CID ON CAB.CODCIDPREST = CID.CODCID 
            INNER JOIN TSIUFS UFS ON CID.UF = UFS.CODUF 
            INNER JOIN TGFPRO PRO ON ITE.CODPROD = PRO.CODPROD 
            WHERE CAB.STATUSNOTA = 'L' AND PRO.USOPROD = 'S' 
            AND (CAB.DTNEG >= :P_DATA_INI OR :P_DATA_INI IS NULL) 
            AND (CAB.DTNEG <= :P_DATA_FIM OR :P_DATA_FIM IS NULL) 
            <%-- Filtros tratados para evitar 'empty argument' --%>
            AND (:P_EMPRESA IS NULL OR CAB.CODEMP IN (:P_EMPRESA))
            AND (:P_UF IS NULL OR UFS.CODUF IN (:P_UF))
            AND (:P_TOP IS NULL OR CAB.CODTIPOPER IN (:P_TOP))
            GROUP BY CID.NOMECID, UFS.UF 
            HAVING SUM(ITE.VLRISS) > 0 
        ) ORDER BY VALOR_ISS DESC
    </snk:query>

    <div class="layout-grid">
        <div class="content-card">
            <h3><i class="fa-solid fa-chart-column"></i> TOP 10 Cidades (ISS)</h3>
            <div id="grafico_iss" style="height: 350px;"></div>
        </div>

        <div class="content-card">
            <h3><i class="fa-solid fa-table-list"></i> Detalhamento por Município</h3>
            <div class="table-wrapper">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Cidade</th>
                            <th>UF</th>
                            <th class="align-right">ISS Retido</th>
                            <th class="align-right">%</th>
                        </tr>
                    </thead>
                    <tbody>
                        <c:forEach items="${iss_municipios.rows}" var="row">
                            <tr>
                                <td>${row.NOMECID}</td>
                                <td>${row.UF}</td>
                                <td class="align-right">R$ ${row.VALOR_ISS}</td>
                                <td class="align-right"><span class="perc-tag">${row.PERC}%</span></td>
                            </tr>
                        </c:forEach>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const cidades = [];
            const valores = [];

            <c:forEach items="${iss_municipios.rows}" var="row" varStatus="loop">
                <c:if test="${loop.index < 10}">
                    cidades.push('${row.NOMECID}');
                    valores.push(parseFloat('${row.VALOR_ISS}'));
                </c:if>
            </c:forEach>

            Highcharts.chart('grafico_iss', {
                chart: { type: 'column', backgroundColor: 'transparent' },
                accessibility: { enabled: false },
                title: { text: null },
                xAxis: {
                    categories: cidades,
                    labels: { style: { color: '#ffffff' } } /* Cor do texto do eixo X */
                },
                yAxis: {
                    title: { text: null },
                    labels: { style: { color: '#ffffff' } }, /* Cor do texto do eixo Y */
                    gridLineColor: '#4a5568' /* Cor das linhas do grid */
                },
                legend: { enabled: false },
                plotOptions: {
                    column: {
                        color: '#4299e1', /* Cor das barras: azul médio */
                        dataLabels: {
                            enabled: true,
                            format: '{point.y:,.2f}',
                            style: {
                                color: '#ffffff',
                                textOutline: 'none' /* Remove contorno do texto */
                            }
                        }
                    }
                },
                series: [{ name: 'ISS', data: valores }],
                credits: { enabled: false }
            });
        });
    </script>
</body>
</html>
