<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored ="false"%>
<%@ taglib prefix="snk" uri="/WEB-INF/tld/sankhyaUtil.tld" %>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <snk:load/>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel de Serviços</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --bg-page: #0f1724;
            --bg-card: #202c3d;
            --bg-card-hover: #243247;
            --text-primary: #f4f7fb;
            --text-secondary: #b2bfce;
            --text-muted: #8091a6;
            --brand-green: #66cc66;
            --status-blue: #3b82f6;
            --status-green: #22c55e;
            --status-yellow: #f59e0b;
            --status-red: #ef4444;
            --status-purple: #8b5cf6;
            --border-soft: rgba(106, 129, 158, 0.22);
            --border-strong: rgba(130, 156, 188, 0.3);
            --shadow-panel: 0 18px 44px rgba(1, 10, 20, 0.34);
            --shadow-card: 0 12px 26px rgba(2, 10, 18, 0.22);
            --shadow-card-hover: 0 16px 34px rgba(2, 10, 18, 0.3);
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        html {
            font-size: 16px;
        }

        body {
            min-height: 100vh;
            margin: 0;
            padding: 0;
            color: var(--text-primary);
            font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
            background:
                radial-gradient(circle at top right, rgba(102, 204, 102, 0.08), transparent 22%),
                radial-gradient(circle at top left, rgba(59, 130, 246, 0.1), transparent 30%),
                linear-gradient(180deg, #0d141f 0%, var(--bg-page) 100%);
        }

        .page-shell {
            width: calc(100% - 32px);
            max-width: 1440px;
            margin: 20px auto;
            padding: 18px 18px 24px;
            background: linear-gradient(180deg, rgba(20, 31, 46, 0.98), rgba(14, 22, 33, 0.98));
            border: 1px solid rgba(77, 96, 121, 0.32);
            border-radius: 28px;
            box-shadow: var(--shadow-panel);
        }

        .header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 20px;
            padding: 14px 18px 22px;
            border-bottom: 1px solid rgba(93, 115, 143, 0.18);
        }

        .header-brand {
            display: flex;
            align-items: center;
            gap: 14px;
            min-width: 0;
        }

        .brand-mark {
            width: 48px;
            height: 48px;
            border-radius: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(160deg, rgba(102, 204, 102, 0.18), rgba(43, 92, 138, 0.28));
            color: var(--brand-green);
            box-shadow: inset 0 0 0 1px rgba(102, 204, 102, 0.18);
        }

        .brand-mark i {
            font-size: 22px;
        }

        .header-copy h1 {
            font-size: 30px;
            line-height: 1.15;
            font-weight: 700;
            letter-spacing: -0.02em;
            color: var(--text-primary);
        }

        .header-copy p {
            margin-top: 6px;
            font-size: 15px;
            line-height: 1.45;
            color: var(--text-secondary);
        }

        .header-metrics {
            display: grid;
            grid-template-columns: repeat(3, minmax(150px, 1fr));
            gap: 12px;
            flex: 1;
            max-width: 600px;
        }

        .metric-pill {
            padding: 12px 16px;
            border-radius: 18px;
            border: 1px solid var(--border-soft);
            background: linear-gradient(180deg, rgba(24, 36, 52, 0.98), rgba(17, 26, 39, 0.98));
        }

        .metric-pill span {
            display: block;
            font-size: 11px;
            letter-spacing: 0.14em;
            text-transform: uppercase;
            color: var(--text-muted);
            font-weight: 700;
        }

        .metric-pill strong {
            display: block;
            margin-top: 6px;
            font-size: 25px;
            line-height: 1;
            color: var(--text-primary);
        }

        .metric-blue {
            border-color: rgba(59, 130, 246, 0.28);
        }

        .metric-green {
            border-color: rgba(34, 197, 94, 0.34);
        }

        .metric-purple {
            border-color: rgba(139, 92, 246, 0.34);
        }

        .section-head {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 16px;
            margin: 22px 6px 18px;
        }

        .section-title h2 {
            font-size: 16px;
            font-weight: 700;
            letter-spacing: 0.08em;
            text-transform: uppercase;
            color: var(--text-primary);
        }

        .section-title p {
            margin-top: 4px;
            font-size: 14px;
            color: var(--text-secondary);
        }

        .section-badge {
            display: inline-block;
            padding: 10px 14px;
            border-radius: 999px;
            border: 1px solid rgba(102, 204, 102, 0.24);
            background: rgba(102, 204, 102, 0.08);
            color: #cdeccd;
            font-size: 13px;
            font-weight: 600;
        }

        .card-container {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 18px;
            margin-top: 18px;
        }

        .card {
            position: relative;
            display: flex;
            align-items: flex-start;
            gap: 16px;
            min-height: 158px;
            padding: 22px 22px 20px;
            border-radius: 20px;
            background: linear-gradient(180deg, var(--bg-card) 0%, #1c2737 100%);
            border: 1px solid var(--border-soft);
            box-shadow: var(--shadow-card);
            cursor: pointer;
            overflow: hidden;
            transition: all 0.22s ease;
        }

        .card:hover {
            transform: translateY(-4px);
            background: linear-gradient(180deg, var(--bg-card-hover) 0%, #202f43 100%);
            box-shadow: var(--shadow-card-hover);
            border-color: var(--border-strong);
        }

        .card:before {
            content: "";
            position: absolute;
            left: 0;
            top: 0;
            bottom: 0;
            width: 4px;
            border-radius: 20px 0 0 20px;
            background: var(--status-blue);
        }

        .c-blue:before { background: var(--status-blue); }
        .c-green:before { background: var(--status-green); }
        .c-orange:before { background: var(--status-yellow); }
        .c-red:before { background: var(--status-red); }
        .c-purple:before { background: var(--status-purple); }

        .card-icon {
            width: 54px;
            height: 54px;
            min-width: 54px;
            border-radius: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: rgba(255, 255, 255, 0.03);
            border: 1px solid rgba(255, 255, 255, 0.05);
        }

        .card-icon i {
            font-size: 22px;
        }

        .c-blue .card-icon {
            color: var(--status-blue);
            background: rgba(59, 130, 246, 0.12);
            border-color: rgba(59, 130, 246, 0.22);
        }

        .c-green .card-icon {
            color: var(--status-green);
            background: rgba(34, 197, 94, 0.12);
            border-color: rgba(34, 197, 94, 0.22);
        }

        .c-orange .card-icon {
            color: var(--status-yellow);
            background: rgba(245, 158, 11, 0.12);
            border-color: rgba(245, 158, 11, 0.26);
        }

        .c-red .card-icon {
            color: var(--status-red);
            background: rgba(239, 68, 68, 0.12);
            border-color: rgba(239, 68, 68, 0.22);
        }

        .c-purple .card-icon {
            color: var(--status-purple);
            background: rgba(139, 92, 246, 0.12);
            border-color: rgba(139, 92, 246, 0.24);
        }

        .card-info {
            flex: 1;
            min-width: 0;
        }

        .card-topline {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 10px;
            margin-bottom: 12px;
        }

        .card-index {
            font-size: 12px;
            color: var(--text-muted);
            font-weight: 700;
            letter-spacing: 0.08em;
        }

        .tag {
            display: inline-block;
            min-height: 28px;
            padding: 5px 11px;
            border-radius: 999px;
            font-size: 11px;
            font-weight: 700;
            letter-spacing: 0.06em;
            text-transform: uppercase;
            white-space: nowrap;
            border: 1px solid transparent;
        }

        .tag-blue {
            color: #cfe2ff;
            background: rgba(59, 130, 246, 0.16);
            border-color: rgba(59, 130, 246, 0.32);
        }

        .tag-green {
            color: #d0f5dd;
            background: rgba(34, 197, 94, 0.16);
            border-color: rgba(34, 197, 94, 0.3);
        }

        .tag-yellow {
            color: #fde8be;
            background: rgba(245, 158, 11, 0.18);
            border-color: rgba(245, 158, 11, 0.34);
        }

        .tag-red {
            color: #ffd7d7;
            background: rgba(239, 68, 68, 0.16);
            border-color: rgba(239, 68, 68, 0.32);
        }

        .tag-purple {
            color: #e3d8ff;
            background: rgba(139, 92, 246, 0.16);
            border-color: rgba(139, 92, 246, 0.32);
        }

        .card h3 {
            margin: 0;
            color: var(--text-primary);
            font-size: 16px;
            font-weight: 700;
            line-height: 1.35;
            word-wrap: break-word;
        }

        .card p {
            margin-top: 10px;
            color: var(--text-secondary);
            font-size: 14px;
            line-height: 1.5;
            word-wrap: break-word;
        }

        .card-meta {
            margin-top: 14px;
        }

        .card-meta .tag {
            margin-right: 8px;
            margin-bottom: 8px;
        }

        @media (max-width: 1180px) {
            .header {
                flex-direction: column;
                align-items: stretch;
            }

            .header-metrics {
                max-width: none;
            }

            .card-container {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }
        }

        @media (max-width: 760px) {
            .page-shell {
                width: calc(100% - 12px);
                margin: 6px auto;
                padding: 12px;
                border-radius: 20px;
            }

            .header {
                padding: 10px 6px 18px;
            }

            .header-copy h1 {
                font-size: 24px;
            }

            .header-copy p {
                font-size: 14px;
            }

            .header-metrics {
                grid-template-columns: 1fr;
            }

            .section-head {
                flex-direction: column;
                align-items: stretch;
            }

            .card-container {
                grid-template-columns: 1fr;
                gap: 14px;
            }

            .card {
                min-height: 0;
                padding: 18px;
            }
        }
    </style>
</head>

<body>
    <main class="page-shell">
        <header class="header">
            <div class="header-brand">
                <div class="brand-mark" aria-hidden="true">
                    <i class="fas fa-leaf"></i>
                </div>
                <div class="header-copy">
                    <h1>Painel de Serviços</h1>
                    <p>Gestão inteligente, auditoria e navegação rápida para os principais indicadores de NFS-e.</p>
                </div>
            </div>
        </header>

        <section class="card-container" aria-label="Atalhos do painel de serviços">
            <div class="card c-blue" onclick="openLevel('lvl_tomadores', {})" tabindex="0" role="button">
                <div class="card-icon" aria-hidden="true">
                    <i class="fas fa-users"></i>
                </div>
                <div class="card-info">
                    <div class="card-topline">
                        <span class="card-index">01</span>
                    </div>
                    <h3>Maiores Tomadores</h3>
                    <p>Clientes com maior faturamento de serviços no período.</p>
                </div>
            </div>

            <div class="card c-blue" onclick="openLevel('lvl_iss_municipio', {})" tabindex="0" role="button">
                <div class="card-icon" aria-hidden="true">
                    <i class="fas fa-map-marked-alt"></i>
                </div>
                <div class="card-info">
                    <div class="card-topline">
                        <span class="card-index">02</span>
                    </div>
                    <h3>ISS por Município / UF</h3>
                    <p>Distribuição geográfica e retenção do ISS por localidade.</p>
                </div>
            </div>

            <div class="card c-orange" onclick="openLevel('lvl_conferencia_top', {})" tabindex="0" role="button">
                <div class="card-icon" aria-hidden="true">
                    <i class="fas fa-exchange-alt"></i>
                </div>
                <div class="card-info">
                    <div class="card-topline">
                        <span class="card-index">03</span>
                    </div>
                    <h3>Conferência por TOP</h3>
                    <p>Resumo de faturamento por tipo de operação utilizada.</p>
                </div>
            </div>

            <div class="card c-blue" onclick="openLevel('lvl_servicos_utilizados', {})" tabindex="0" role="button">
                <div class="card-icon" aria-hidden="true">
                    <i class="fas fa-list-ol"></i>
                </div>
                <div class="card-info">
                    <div class="card-topline">
                        <span class="card-index">04</span>
                    </div>
                    <h3>Serviços Mais Utilizados</h3>
                    <p>Ranking dos códigos de serviço com maior volume.</p>
                </div>
            </div>

            <div class="card c-green" onclick="openLevel('lvl_faturamento_mensal', {})" tabindex="0" role="button">
                <div class="card-icon" aria-hidden="true">
                    <i class="fas fa-chart-bar"></i>
                </div>
                <div class="card-info">
                    <div class="card-topline">
                        <span class="card-index">05</span>
                    </div>
                    <h3>Evolução de Faturamento</h3>
                    <p>Evolução financeira e crescimento mês a mês.</p>
                </div>
            </div>

            <div class="card c-green" onclick="openLevel('lvl_ticket_medio', {})" tabindex="0" role="button">
                <div class="card-icon" aria-hidden="true">
                    <i class="fas fa-calculator"></i>
                </div>
                <div class="card-info">
                    <div class="card-topline">
                        <span class="card-index">06</span>
                    </div>
                    <h3>Ticket Médio</h3>
                    <p>Valor faturado médio por cada nota emitida.</p>
                </div>
            </div>

            <div class="card c-red" onclick="openLevel('lvl_clientes_inativos', {})" tabindex="0" role="button">
                <div class="card-icon" aria-hidden="true">
                    <i class="fas fa-user-slash"></i>
                </div>
                <div class="card-info">
                    <div class="card-topline">
                        <span class="card-index">07</span>
                    </div>
                    <h3>Clientes Inativos</h3>
                    <p>Tomadores sem faturamento de serviço recente.</p>
                </div>
            </div>

            <div class="card c-purple" onclick="openLevel('lvl_mapa_tributario', {})" tabindex="0" role="button">
                <div class="card-icon" aria-hidden="true">
                    <i class="fas fa-chart-line"></i>
                </div>
                <div class="card-info">
                    <div class="card-topline">
                        <span class="card-index">08</span>
                    </div>
                    <h3>Auditoria de Impostos - NFS-e</h3>
                    <p>PIS, COFINS, INSS, CSLL, IR e ISS em uma visão consolidada.</p>
                </div>
            </div>

            <div class="card c-orange" onclick="openLevel('lvl_servicos_sem_mov', {})" tabindex="0" role="button">
                <div class="card-icon" aria-hidden="true">
                    <i class="fas fa-box-open"></i>
                </div>
                <div class="card-info">
                    <div class="card-topline">
                        <span class="card-index">09</span>
                    </div>
                    <h3>Serviços sem Movimento</h3>
                    <p>Serviços cadastrados, mas não utilizados no período.</p>
                </div>
            </div>

            <div class="card c-green" onclick="openLevel('lvl_clientes_novos', {})" tabindex="0" role="button">
                <div class="card-icon" aria-hidden="true">
                    <i class="fas fa-user-plus"></i>
                </div>
                <div class="card-info">
                    <div class="card-topline">
                        <span class="card-index">10</span>
                    </div>
                    <h3>Clientes Novos</h3>
                    <p>Análise de entrada de novos parceiros tomadores.</p>
                </div>
            </div>

            <div class="card c-blue" onclick="openLevel('lvl_fat_cidade', {})" tabindex="0" role="button">
                <div class="card-icon" aria-hidden="true">
                    <i class="fas fa-city"></i>
                </div>
                <div class="card-info">
                    <div class="card-topline">
                        <span class="card-index">11</span>
                    </div>
                    <h3>Faturamento por Cidade / UF</h3>
                    <p>Receita segmentada pela localização do cliente.</p>
                </div>
            </div>

            <div class="card c-red" onclick="openLevel('lvl_iss_zerado', {})" tabindex="0" role="button">
                <div class="card-icon" aria-hidden="true">
                    <i class="fas fa-exclamation-triangle"></i>
                </div>
                <div class="card-info">
                    <div class="card-topline">
                        <span class="card-index">12</span>
                    </div>
                    <h3>Notas com ISS Zerado</h3>
                    <p>Auditoria de possíveis erros na tributação de serviços.</p>
                </div>
            </div>

            <div class="card c-green" onclick="openLevel('lvl_evolucao_servicos', {})" tabindex="0" role="button">
                <div class="card-icon" aria-hidden="true">
                    <i class="fas fa-chart-bar"></i>
                </div>
                <div class="card-info">
                    <div class="card-topline">
                        <span class="card-index">13</span>
                    </div>
                    <h3>Evolução de serviços</h3>
                    <p>Evolução mês a mês.</p>
                </div>
            </div>

            <div class="card c-red" onclick="openLevel('lvl_alerta_reinf', {})" tabindex="0" role="button">
                <div class="card-icon" aria-hidden="true">
                    <i class="fas fa-exclamation-triangle"></i>
                </div>
                <div class="card-info">
                    <div class="card-topline">
                        <span class="card-index">14</span>
                    </div>
                    <h3>Alerta REINF</h3>
                    <p>Cessão de mão de obra.</p>
                </div>
            </div>
        </section>
    </main>
</body>
</html>
