<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false"%>
<%@ taglib uri="http://java.sun.com/jstl/core_rt" prefix="c" %>
<%@ taglib prefix="snk" uri="/WEB-INF/tld/sankhyaUtil.tld" %>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Maiores Tomadores</title>
    <script src="https://code.highcharts.com/highcharts.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" rel="stylesheet">
    <snk:load/>

    <style>
        :root { --bg-page: #0f1724; --bg-card: #202c3d; --text-primary: #f4f7fb; --text-secondary: #b2bfce; --border-soft: rgba(106, 129, 158, 0.22); }
        body { color: var(--text-primary); font-family: "Segoe UI", sans-serif; background-color: #111827; margin: 0; padding: 20px; }
        .layout-container { display: flex; flex-direction: row; gap: 20px; }
        .content-card { flex: 1; padding: 20px; border-radius: 15px; background-color: var(--bg-card); border: 1px solid var(--border-soft); min-height: 450px; }
        .table-wrapper { height: 380px; overflow-y: auto; margin-top: 10px; }
        .data-table { width: 100%; border-collapse: collapse; }
        .data-table th { text-align: left; padding: 10px; color: var(--text-secondary); border-bottom: 2px solid var(--border-soft); font-size: 13px; }
        .data-table td { padding: 10px; border-bottom: 1px solid var(--border-soft); font-size: 14px; }
        .align-right { text-align: right; }
        h2 { font-size: 18px; margin-bottom: 15px; color: #68D391; }
    </style>
</head>
<body>

<%-- BUSCA DE DADOS - Simplificada para evitar conflitos de parâmetros --%>
<snk:query var="dadosTomadores">
    SELECT * FROM (
        SELECT 
            PAR.RAZAOSOCIAL AS CLIENTE, 
            SUM(ITE.VLRTOT) AS VALOR 
        FROM TGFCAB CAB 
        INNER JOIN TGFITE ITE ON CAB.NUNOTA = ITE.NUNOTA 
        INNER JOIN TGFPAR PAR ON CAB.CODPARC = PAR.CODPARC 
        INNER JOIN TGFPRO PRO ON ITE.CODPROD = PRO.CODPROD 
        WHERE CAB.STATUSNOTA = 'L' AND PRO.USOPROD = 'S'
        /* Filtros de data opcionais */
        AND (CAB.DTNEG >= :P_DATA_INI OR :P_DATA_INI IS NULL) 
        AND (CAB.DTNEG <= :P_DATA_FIM OR :P_DATA_FIM IS NULL)
        GROUP BY PAR.RAZAOSOCIAL 
        ORDER BY VALOR DESC
    ) WHERE ROWNUM <= 15
</snk:query>

<div class="layout-container">
    <div class="content-card">
        <h2><i class="fa-solid fa-list-ol"></i> Listagem de Tomadores</h2>
        <div class="table-wrapper">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Cliente</th>
                        <th class="align-right">Total (R$)</th>
                    </tr>
                </thead>
                <tbody>
                    <c:forEach items="${dadosTomadores.rows}" var="row">
                        <tr>
                            <td>${row.CLIENTE}</td>
                            <td class="align-right">${row.VALOR}</td>
                        </tr>
                    </c:forEach>
                </tbody>
            </table>
        </div>
    </div>

    <div class="content-card">
        <h2><i class="fa-solid fa-chart-line"></i> TOP 10 Desempenho</h2>
        <div id="grafico-neon" style="height: 380px;"></div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Extração de dados igual ao volumetria.jsp
        const categorias = [
            <c:forEach items="${dadosTomadores.rows}" var="row" varStatus="loop">
                <c:if test="${loop.index < 10}">'${row.CLIENTE}',</c:if>
            </c:forEach>
        ];
        
        const valores = [
            <c:forEach items="${dadosTomadores.rows}" var="row" varStatus="loop">
                <c:if test="${loop.index < 10}">${row.VALOR},</c:if>
            </c:forEach>
        ];

        // Construção do gráfico usando o motor que já funciona no seu ambiente
        Highcharts.chart('grafico-neon', {
            chart: { backgroundColor: 'transparent', type: 'column' },
            title: { text: null },
            xAxis: { 
                categories: categorias,
                labels: { style: { color: '#9CA3AF' } }
            },
            yAxis: { 
                title: { text: null },
                gridLineColor: '#1F2937',
                labels: { style: { color: '#9CA3AF' } }
            },
            legend: { enabled: false },
            series: [{
                name: 'Faturamento',
                data: valores,
                color: '#4F46E5',
                shadow: { color: 'rgba(79, 70, 229, 0.4)', width: 10 }
            }],
            credits: { enabled: false }
        });
    });
</script>

</body>
</html>