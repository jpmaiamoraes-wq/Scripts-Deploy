<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false"%>
<%@ taglib prefix="snk" uri="/WEB-INF/tld/sankhyaUtil.tld" %>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajuda do Painel de Serviços</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" rel="stylesheet">
    <snk:load/>
    <style>
        :root {
            --bg: #f3f6fa;
            --surface: #ffffff;
            --line: #dce4ee;
            --text: #253246;
            --muted: #718096;
            --green: #20ad68;
            --green-soft: #e8f7ef;
            --blue: #2563eb;
            --orange: #f59e0b;
            --red: #dc4c64;
        }
        * { box-sizing: border-box; }
        body { margin: 0; color: var(--text); background: var(--bg); font-family: "Segoe UI", Arial, sans-serif; }
        .top-nav { position: sticky; top: 0; z-index: 20; display: flex; align-items: center; gap: 6px; min-height: 58px; padding: 9px 18px; overflow-x: auto; background: rgba(255,255,255,.97); border-bottom: 1px solid var(--line); }
        .top-nav strong { margin-right: 10px; white-space: nowrap; }
        .top-nav button { display: inline-flex; align-items: center; gap: 7px; min-height: 34px; padding: 0 10px; border: 0; border-radius: 8px; color: #607086; background: transparent; cursor: pointer; font-weight: 700; white-space: nowrap; }
        .top-nav button:hover, .top-nav button.active { color: #087b46; background: var(--green-soft); }
        main { width: min(1280px, calc(100% - 36px)); margin: 24px auto 44px; }
        .page-head { display: flex; align-items: flex-start; justify-content: space-between; gap: 18px; padding-bottom: 20px; border-bottom: 1px solid var(--line); }
        h1 { margin: 0; font-size: 27px; }
        .lead { margin: 7px 0 0; color: var(--muted); line-height: 1.55; }
        .version { padding: 7px 10px; border: 1px solid #bfe8d1; border-radius: 8px; color: #087b46; background: var(--green-soft); font-size: 12px; font-weight: 800; white-space: nowrap; }
        .quick-nav { display: flex; flex-wrap: wrap; gap: 8px; padding: 18px 0; }
        .quick-nav a { padding: 8px 11px; border: 1px solid var(--line); border-radius: 8px; color: #53647b; background: #fff; text-decoration: none; font-size: 13px; font-weight: 700; }
        .section { padding: 24px 0; border-bottom: 1px solid var(--line); scroll-margin-top: 76px; }
        .section h2 { display: flex; align-items: center; gap: 9px; margin: 0 0 15px; font-size: 19px; }
        .section h2 i { color: var(--green); }
        .grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 12px 24px; }
        .item { padding: 15px 0; border-bottom: 1px solid #e9eef4; }
        .item h3 { margin: 0 0 7px; font-size: 14px; }
        .item p { margin: 0; color: var(--muted); font-size: 13px; line-height: 1.55; }
        .formula { display: inline-block; margin-top: 8px; padding: 6px 8px; border-radius: 6px; color: #24405f; background: #eef4fb; font-family: Consolas, monospace; font-size: 12px; }
        .abc { display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; margin-top: 13px; }
        .abc div { padding: 16px; border-left: 4px solid var(--green); background: #fff; }
        .abc div:nth-child(2) { border-color: var(--orange); }
        .abc div:nth-child(3) { border-color: var(--red); }
        .abc strong { display: block; margin-bottom: 5px; }
        .notice { padding: 14px 16px; border-left: 4px solid var(--blue); color: #3f526b; background: #eef4ff; font-size: 13px; line-height: 1.55; }
        details { border-bottom: 1px solid #e5ebf2; }
        summary { padding: 14px 0; cursor: pointer; font-weight: 800; }
        details p { margin: 0 0 15px; color: var(--muted); font-size: 13px; line-height: 1.55; }
        table { width: 100%; border-collapse: collapse; background: #fff; }
        th, td { padding: 11px 12px; border-bottom: 1px solid #e5ebf2; text-align: left; font-size: 13px; vertical-align: top; }
        th { color: #617087; background: #f7f9fc; }
        code { color: #23466c; font-family: Consolas, monospace; }
        @media (max-width: 850px) { .grid, .abc { grid-template-columns: 1fr; } main { width: min(100% - 22px, 1280px); } }
    </style>
</head>
<body>
    <nav class="top-nav" aria-label="Menu principal">
        <strong><i class="fa-solid fa-circle-question"></i> Ajuda do Painel</strong>
        <button type="button" onclick="abrirNivel('lvl_serv_capa')"><i class="fa-solid fa-house"></i> Início</button>
        <button type="button" onclick="abrirNivel('lvl_tomadores')"><i class="fa-solid fa-briefcase"></i> Análise Tomadores</button>
        <button type="button" onclick="abrirNivel('lvl_fat_cidade')"><i class="fa-solid fa-city"></i> Movimento por Município</button>
        <button type="button" onclick="abrirNivel('lvl_mapa_tributario')"><i class="fa-solid fa-layer-group"></i> Auditoria de Impostos</button>
        <button type="button" onclick="abrirNivel('lvl_servicos_prestados_tomados')"><i class="fa-solid fa-clipboard-list"></i> Prestados / Tomados</button>
        <button class="active" type="button" onclick="abrirNivel('lvl_ajuda_painel')"><i class="fa-solid fa-circle-question"></i> Ajuda / FAQ</button>
    </nav>

    <main>
        <header class="page-head">
            <div>
                <h1>Guia do Painel de Serviços</h1>
                <p class="lead">Referência para apresentação, validação dos números e entendimento das regras de negócio.</p>
            </div>
            <span class="version">Regra ABC: 80 / 15 / 5</span>
        </header>

        <nav class="quick-nav">
            <a href="#base">Base dos dados</a>
            <a href="#inicio">Tela inicial</a>
            <a href="#abc">Curva ABC</a>
            <a href="#cidade">Municípios</a>
            <a href="#auditoria">Auditoria</a>
            <a href="#prestados">Prestados / Tomados</a>
            <a href="#faq">Perguntas frequentes</a>
        </nav>

        <section class="section" id="base">
            <h2><i class="fa-solid fa-database"></i> Base dos dados</h2>
            <div class="grid">
                <article class="item"><h3>Movimentos e itens</h3><p>As notas vêm de <code>TGFCAB</code> e seus itens de <code>TGFITE</code>. Os serviços são identificados em <code>TGFPRO</code>.</p></article>
                <article class="item"><h3>O que é considerado serviço?</h3><p>Produto com <code>TGFPRO.USOPROD = 'S'</code>.</p></article>
                <article class="item"><h3>Notas consideradas</h3><p>Na visão comercial são usadas notas confirmadas/liberadas, com <code>TGFCAB.STATUSNOTA = 'L'</code> e movimento de venda <code>TIPMOV = 'V'</code>.</p></article>
                <article class="item"><h3>Filtros globais</h3><p>Data inicial, data final, empresa, UF e tipo de operação. Quando informados, os mesmos filtros são aplicados às consultas da tela.</p></article>
            </div>
        </section>

        <section class="section" id="inicio">
            <h2><i class="fa-solid fa-chart-line"></i> Tela inicial</h2>
            <div class="grid">
                <article class="item"><h3>Faturamento Total</h3><p>Soma do valor total dos itens de serviço nas notas de venda válidas.</p><span class="formula">SUM(TGFITE.VLRTOT)</span></article>
                <article class="item"><h3>Serviços Distintos</h3><p>Quantidade de códigos de serviço diferentes movimentados no período.</p><span class="formula">COUNT(DISTINCT TGFITE.CODPROD)</span></article>
                <article class="item"><h3>Quantidade Total</h3><p>Quantidade de notas distintas que possuem itens de serviço.</p><span class="formula">COUNT(DISTINCT TGFCAB.NUNOTA)</span></article>
                <article class="item"><h3>Ticket Médio</h3><p>Faturamento mensal de serviços dividido pela quantidade de notas distintas do mês.</p><span class="formula">SUM(VLRTOT) / COUNT(DISTINCT NUNOTA)</span></article>
                <article class="item"><h3>Serviços Mais Utilizados</h3><p>Ranking pela soma da quantidade negociada dos itens, usando <code>SUM(TGFITE.QTDNEG)</code>. Não é ranking por faturamento.</p></article>
                <article class="item"><h3>Evolução mensal</h3><p>As barras representam faturamento. As linhas mostram notas e ticket médio. Valores financeiros usam a mesma escala em reais; notas usam escala de quantidade.</p></article>
            </div>
        </section>

        <section class="section" id="abc">
            <h2><i class="fa-solid fa-ranking-star"></i> Curva ABC de novos clientes</h2>
            <p class="lead">O painel usa o padrão clássico 80/15/5 sobre o faturamento acumulado, após ordenar os clientes do maior para o menor faturamento.</p>
            <div class="abc">
                <div><strong>Classe A - até 80%</strong><span>Clientes que formam os primeiros 80% do faturamento acumulado.</span></div>
                <div><strong>Classe B - de 80% a 95%</strong><span>Clientes que completam os 15 pontos percentuais seguintes.</span></div>
                <div><strong>Classe C - acima de 95%</strong><span>Clientes que representam os aproximadamente 5% finais.</span></div>
            </div>
            <p class="notice"><strong>Importante:</strong> 80/15/5 não é uma divisão fixa da quantidade de clientes. Dependendo da concentração do faturamento, poucos clientes podem formar a classe A e muitos podem ficar na classe C.</p>
            <div class="grid">
                <article class="item"><h3>Quem é considerado novo cliente?</h3><p>Parceiro cuja primeira nota de venda confirmada está dentro do período selecionado.</p></article>
                <article class="item"><h3>É possível ajustar?</h3><p>Sim. Os limites atuais são <code>0.80</code> e <code>0.95</code> nas três consultas da tela ABC. Podem ser alterados, por exemplo, para 70/20/10 ou 80/10/10, desde que a regra seja documentada.</p></article>
            </div>
        </section>

        <section class="section" id="cidade">
            <h2><i class="fa-solid fa-map-location-dot"></i> Movimento por Município e ISS</h2>
            <div class="grid">
                <article class="item"><h3>Faturamento por cidade</h3><p>Soma de <code>TGFITE.VLRTOT</code>, agrupada pela cidade e UF do parceiro, respeitando os filtros da tela.</p></article>
                <article class="item"><h3>Participação percentual</h3><p>Valor da cidade dividido pelo faturamento total das cidades selecionadas, multiplicado por 100.</p></article>
                <article class="item"><h3>ISS por município</h3><p>Consolida o valor de ISS por município, destacando quantidade de municípios, total de ISS e maior concentração.</p></article>
                <article class="item"><h3>Mapa</h3><p>É uma representação geográfica do mesmo agrupamento. O mapa não altera os valores; apenas muda a forma de leitura.</p></article>
            </div>
        </section>

        <section class="section" id="auditoria">
            <h2><i class="fa-solid fa-shield-halved"></i> Auditoria de impostos</h2>
            <table>
                <thead><tr><th>Indicador</th><th>Como é interpretado</th></tr></thead>
                <tbody>
                    <tr><td>Impostos</td><td>Valores de ISS, PIS, COFINS, CSLL, IR e INSS apurados nas tabelas fiscais relacionadas aos itens/notas.</td></tr>
                    <tr><td>ISS zerado</td><td>Notas de serviço cujo valor de ISS no cabeçalho está zerado. É uma sinalização para conferência, não uma conclusão automática de erro fiscal.</td></tr>
                    <tr><td>Serviços sem movimento</td><td>Serviços ativos sem movimentação no período ou nunca utilizados. A maior inatividade é calculada entre a data atual e a última negociação.</td></tr>
                    <tr><td>Cadastro incompleto</td><td>Serviços ativos com ausência de informações fiscais como incidência de ISS, alíquota, tipo de serviço, código tributário municipal, CNAE ou NBS.</td></tr>
                </tbody>
            </table>
        </section>

        <section class="section" id="prestados">
            <h2><i class="fa-solid fa-right-left"></i> Serviços prestados e tomados</h2>
            <div class="grid">
                <article class="item"><h3>Prestados</h3><p>Notas de venda de serviço: <code>TGFCAB.TIPMOV = 'V'</code>.</p></article>
                <article class="item"><h3>Tomados</h3><p>Notas de compra de serviço: <code>TGFCAB.TIPMOV = 'C'</code>.</p></article>
                <article class="item"><h3>Alíquota ISS</h3><p>Alíquota informada no item da nota.</p></article>
                <article class="item"><h3>ISS calculado</h3><p>Percentual calculado por <code>VLRISS / BASEISS x 100</code>, com proteção para base igual a zero.</p></article>
            </div>
        </section>

        <section class="section" id="faq">
            <h2><i class="fa-solid fa-comments"></i> Perguntas frequentes</h2>
            <details><summary>Por que o total pode mudar quando aplico UF?</summary><p>A UF utilizada nas telas comerciais vem da cidade do parceiro. Notas de parceiros sem relacionamento válido de cidade/UF podem não participar do agrupamento.</p></details>
            <details><summary>Por que ticket médio e faturamento não têm o mesmo desenho?</summary><p>Porque ticket médio também depende da quantidade de notas. Dois meses com faturamento parecido podem ter tickets diferentes se a quantidade de notas for diferente.</p></details>
            <details><summary>Por que a quantidade de clientes A não é 80%?</summary><p>Porque a classificação considera percentual do faturamento acumulado, não percentual da quantidade de clientes.</p></details>
            <details><summary>ISS zerado significa erro?</summary><p>Não necessariamente. É um alerta para conferência da operação, retenção, tributação e configuração fiscal.</p></details>
            <details><summary>Qual valor é usado como faturamento?</summary><p>A soma de <code>TGFITE.VLRTOT</code> dos itens classificados como serviço em notas de venda confirmadas.</p></details>
        </section>
    </main>

    <script>
        function abrirNivel(levelId, params) {
            params = params || {};
            if (typeof openLevel === 'function') { openLevel(levelId, params); return; }
            if (window.parent && typeof window.parent.openLevel === 'function') { window.parent.openLevel(levelId, params); return; }
            if (typeof JX !== 'undefined' && JX.openLevel) JX.openLevel(levelId, params);
        }
    </script>
</body>
</html>
