<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false"%>
<%@ taglib uri="http://java.sun.com/jstl/core_rt" prefix="c" %>
<%@ taglib prefix="snk" uri="/WEB-INF/tld/sankhyaUtil.tld" %>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://cdnjs.cloudflare.com">
    <link rel="preconnect" href="https://code.highcharts.com">
    <title>Curva ABC - Novos Clientes</title>
    <script defer src="https://code.highcharts.com/highcharts.js"></script>
    <script defer src="https://code.highcharts.com/modules/accessibility.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" rel="stylesheet">
</head>

<body>
<snk:load/>

<script type="text/javascript">
    var gadGetID = '${param.gadGetID}';
    var nuGdg = '${param.nuGdg}';
    var contextPage = window.parent.dashboard[nuGdg];

    function openLevel(nivel, params) {
        contextPage.openLevel(nivel, params || {});
    }
</script>

    <style>
        :root {
            --bg-page: #f4f7fb;
            --bg-panel: #ffffff;
            --bg-sidebar: #ffffff;
            --bg-card: #ffffff;
            --text-title: #172033;
            --text-body: #5e6b7f;
            --text-muted: #8a97a8;
            --green: #21a366;
            --green-soft: #e7f6ee;
            --orange: #f59e0b;
            --orange-soft: #fff4dd;
            --red: #ef4444;
            --red-soft: #fdecec;
            --blue: #2563eb;
            --blue-soft: #e8f0ff;
            --purple: #7c3aed;
            --purple-soft: #f1eaff;
            --border: #e5eaf1;
            --shadow: 0 12px 30px rgba(15, 23, 42, .08);
            --radius: 18px;
        }
        * { box-sizing: border-box; }
        body {
            margin: 0;
            background: var(--bg-page);
            color: var(--text-title);
            font-family: "Segoe UI", Arial, sans-serif;
            overflow-x: hidden;
        }
        .app {
            display: grid;
            grid-template-columns: 230px minmax(0, 1fr);
            min-height: 100vh;
        }
        .sidebar {
            background: var(--bg-sidebar);
            border-right: 1px solid var(--border);
            padding: 18px 14px;
        }
        .brand {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 8px 10px 20px;
            font-weight: 800;
            color: var(--text-title);
        }
        .brand-icon {
            width: 34px;
            height: 34px;
            border-radius: 11px;
            display: grid;
            place-items: center;
            background: var(--green-soft);
            color: var(--green);
        }
        .nav-title {
            font-size: 11px;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: .12em;
            margin: 16px 12px 8px;
            font-weight: 700;
        }
        .nav-item {
            display: flex;
            align-items: center;
            gap: 11px;
            width: 100%;
            border: 0;
            background: transparent;
            color: var(--text-body);
            padding: 11px 12px;
            border-radius: 12px;
            font-size: 14px;
            text-align: left;
            cursor: pointer;
            transition: .18s ease;
        }
        .nav-item:hover, .nav-item.active {
            background: var(--green-soft);
            color: var(--green);
            font-weight: 700;
        }
        .main {
            padding: 18px 24px 28px;
            min-width: 0;
        }
        .topbar {
            background: var(--bg-panel);
            border: 1px solid var(--border);
            border-radius: 16px;
            min-height: 64px;
            padding: 0 18px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: 0 6px 18px rgba(15, 23, 42, .04);
            margin-bottom: 18px;
        }
        .topbar-left { display: flex; align-items: center; gap: 12px; }
        .title-icon {
            width: 38px;
            height: 38px;
            border-radius: 13px;
            display: grid;
            place-items: center;
            background: var(--green-soft);
            color: var(--green);
        }
        .topbar h1 { margin: 0; font-size: 18px; font-weight: 850; color: var(--text-title); }
        .periodo { color: var(--text-muted); font-size: 12px; margin-top: 3px; }
        .badge {
            font-size: 11px;
            font-weight: 800;
            color: var(--green);
            background: var(--green-soft);
            border: 1px solid #c7ecd8;
            border-radius: 999px;
            padding: 6px 10px;
            white-space: nowrap;
        }
        .dash-grid {
            display: grid;
            grid-template-columns: repeat(12, minmax(0, 1fr));
            gap: 18px;
        }
        .card {
            background: var(--bg-card);
            border: 1px solid var(--border);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            padding: 18px;
            min-width: 0;
        }
        .span-12 { grid-column: span 12; }
        .span-7 { grid-column: span 7; }
        .span-5 { grid-column: span 5; }
        .card-head {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            margin-bottom: 14px;
        }
        .card-title { margin: 0; font-size: 15px; font-weight: 850; color: var(--text-title); }
        .card-title i { color: var(--green); margin-right: 7px; }
        .card-title.warning i { color: var(--orange); }
        .alert-warning {
            display: flex;
            align-items: center;
            gap: 12px;
            background: var(--orange-soft);
            border: 2px solid var(--orange);
            color: #92400e;
            border-radius: 18px;
            padding: 16px 18px;
            font-weight: 800;
            box-shadow: 0 10px 25px rgba(245, 158, 11, .15);
        }
        .alert-warning i { font-size: 24px; }
        .row-warning td { background: #fffbeb; }
        .resumo-card {
            display: grid;
            grid-template-columns: 1.3fr repeat(3, minmax(0, 1fr));
            gap: 14px;
            align-items: stretch;
        }
        .resumo-total {
            border: 1px solid var(--border);
            background: linear-gradient(135deg, #ffffff 0%, #f7fbff 100%);
            border-radius: 16px;
            padding: 18px;
            display: flex;
            gap: 14px;
            align-items: center;
        }
        .resumo-icon {
            width: 52px;
            height: 52px;
            min-width: 52px;
            border-radius: 16px;
            display: grid;
            place-items: center;
            background: var(--green-soft);
            color: var(--green);
            font-size: 22px;
        }
        .resumo-label {
            display: block;
            color: var(--text-muted);
            font-size: 11px;
            letter-spacing: .06em;
            text-transform: uppercase;
            font-weight: 800;
            margin-bottom: 6px;
        }
        .resumo-value {
            font-size: 26px;
            font-weight: 900;
            color: var(--text-title);
            line-height: 1.05;
        }
        .resumo-sub {
            margin-top: 5px;
            color: var(--text-body);
            font-size: 12px;
        }
        .abc-box {
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 16px;
            min-width: 0;
        }
        .abc-box.a { background: var(--green-soft); }
        .abc-box.b { background: var(--orange-soft); }
        .abc-box.c { background: var(--red-soft); }
        .abc-top { display: flex; align-items: center; justify-content: space-between; gap: 10px; }
        .abc-letter {
            width: 34px;
            height: 34px;
            border-radius: 12px;
            display: grid;
            place-items: center;
            font-weight: 900;
            color: #fff;
        }
        .abc-box.a .abc-letter { background: var(--green); }
        .abc-box.b .abc-letter { background: var(--orange); }
        .abc-box.c .abc-letter { background: var(--red); }
        .abc-qtd { font-size: 25px; font-weight: 900; color: var(--text-title); margin-top: 12px; }
        .abc-desc { color: var(--text-body); font-size: 12px; margin-top: 3px; }
        .chart { height: 340px; }
        .table-wrapper {
            max-height: 410px;
            overflow: auto;
            border: 1px solid var(--border);
            border-radius: 14px;
        }
        .data-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 13px;
        }
        .data-table th {
            position: sticky;
            top: 0;
            z-index: 1;
            background: #f8fafc;
            color: var(--text-muted);
            text-align: left;
            padding: 11px 12px;
            border-bottom: 1px solid var(--border);
            font-size: 11px;
            letter-spacing: .05em;
            text-transform: uppercase;
            white-space: nowrap;
        }
        .data-table td {
            padding: 11px 12px;
            border-bottom: 1px solid var(--border);
            color: var(--text-body);
            vertical-align: middle;
        }
        .data-table tr:hover td { background: #fbfdff; }
        .align-right { text-align: right; }
        .align-center { text-align: center; }
        .curva-pill {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 28px;
            height: 24px;
            border-radius: 999px;
            font-size: 12px;
            font-weight: 900;
        }
        .curva-a { color: var(--green); background: var(--green-soft); }
        .curva-b { color: var(--orange); background: var(--orange-soft); }
        .curva-c { color: var(--red); background: var(--red-soft); }
        @media (max-width: 1150px) {
            .app { grid-template-columns: 1fr; }
            .sidebar { display: none; }
            .resumo-card { grid-template-columns: 1fr; }
            .span-7, .span-5 { grid-column: span 12; }
            .main { padding: 12px; }
            .topbar { align-items: flex-start; flex-direction: column; padding: 14px 16px; }
        }
    
        /* Otimizações de renderização: limita reflows/repaints em blocos independentes */
        .card, .kpi, .resumo-total, .mini-card, .table-wrap, .ranking-list {
            contain: layout paint;
        }
        table { table-layout: fixed; }
</style>
</head>
<body>

<snk:query var="q_resumo_abc_novos">
WITH BASE AS (
    SELECT
        CAB.CODPARC,
        PAR.NOMEPARC,
        SUM(ITE.VLRTOT) AS FAT_SERV
    FROM TGFCAB CAB
    INNER JOIN TGFITE ITE ON CAB.NUNOTA = ITE.NUNOTA
    INNER JOIN TGFPRO PRO ON ITE.CODPROD = PRO.CODPROD
    INNER JOIN TGFPAR PAR ON CAB.CODPARC = PAR.CODPARC
    INNER JOIN TSICID CID ON PAR.CODCID = CID.CODCID
    INNER JOIN TSIUFS UFS ON CID.UF = UFS.CODUF
    WHERE CAB.STATUSNOTA = 'L'
      AND CAB.TIPMOV = 'V'
      AND PRO.USOPROD = 'S'
      AND (CAB.DTNEG >= :P_DATA_INI OR :P_DATA_INI IS NULL)
      AND (CAB.DTNEG <= :P_DATA_FIM OR :P_DATA_FIM IS NULL)
      AND (:P_EMPRESA IS NULL OR CAB.CODEMP IN (:P_EMPRESA))
      AND (:P_TOP IS NULL OR CAB.CODTIPOPER IN (:P_TOP))
      AND (:P_UF IS NULL OR UFS.CODUF IN (:P_UF))
      AND ((SELECT MIN(C2.DTNEG)
              FROM TGFCAB C2
             WHERE C2.CODPARC = CAB.CODPARC
               AND C2.STATUSNOTA = 'L'
               AND C2.TIPMOV = 'V') >= :P_DATA_INI OR :P_DATA_INI IS NULL)
      AND ((SELECT MIN(C2.DTNEG)
              FROM TGFCAB C2
             WHERE C2.CODPARC = CAB.CODPARC
               AND C2.STATUSNOTA = 'L'
               AND C2.TIPMOV = 'V') <= :P_DATA_FIM OR :P_DATA_FIM IS NULL)
    GROUP BY CAB.CODPARC, PAR.NOMEPARC
), CALC AS (
    SELECT
        NOMEPARC,
        FAT_SERV,
        SUM(FAT_SERV) OVER () AS TOTAL_GERAL,
        SUM(FAT_SERV) OVER (ORDER BY FAT_SERV DESC, NOMEPARC) AS ACUMULADO
    FROM BASE
), CLASSIFICADO AS (
    SELECT
        NOMEPARC,
        FAT_SERV,
        CASE
            WHEN ACUMULADO / NULLIF(TOTAL_GERAL, 0) <= 0.80 THEN 'A'
            WHEN ACUMULADO / NULLIF(TOTAL_GERAL, 0) <= 0.95 THEN 'B'
            ELSE 'C'
        END AS CURVA
    FROM CALC
)
SELECT
    COUNT(*) AS TOTAL_CLIENTES,
    TO_CHAR(COUNT(*), 'FM999G999G999G990', 'NLS_NUMERIC_CHARACTERS = '',.''') AS TOTAL_CLIENTES_FMT,
    SUM(FAT_SERV) AS FAT_TOTAL,
    TO_CHAR(NVL(SUM(FAT_SERV), 0), 'FM999G999G999G990D00', 'NLS_NUMERIC_CHARACTERS = '',.''') AS FAT_TOTAL_FMT,
    SUM(CASE WHEN CURVA = 'A' THEN 1 ELSE 0 END) AS QTD_A,
    SUM(CASE WHEN CURVA = 'B' THEN 1 ELSE 0 END) AS QTD_B,
    SUM(CASE WHEN CURVA = 'C' THEN 1 ELSE 0 END) AS QTD_C,
    TO_CHAR(SUM(CASE WHEN CURVA = 'A' THEN 1 ELSE 0 END), 'FM999G999G990', 'NLS_NUMERIC_CHARACTERS = '',.''') AS QTD_A_FMT,
    TO_CHAR(SUM(CASE WHEN CURVA = 'B' THEN 1 ELSE 0 END), 'FM999G999G990', 'NLS_NUMERIC_CHARACTERS = '',.''') AS QTD_B_FMT,
    TO_CHAR(SUM(CASE WHEN CURVA = 'C' THEN 1 ELSE 0 END), 'FM999G999G990', 'NLS_NUMERIC_CHARACTERS = '',.''') AS QTD_C_FMT
FROM CLASSIFICADO
</snk:query>

<snk:query var="q_grd_abc_novos">
WITH BASE AS (
    SELECT
        CAB.CODPARC,
        PAR.NOMEPARC,
        SUM(ITE.VLRTOT) AS FAT_SERV
    FROM TGFCAB CAB
    INNER JOIN TGFITE ITE ON CAB.NUNOTA = ITE.NUNOTA
    INNER JOIN TGFPRO PRO ON ITE.CODPROD = PRO.CODPROD
    INNER JOIN TGFPAR PAR ON CAB.CODPARC = PAR.CODPARC
    INNER JOIN TSICID CID ON PAR.CODCID = CID.CODCID
    INNER JOIN TSIUFS UFS ON CID.UF = UFS.CODUF
    WHERE CAB.STATUSNOTA = 'L'
      AND CAB.TIPMOV = 'V'
      AND PRO.USOPROD = 'S'
      AND (CAB.DTNEG >= :P_DATA_INI OR :P_DATA_INI IS NULL)
      AND (CAB.DTNEG <= :P_DATA_FIM OR :P_DATA_FIM IS NULL)
      AND (:P_EMPRESA IS NULL OR CAB.CODEMP IN (:P_EMPRESA))
      AND (:P_TOP IS NULL OR CAB.CODTIPOPER IN (:P_TOP))
      AND (:P_UF IS NULL OR UFS.CODUF IN (:P_UF))
      AND ((SELECT MIN(C2.DTNEG)
              FROM TGFCAB C2
             WHERE C2.CODPARC = CAB.CODPARC
               AND C2.STATUSNOTA = 'L'
               AND C2.TIPMOV = 'V') >= :P_DATA_INI OR :P_DATA_INI IS NULL)
      AND ((SELECT MIN(C2.DTNEG)
              FROM TGFCAB C2
             WHERE C2.CODPARC = CAB.CODPARC
               AND C2.STATUSNOTA = 'L'
               AND C2.TIPMOV = 'V') <= :P_DATA_FIM OR :P_DATA_FIM IS NULL)
    GROUP BY CAB.CODPARC, PAR.NOMEPARC
), CALC AS (
    SELECT
        NOMEPARC,
        FAT_SERV,
        SUM(FAT_SERV) OVER () AS TOTAL_GERAL,
        SUM(FAT_SERV) OVER (ORDER BY FAT_SERV DESC, NOMEPARC) AS ACUMULADO
    FROM BASE
)
SELECT
    NOMEPARC,
    FAT_SERV,
    TO_CHAR(FAT_SERV, 'FM999G999G999G990D00', 'NLS_NUMERIC_CHARACTERS = '',.''') AS FAT_SERV_FMT,
    ROUND((FAT_SERV / NULLIF(TOTAL_GERAL, 0)) * 100, 2) AS PERC,
    TO_CHAR(ROUND((FAT_SERV / NULLIF(TOTAL_GERAL, 0)) * 100, 2), 'FM990D00', 'NLS_NUMERIC_CHARACTERS = '',.''') AS PERC_FMT,
    ROUND((ACUMULADO / NULLIF(TOTAL_GERAL, 0)) * 100, 2) AS PERC_ACUM,
    TO_CHAR(ROUND((ACUMULADO / NULLIF(TOTAL_GERAL, 0)) * 100, 2), 'FM990D00', 'NLS_NUMERIC_CHARACTERS = '',.''') AS PERC_ACUM_FMT,
    CASE
        WHEN ACUMULADO / NULLIF(TOTAL_GERAL, 0) <= 0.80 THEN 'A'
        WHEN ACUMULADO / NULLIF(TOTAL_GERAL, 0) <= 0.95 THEN 'B'
        ELSE 'C'
    END AS CURVA
FROM CALC
ORDER BY FAT_SERV DESC, NOMEPARC
</snk:query>

<snk:query var="q_cht_abc_novos">
WITH BASE AS (
    SELECT
        CAB.CODPARC,
        PAR.NOMEPARC,
        SUM(ITE.VLRTOT) AS FAT_SERV
    FROM TGFCAB CAB
    INNER JOIN TGFITE ITE ON CAB.NUNOTA = ITE.NUNOTA
    INNER JOIN TGFPRO PRO ON ITE.CODPROD = PRO.CODPROD
    INNER JOIN TGFPAR PAR ON CAB.CODPARC = PAR.CODPARC
    INNER JOIN TSICID CID ON PAR.CODCID = CID.CODCID
    INNER JOIN TSIUFS UFS ON CID.UF = UFS.CODUF
    WHERE CAB.STATUSNOTA = 'L'
      AND CAB.TIPMOV = 'V'
      AND PRO.USOPROD = 'S'
      AND (CAB.DTNEG >= :P_DATA_INI OR :P_DATA_INI IS NULL)
      AND (CAB.DTNEG <= :P_DATA_FIM OR :P_DATA_FIM IS NULL)
      AND (:P_EMPRESA IS NULL OR CAB.CODEMP IN (:P_EMPRESA))
      AND (:P_TOP IS NULL OR CAB.CODTIPOPER IN (:P_TOP))
      AND (:P_UF IS NULL OR UFS.CODUF IN (:P_UF))
      AND ((SELECT MIN(C2.DTNEG)
              FROM TGFCAB C2
             WHERE C2.CODPARC = CAB.CODPARC
               AND C2.STATUSNOTA = 'L'
               AND C2.TIPMOV = 'V') >= :P_DATA_INI OR :P_DATA_INI IS NULL)
      AND ((SELECT MIN(C2.DTNEG)
              FROM TGFCAB C2
             WHERE C2.CODPARC = CAB.CODPARC
               AND C2.STATUSNOTA = 'L'
               AND C2.TIPMOV = 'V') <= :P_DATA_FIM OR :P_DATA_FIM IS NULL)
    GROUP BY CAB.CODPARC, PAR.NOMEPARC
), CALC AS (
    SELECT
        NOMEPARC,
        FAT_SERV,
        SUM(FAT_SERV) OVER () AS TOTAL_GERAL,
        SUM(FAT_SERV) OVER (ORDER BY FAT_SERV DESC, NOMEPARC) AS ACUMULADO
    FROM BASE
), CLASSIFICADO AS (
    SELECT
        CASE
            WHEN ACUMULADO / NULLIF(TOTAL_GERAL, 0) <= 0.80 THEN 'A'
            WHEN ACUMULADO / NULLIF(TOTAL_GERAL, 0) <= 0.95 THEN 'B'
            ELSE 'C'
        END AS CURVA,
        FAT_SERV
    FROM CALC
)
SELECT
    CURVA,
    COUNT(*) AS QTD_CLIENTES,
    TO_CHAR(COUNT(*), 'FM999999999990', 'NLS_NUMERIC_CHARACTERS = ''.,''') AS QTD_CLIENTES_JS,
    SUM(FAT_SERV) AS FAT_SERV,
    TO_CHAR(NVL(SUM(FAT_SERV), 0), 'FM999999999990D00', 'NLS_NUMERIC_CHARACTERS = ''.,''') AS FAT_SERV_JS
FROM CLASSIFICADO
GROUP BY CURVA
ORDER BY CURVA
</snk:query>

<snk:query var="q_resumo_clientes_inativos">
WITH ULTIMA_COMPRA AS (
    SELECT
        PAR.CODPARC,
        PAR.NOMEPARC,
        MAX(CAB.DTNEG) AS DATA_ULTIMA_NOTA
    FROM TGFCAB CAB
    INNER JOIN TGFPAR PAR ON CAB.CODPARC = PAR.CODPARC
    INNER JOIN TGFITE ITE ON CAB.NUNOTA = ITE.NUNOTA
    INNER JOIN TGFPRO PRO ON ITE.CODPROD = PRO.CODPROD
    INNER JOIN TSICID CID ON PAR.CODCID = CID.CODCID
    INNER JOIN TSIUFS UFS ON CID.UF = UFS.CODUF
    WHERE CAB.STATUSNOTA = 'L'
      AND CAB.TIPMOV = 'V'
      AND PRO.USOPROD = 'S'
      AND (CAB.DTNEG >= :P_DATA_INI OR :P_DATA_INI IS NULL)
      AND (CAB.DTNEG <= :P_DATA_FIM OR :P_DATA_FIM IS NULL)
      AND (:P_EMPRESA IS NULL OR CAB.CODEMP IN (:P_EMPRESA))
      AND (:P_TOP IS NULL OR CAB.CODTIPOPER IN (:P_TOP))
      AND (:P_UF IS NULL OR UFS.CODUF IN (:P_UF))
      AND NOT EXISTS (
          SELECT 1
          FROM TGFCAB C2
          WHERE C2.CODPARC = CAB.CODPARC
            AND C2.STATUSNOTA = 'L'
            AND C2.TIPMOV = 'V'
            AND C2.DTNEG > TRUNC(SYSDATE) - 30
      )
    GROUP BY PAR.CODPARC, PAR.NOMEPARC
)
SELECT
    COUNT(*) AS QTD_CLIENTES_INATIVOS,
    TO_CHAR(COUNT(*), 'FM999G999G990', 'NLS_NUMERIC_CHARACTERS = '',.''') AS QTD_CLIENTES_INATIVOS_FMT,
    TO_CHAR(NVL(MAX(TRUNC(SYSDATE) - TRUNC(DATA_ULTIMA_NOTA)), 0), 'FM999G999G990', 'NLS_NUMERIC_CHARACTERS = '',.''') AS MAIOR_INATIVIDADE_FMT
FROM ULTIMA_COMPRA
</snk:query>

<snk:query var="q_grd_clientes_inativos">
SELECT *
FROM (
    SELECT
        PAR.CODPARC AS COD_PARCEIRO,
        PAR.NOMEPARC AS TOMADOR,
        PAR.TELEFONE,
        MAX(CAB.DTNEG) AS DATA_ULTIMA_NOTA,
        TO_CHAR(MAX(CAB.DTNEG), 'DD-MM-YYYY') AS DATA_ULTIMA_NOTA_FMT,
        TRUNC(SYSDATE) - TRUNC(MAX(CAB.DTNEG)) AS DIAS_INATIVO
    FROM TGFCAB CAB
    INNER JOIN TGFPAR PAR ON CAB.CODPARC = PAR.CODPARC
    INNER JOIN TGFITE ITE ON CAB.NUNOTA = ITE.NUNOTA
    INNER JOIN TGFPRO PRO ON ITE.CODPROD = PRO.CODPROD
    INNER JOIN TSICID CID ON PAR.CODCID = CID.CODCID
    INNER JOIN TSIUFS UFS ON CID.UF = UFS.CODUF
    WHERE CAB.STATUSNOTA = 'L'
      AND CAB.TIPMOV = 'V'
      AND PRO.USOPROD = 'S'
      AND (CAB.DTNEG >= :P_DATA_INI OR :P_DATA_INI IS NULL)
      AND (CAB.DTNEG <= :P_DATA_FIM OR :P_DATA_FIM IS NULL)
      AND (:P_EMPRESA IS NULL OR CAB.CODEMP IN (:P_EMPRESA))
      AND (:P_TOP IS NULL OR CAB.CODTIPOPER IN (:P_TOP))
      AND (:P_UF IS NULL OR UFS.CODUF IN (:P_UF))
      AND NOT EXISTS (
          SELECT 1
          FROM TGFCAB C2
          WHERE C2.CODPARC = CAB.CODPARC
            AND C2.STATUSNOTA = 'L'
            AND C2.TIPMOV = 'V'
            AND C2.DTNEG > TRUNC(SYSDATE) - 30
      )
    GROUP BY PAR.CODPARC, PAR.NOMEPARC, PAR.TELEFONE
    ORDER BY DIAS_INATIVO DESC, PAR.NOMEPARC
)
WHERE ROWNUM <= 10
</snk:query>

<div class="app">
    <aside class="sidebar">
        <div class="brand" onclick="voltarMenuInicial()" title="Voltar ao menu inicial">
            <div class="brand-icon">
                <i class="fa-solid fa-bars"></i>
            </div>
            <span>Menu Inicial</span>
        </div>

        <div class="nav-title">Dashboard</div>
        <button class="nav-item" type="button" onclick="voltarMenuInicial()"><i class="fa-solid fa-house"></i> Início</button>
        <button class="nav-item active" type="button" onclick="abrirNivel('lvl_tomadores')"><i class="fa-solid fa-briefcase"></i> Análise Tomadores</button>
        <button class="nav-item" type="button" onclick="abrirNivel('lvl_fat_cidade')"><i class="fa-solid fa-city"></i> Movimento por Município</button>
        <button class="nav-item" type="button" onclick="abrirIssMunicipio()"><i class="fa-solid fa-map-location-dot"></i> ISS por Município</button>
        <button class="nav-item" type="button" onclick="abrirNivel('lvl_mapa_tributario')"><i class="fa-solid fa-layer-group"></i> Auditoria de Impostos</button>
        <button class="nav-item" type="button" onclick="abrirServicosSemMovimento()"><i class="fa-solid fa-screwdriver-wrench"></i> Serviços</button>
        <button class="nav-item" type="button" onclick="abrirNivel('lvl_servicos_prestados_tomados')"><i class="fa-solid fa-clipboard-list"></i> Prestados / Tomados</button>
    </aside>

    <main class="main">
        <section class="topbar">
            <div class="topbar-left">
                <div class="title-icon"><i class="fa-solid fa-user-plus"></i></div>
                <div>
                    <h1>Análise dos Tomadores</h1>
                </div>
            </div>
        </section>

        <section class="dash-grid">
            <div class="card span-12">
                <c:forEach items="${q_resumo_abc_novos.rows}" var="resumo">
                    <div class="resumo-card">
                        <div class="resumo-total">
                            <div class="resumo-icon"><i class="fa-solid fa-sack-dollar"></i></div>
                            <div>
                                <span class="resumo-label">Faturamento</span>
                                <div class="resumo-value">R$ ${resumo.FAT_TOTAL_FMT}</div>
                                <div class="resumo-sub">${resumo.TOTAL_CLIENTES_FMT} novo(s) cliente(s) no período</div>
                            </div>
                        </div>

                        <div class="abc-box a">
                            <div class="abc-top">
                                <span class="resumo-label">Curva A</span>
                                <span class="abc-letter">A</span>
                            </div>
                            <div class="abc-qtd">${resumo.QTD_A_FMT}</div>
                            <div class="abc-desc">clientes de maior relevância</div>
                        </div>

                        <div class="abc-box b">
                            <div class="abc-top">
                                <span class="resumo-label">Curva B</span>
                                <span class="abc-letter">B</span>
                            </div>
                            <div class="abc-qtd">${resumo.QTD_B_FMT}</div>
                            <div class="abc-desc">clientes intermediários</div>
                        </div>

                        <div class="abc-box c">
                            <div class="abc-top">
                                <span class="resumo-label">Curva C</span>
                                <span class="abc-letter">C</span>
                            </div>
                            <div class="abc-qtd">${resumo.QTD_C_FMT}</div>
                            <div class="abc-desc">clientes de menor participação</div>
                        </div>
                    </div>
                </c:forEach>
            </div>

            <c:forEach items="${q_resumo_clientes_inativos.rows}" var="inativos">
                <c:if test="${inativos.QTD_CLIENTES_INATIVOS > 0}">
                    <div class="alert-warning span-12">
                        <i class="fa-solid fa-user-clock"></i>
                        <span>Foram encontrados ${inativos.QTD_CLIENTES_INATIVOS_FMT} cliente(s) inativo(s) há mais de 30 dias. Maior inatividade: ${inativos.MAIOR_INATIVIDADE_FMT} dias desde a última nota emitida.</span>
                    </div>
                </c:if>
            </c:forEach>

            <div class="card span-12">
                <div class="card-head">
                    <h2 class="card-title warning"><i class="fa-solid fa-user-clock"></i> Clientes inativos</h2>
                    <span class="badge">Sem nota nos últimos 30 dias</span>
                </div>
                <div class="table-wrapper">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th class="align-center">Cód.</th>
                                <th>Tomador</th>
                                <th>Telefone</th>
                                <th class="align-center">Últ. nota</th>
                                <th class="align-right">Dias inativo</th>
                            </tr>
                        </thead>
                        <tbody>
                            <c:forEach items="${q_grd_clientes_inativos.rows}" var="row">
                                <tr class="row-warning">
                                    <td class="align-center">${row.COD_PARCEIRO}</td>
                                    <td><c:out value="${row.TOMADOR}"/></td>
                                    <td>${row.TELEFONE}</td>
                                    <td class="align-center">${row.DATA_ULTIMA_NOTA_FMT}</td>
                                    <td class="align-right">${row.DIAS_INATIVO}</td>
                                </tr>
                            </c:forEach>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="card span-5">
                <div class="card-head">
                    <h2 class="card-title"><i class="fa-solid fa-chart-column"></i> Clientes por curva</h2>
                </div>
                <div id="chartAbcNovos" class="chart"></div>
            </div>

            <div class="card span-7">
                <div class="card-head">
                    <h2 class="card-title"><i class="fa-solid fa-table-list"></i> Detalhamento dos novos clientes</h2>
                    <span class="badge">Ordenado por faturamento</span>
                </div>
                <div class="table-wrapper">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Cliente</th>
                                <th class="align-right">Faturamento</th>
                                <th class="align-right">% Part.</th>
                                <th class="align-right">% Acum.</th>
                                <th>Curva</th>
                            </tr>
                        </thead>
                        <tbody>
                            <c:forEach items="${q_grd_abc_novos.rows}" var="row">
                                <tr>
                                    <td>${row.NOMEPARC}</td>
                                    <td class="align-right">R$ ${row.FAT_SERV_FMT}</td>
                                    <td class="align-right">${row.PERC_FMT}%</td>
                                    <td class="align-right">${row.PERC_ACUM_FMT}%</td>
                                    <td>
                                        <c:choose>
                                            <c:when test="${row.CURVA == 'A'}"><span class="curva-pill curva-a">A</span></c:when>
                                            <c:when test="${row.CURVA == 'B'}"><span class="curva-pill curva-b">B</span></c:when>
                                            <c:otherwise><span class="curva-pill curva-c">C</span></c:otherwise>
                                        </c:choose>
                                    </td>
                                </tr>
                            </c:forEach>
                        </tbody>
                    </table>
                </div>
            </div>
        </section>
    </main>
</div>

<script>
    function voltarMenuInicial() {
        openLevel('lvl_serv_capa', {});
    }

    function abrirNivel(levelId, params) {
        params = params || {};
        try {
            if (typeof openLevel === 'function') {
                openLevel(levelId, params);
            } else if (window.parent && typeof window.parent.openLevel === 'function') {
                window.parent.openLevel(levelId, params);
            } else {
                alert('Não foi possível abrir o nível: ' + levelId);
            }
        } catch (e) {
            console.error('Erro ao abrir nível:', levelId, e);
        }
    }

    function abrirServicosSemMovimento() {
        try {
            if (window.parent) {
                window.parent.__abrirServicosSemMov = true;
            }
        } catch (e) {}
        abrirNivel('lvl_mapa_tributario', { ABRIR_SERVICOS: 'S' });
    }

    function abrirIssMunicipio() {
        try {
            if (window.parent) {
                window.parent.__abrirIssMunicipio = true;
            }
        } catch (e) {}
        abrirNivel('lvl_fat_cidade', { ABRIR_ISS_MUNICIPIO: 'S' });
    }

    function toNumber(value) {
        if (value === null || value === undefined || value === '') return 0;
        value = String(value).trim();
        if (value.indexOf(',') >= 0) {
            value = value.replace(/\./g, '').replace(',', '.');
        }
        return Number(value) || 0;
    }

    document.addEventListener('DOMContentLoaded', function() {
        if (typeof Highcharts !== 'undefined') {
            Highcharts.setOptions({
                chart: { animation: false },
                plotOptions: { series: { animation: false } },
                accessibility: { enabled: false }
            });
        }

        var categorias = [];
        var qtdClientes = [];
        var fatServ = [];

        <c:forEach items="${q_cht_abc_novos.rows}" var="row">
            categorias.push('Curva ${row.CURVA}');
            qtdClientes.push(toNumber('${row.QTD_CLIENTES_JS}'));
            fatServ.push(toNumber('${row.FAT_SERV_JS}'));
        </c:forEach>

        Highcharts.chart('chartAbcNovos', {
            chart: { type: 'column', backgroundColor: 'transparent' },
            accessibility: { enabled: false },
            title: { text: null },
            xAxis: {
                categories: categorias,
                labels: { style: { color: '#5e6b7f', fontSize: '12px' } },
                lineColor: '#e5eaf1'
            },
            yAxis: {
                min: 0,
                title: { text: null },
                gridLineColor: '#eef2f7',
                labels: { style: { color: '#8a97a8' } }
            },
            legend: { enabled: false },
            tooltip: {
                shared: true,
                formatter: function () {
                    var idx = this.points ? this.points[0].point.index : this.point.index;
                    return '<b>' + categorias[idx] + '</b><br/>' +
                           'Clientes: <b>' + Highcharts.numberFormat(qtdClientes[idx], 0, ',', '.') + '</b><br/>' +
                           'Faturamento: <b>R$ ' + Highcharts.numberFormat(fatServ[idx], 2, ',', '.') + '</b>';
                }
            },
            plotOptions: {
                column: {
                    borderWidth: 0,
                    borderRadius: 8,
                    dataLabels: {
                        enabled: true,
                        style: { color: '#172033', textOutline: 'none', fontWeight: '800' }
                    }
                }
            },
            series: [{
                name: 'Clientes',
                data: qtdClientes,
                color: '#21a366'
            }],
            credits: { enabled: false }
        });
    });
</script>
</body>
</html>
