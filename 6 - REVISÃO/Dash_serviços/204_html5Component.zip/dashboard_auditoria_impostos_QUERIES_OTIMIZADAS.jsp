<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false"%>
<%@ taglib uri="http://java.sun.com/jstl/core_rt" prefix="c" %>
<%@ taglib prefix="snk" uri="/WEB-INF/tld/sankhyaUtil.tld" %>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Mapa Tributário + ISS Zerado</title>
    <link rel="preconnect" href="https://code.highcharts.com" crossorigin>
    <link rel="preconnect" href="https://cdnjs.cloudflare.com" crossorigin>
    <script defer src="https://code.highcharts.com/highcharts.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" rel="stylesheet">
</head>

<body>
<snk:load/>

<snk:query var="q_resource_cadastro_servico">
SELECT RESOURCEID
FROM (
    SELECT
        RESOURCEID,
        DESCRMENU,
        CASE
            WHEN UPPER(DESCRMENU) IN ('SERVIÇO', 'SERVICO') THEN 1
            WHEN UPPER(DESCRMENU) LIKE '%PRODUTOS%SERVI%' THEN 2
            WHEN UPPER(DESCRMENU) LIKE '%SERVI%' THEN 3
            WHEN UPPER(DESCRMENU) IN ('PRODUTOS', 'PRODUTO') THEN 4
            WHEN UPPER(DESCRMENU) LIKE '%PRODUTO%' THEN 5
            ELSE 9
        END AS ORDEM
    FROM TSIACM
    WHERE RESOURCEID IS NOT NULL
      AND (
          UPPER(DESCRMENU) IN ('SERVIÇO', 'SERVICO', 'PRODUTOS', 'PRODUTO')
          OR UPPER(DESCRMENU) LIKE '%SERVI%'
          OR UPPER(DESCRMENU) LIKE '%PRODUTO%'
      )
    ORDER BY ORDEM, DESCRMENU
)
WHERE ROWNUM = 1
</snk:query>

<script type="text/javascript">
    var gadGetID = '${param.gadGetID}';
    var nuGdg = '${param.nuGdg}';
    var contextPage = window.parent.dashboard[nuGdg];
    var abrirServicosInicial = '${param.ABRIR_SERVICOS}';
    var resourceCadastroServico = '';
    <c:forEach items="${q_resource_cadastro_servico.rows}" var="res">
        resourceCadastroServico = '<c:out value="${res.RESOURCEID}"/>';
    </c:forEach>

    function openLevel(nivel, params) {
        contextPage.openLevel(nivel, params || {});
    }
</script>

    <style>
        :root {
            --bg-page: #f4f7fb;
            --bg-panel: #ffffff;
            --bg-sidebar: #ffffff;
            --bg-card: #ffffff;
            --text-title: #172033;
            --text-body: #5e6b7f;
            --text-muted: #8a97a8;
            --green: #21a366;
            --green-soft: #e7f6ee;
            --blue: #2563eb;
            --blue-soft: #e8f0ff;
            --orange: #f59e0b;
            --orange-soft: #fff4dd;
            --red: #ef4444;
            --red-soft: #fef2f2;
            --border: #e5eaf1;
            --shadow: 0 12px 30px rgba(15, 23, 42, .08);
            --radius: 18px;
        }
        * { box-sizing: border-box; }
        body {
            margin: 0;
            background: var(--bg-page);
            color: var(--text-title);
            font-family: "Segoe UI", Arial, sans-serif;
            overflow-x: hidden;
        }
        .app {
            display: grid;
            grid-template-columns: 230px minmax(0, 1fr);
            min-height: 100vh;
        }
        .sidebar {
            background: var(--bg-sidebar);
            border-right: 1px solid var(--border);
            padding: 18px 14px;
        }
        .brand {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 8px 10px 20px;
            font-weight: 800;
            color: var(--text-title);
        }
        .brand-icon {
            width: 34px;
            height: 34px;
            border-radius: 11px;
            display: grid;
            place-items: center;
            background: var(--green-soft);
            color: var(--green);
        }
        .nav-title {
            font-size: 11px;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: .12em;
            margin: 16px 12px 8px;
            font-weight: 700;
        }
        .nav-item {
            display: flex;
            align-items: center;
            gap: 11px;
            width: 100%;
            border: 0;
            background: transparent;
            color: var(--text-body);
            padding: 11px 12px;
            border-radius: 12px;
            font-size: 14px;
            text-align: left;
            cursor: pointer;
            transition: .18s ease;
        }
        .nav-item:hover, .nav-item.active {
            background: var(--green-soft);
            color: var(--green);
            font-weight: 700;
        }
        .nav-item.danger:hover {
            background: var(--red-soft);
            color: var(--red);
        }
        .main {
            padding: 18px 24px 28px;
            min-width: 0;
        }
        .topbar {
            background: var(--bg-panel);
            border: 1px solid var(--border);
            border-radius: 16px;
            min-height: 58px;
            padding: 0 18px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: 0 6px 18px rgba(15, 23, 42, .04);
            margin-bottom: 18px;
        }
        .topbar-left { display: flex; align-items: center; gap: 12px; }
        .title-icon {
            width: 38px;
            height: 38px;
            border-radius: 12px;
            display: grid;
            place-items: center;
            background: var(--green-soft);
            color: var(--green);
        }
        .topbar h1 { margin: 0; font-size: 17px; font-weight: 800; }
        .periodo { color: var(--text-muted); font-size: 12px; }
        .badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 6px 10px;
            border-radius: 999px;
            font-size: 11px;
            font-weight: 800;
            color: var(--green);
            background: var(--green-soft);
            border: 1px solid #c7ecd8;
            white-space: nowrap;
        }
        .badge-danger {
            color: #991b1b;
            background: var(--red-soft);
            border-color: #fecaca;
        }
        .dash-grid {
            display: grid;
            grid-template-columns: repeat(12, minmax(0, 1fr));
            gap: 18px;
        }
        .card {
            background: var(--bg-card);
            border: 1px solid var(--border);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            padding: 18px;
            min-width: 0;
        }
        .span-12 { grid-column: span 12; }
        .span-6 { grid-column: span 6; }
        .span-4 { grid-column: span 4; }
        .card-head {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            margin-bottom: 12px;
        }
        .card-title {
            margin: 0;
            font-size: 15px;
            font-weight: 800;
            color: var(--text-title);
        }
        .card-title i { color: var(--green); margin-right: 7px; }
        .card-title.danger i { color: var(--red); }
        .card-title.warning i { color: var(--orange); }
        .kpi-grid {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 18px;
            margin-bottom: 18px;
        }
        .kpi {
            background: var(--bg-card);
            border: 1px solid var(--border);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            padding: 18px;
            display: flex;
            align-items: center;
            gap: 15px;
            min-height: 110px;
        }
        .kpi.danger {
            border-color: #fecaca;
            background: linear-gradient(180deg, #fff, #fff7f7);
        }
        .kpi-icon {
            width: 50px;
            height: 50px;
            min-width: 50px;
            border-radius: 16px;
            display: grid;
            place-items: center;
            background: var(--green-soft);
            color: var(--green);
            font-size: 22px;
        }
        .kpi.blue .kpi-icon { background: var(--blue-soft); color: var(--blue); }
        .kpi.warning .kpi-icon { background: var(--orange-soft); color: var(--orange); }
        .kpi.danger .kpi-icon { background: var(--red-soft); color: var(--red); }
        .kpi-label {
            display: block;
            color: var(--text-muted);
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: .05em;
            font-weight: 800;
            margin-bottom: 6px;
        }
        .kpi-value {
            font-size: 24px;
            font-weight: 850;
            color: var(--text-title);
            line-height: 1.1;
        }
        .kpi-sub {
            margin-top: 5px;
            font-size: 12px;
            color: var(--green);
            font-weight: 700;
        }
        .kpi.danger .kpi-sub { color: var(--red); }
        .alert-iss {
            display: none;
            background: var(--red-soft);
            border: 2px solid var(--red);
            color: #991b1b;
            border-radius: 18px;
            padding: 16px 18px;
            margin-bottom: 18px;
            font-weight: 700;
            align-items: center;
            gap: 12px;
            box-shadow: 0 10px 25px rgba(239, 68, 68, .15);
        }
        .alert-iss i { font-size: 24px; }
        .detail-card {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 18px;
            border-color: #fecaca;
            background: linear-gradient(180deg, #fff, #fff7f7);
        }
        .detail-card-main {
            display: flex;
            align-items: center;
            gap: 15px;
            min-width: 0;
        }
        .detail-card-icon {
            width: 50px;
            height: 50px;
            min-width: 50px;
            border-radius: 16px;
            display: grid;
            place-items: center;
            background: var(--red-soft);
            color: var(--red);
            font-size: 22px;
        }
        .detail-card-label {
            color: var(--text-muted);
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: .05em;
            font-weight: 800;
            margin-bottom: 6px;
        }
        .detail-card-value {
            font-size: 24px;
            font-weight: 850;
            color: var(--text-title);
            line-height: 1.1;
        }
        .detail-card-sub {
            margin-top: 5px;
            color: var(--red);
            font-size: 12px;
            font-weight: 700;
        }
        .detail-card-action {
            border: 0;
            border-radius: 12px;
            background: var(--red);
            color: #fff;
            cursor: pointer;
            font-weight: 800;
            padding: 11px 15px;
            white-space: nowrap;
            box-shadow: 0 10px 22px rgba(239, 68, 68, .18);
        }
        .detail-card-action:hover { background: #dc2626; }
        .service-card {
            border-color: #fed7aa;
            background: linear-gradient(180deg, #fff, #fffaf1);
        }
        .service-card .detail-card-icon {
            background: var(--orange-soft);
            color: var(--orange);
        }
        .service-card .detail-card-sub { color: #b45309; }
        .service-card .detail-card-action {
            background: var(--orange);
            box-shadow: 0 10px 22px rgba(245, 158, 11, .18);
        }
        .service-card .detail-card-action:hover { background: #d97706; }
        .inline-detail {
            display: none;
            grid-column: span 12;
            grid-template-columns: repeat(12, minmax(0, 1fr));
            gap: 18px;
        }
        #servicosSemMovInline { order: 10; }
        #issMunicipioInline { order: 12; }
        #tabelaMapa { order: 20; }
        .inline-detail.is-open { display: grid; }
        .detail-table-wrapper { max-height: 620px; }
        .chart-box { height: 360px; }
        .table-wrapper {
            max-height: 520px;
            overflow: auto;
            margin-top: 10px;
            border: 1px solid var(--border);
            border-radius: 14px;
        }
        .data-table { width: 100%; border-collapse: collapse; background: #fff; }
        .data-table th {
            position: sticky;
            top: 0;
            background: #f8fafc;
            text-align: left;
            padding: 11px 12px;
            color: var(--text-muted);
            border-bottom: 1px solid var(--border);
            font-size: 11px;
            text-transform: uppercase;
            white-space: nowrap;
            z-index: 1;
        }
        .data-table td {
            padding: 10px 12px;
            border-bottom: 1px solid #edf1f6;
            font-size: 13px;
            vertical-align: top;
            color: var(--text-body);
        }
        .data-table tr.clickable-row { cursor: pointer; }
        .data-table tr.clickable-row:hover td { background: #feecec; }
        .data-table tr.row-warning.clickable-row:hover td { background: #fff4dd; }
        .nota-link {
            color: var(--blue);
            font-weight: 800;
            text-decoration: underline;
            text-underline-offset: 3px;
            cursor: pointer;
        }
        .data-table tr.row-danger td { background: #fff7f7; }
        .align-right { text-align: right; }
        .align-center { text-align: center; }
        .col-qtd {
            width: 92px;
            min-width: 92px;
            max-width: 92px;
            text-align: center;
        }
        .col-cod {
            width: 120px;
            min-width: 120px;
            max-width: 120px;
            text-align: center;
        }
        .col-config {
            width: 160px;
            min-width: 160px;
            max-width: 160px;
            text-align: center;
        }
        @media (max-width: 1100px) {
            .app { grid-template-columns: 1fr; }
            .sidebar { display: none; }
            .kpi-grid { grid-template-columns: 1fr; }
            .span-6, .span-4 { grid-column: span 12; }
            .detail-card { align-items: stretch; flex-direction: column; }
            .detail-card-action { width: 100%; }
            .main { padding: 12px; }
        }
    

        /* Otimizações seguras de renderização: isola blocos para reduzir reflow/repaint */
        .card, .kpi, .resumo-total, .mini-card, .table-wrap, .ranking-list {
            contain: layout paint;
        }
        table { table-layout: fixed; }

</style>
</head>
<body>

<snk:query var="q_grd_mapa_servicos">
WITH CAB_FILTRADA AS (
    SELECT /*+ MATERIALIZE */
        CAB.NUNOTA,
        CAB.DTNEG,
        CAB.CODEMP,
        CAB.ISSRETIDO
    FROM TGFCAB CAB
    INNER JOIN TGFPAR PAR ON PAR.CODPARC = CAB.CODPARC
    INNER JOIN TSICID CID ON CID.CODCID = PAR.CODCID
    WHERE CAB.STATUSNOTA = 'L'
      AND CAB.TIPMOV = 'V'
      AND (:P_DATA_INI IS NULL OR CAB.DTNEG >= :P_DATA_INI)
      AND (:P_DATA_FIM IS NULL OR CAB.DTNEG <= :P_DATA_FIM)
      AND (:P_EMPRESA IS NULL OR CAB.CODEMP IN (:P_EMPRESA))
      AND (:P_TOP IS NULL OR CAB.CODTIPOPER IN (:P_TOP))
      AND (:P_UF IS NULL OR CID.UF IN (:P_UF))
),

ITENS_RANQUEADOS AS (
    SELECT
        CAB.NUNOTA,
        CAB.DTNEG,
        CAB.CODEMP,
        CAB.ISSRETIDO AS ISS_RETIDO_CAB,
        ITE.SEQUENCIA,
        ITE.CODTRIBISS,
        ITE.VLRTOT AS VALOR_BRUTO,
        PRO.DESCRPROD,

        ROW_NUMBER() OVER (
            ORDER BY CAB.DTNEG DESC, CAB.NUNOTA DESC, ITE.SEQUENCIA
        ) AS RN

    FROM CAB_FILTRADA CAB
    INNER JOIN TGFITE ITE ON ITE.NUNOTA = CAB.NUNOTA
    INNER JOIN TGFPRO PRO ON PRO.CODPROD = ITE.CODPROD
    WHERE PRO.USOPROD = 'S'
),

ITENS_TOP AS (
    SELECT /*+ MATERIALIZE */
        *
    FROM ITENS_RANQUEADOS
    WHERE RN <= 50
),

ISS_AGR AS (
    SELECT
        D.NUNOTA,
        D.SEQUENCIA,
        SUM(NVL(D.VALOR, 0)) AS VLR_ISS
    FROM TGFDIN D
    INNER JOIN ITENS_TOP ITE
        ON ITE.NUNOTA = D.NUNOTA
       AND ITE.SEQUENCIA = D.SEQUENCIA
    WHERE D.CODIMP = 4
    GROUP BY D.NUNOTA, D.SEQUENCIA
),

IMPOSTOS_AGR AS (
    SELECT
        M.NUNOTA,
        M.SEQUENCIA,

        SUM(CASE WHEN M.CODIMP = 2 THEN NVL(M.VALOR, 0) ELSE 0 END) AS VLR_PIS,
        SUM(CASE WHEN M.CODIMP = 3 THEN NVL(M.VALOR, 0) ELSE 0 END) AS VLR_COFINS,
        SUM(CASE WHEN M.CODIMP = 4 THEN NVL(M.VALOR, 0) ELSE 0 END) AS VLR_CSLL,
        SUM(CASE WHEN M.CODIMP = 7 THEN NVL(M.VALOR, 0) ELSE 0 END) AS VLR_IR,
        SUM(CASE WHEN M.CODIMP = 6 THEN NVL(M.VALOR, 0) ELSE 0 END) AS VLR_INSS

    FROM TGFIMN M
    INNER JOIN ITENS_TOP ITE
        ON ITE.NUNOTA = M.NUNOTA
       AND ITE.SEQUENCIA = M.SEQUENCIA
    WHERE M.CODIMP IN (2, 3, 4, 6, 7)
    GROUP BY M.NUNOTA, M.SEQUENCIA
)

SELECT
    ITE.NUNOTA,
    ITE.DTNEG,
    TO_CHAR(ITE.DTNEG, 'DD-MM-YYYY') AS DTNEG_FMT,
    ITE.CODEMP,
    ITE.DESCRPROD,

    ITE.VALOR_BRUTO,
    TO_CHAR(
        ITE.VALOR_BRUTO,
        'FM999G999G999G990D00',
        'NLS_NUMERIC_CHARACTERS = '',.'''
    ) AS VALOR_BRUTO_FMT,

    NVL(ISS.VLR_ISS, 0) AS VLR_ISS,
    TO_CHAR(
        NVL(ISS.VLR_ISS, 0),
        'FM999G999G999G990D00',
        'NLS_NUMERIC_CHARACTERS = '',.'''
    ) AS VLR_ISS_FMT,

    ITE.ISS_RETIDO_CAB,

    NVL(IMP.VLR_PIS, 0) AS VLR_PIS,
    TO_CHAR(
        NVL(IMP.VLR_PIS, 0),
        'FM999G999G999G990D00',
        'NLS_NUMERIC_CHARACTERS = '',.'''
    ) AS VLR_PIS_FMT,

    NVL(IMP.VLR_COFINS, 0) AS VLR_COFINS,
    TO_CHAR(
        NVL(IMP.VLR_COFINS, 0),
        'FM999G999G999G990D00',
        'NLS_NUMERIC_CHARACTERS = '',.'''
    ) AS VLR_COFINS_FMT,

    NVL(IMP.VLR_CSLL, 0) AS VLR_CSLL,
    TO_CHAR(
        NVL(IMP.VLR_CSLL, 0),
        'FM999G999G999G990D00',
        'NLS_NUMERIC_CHARACTERS = '',.'''
    ) AS VLR_CSLL_FMT,

    NVL(IMP.VLR_IR, 0) AS VLR_IR,
    TO_CHAR(
        NVL(IMP.VLR_IR, 0),
        'FM999G999G999G990D00',
        'NLS_NUMERIC_CHARACTERS = '',.'''
    ) AS VLR_IR_FMT,

    NVL(IMP.VLR_INSS, 0) AS VLR_INSS,
    TO_CHAR(
        NVL(IMP.VLR_INSS, 0),
        'FM999G999G999G990D00',
        'NLS_NUMERIC_CHARACTERS = '',.'''
    ) AS VLR_INSS_FMT,

    (
        ITE.VALOR_BRUTO -
        (
            NVL(IMP.VLR_PIS, 0) +
            NVL(IMP.VLR_COFINS, 0) +
            NVL(IMP.VLR_CSLL, 0) +
            NVL(IMP.VLR_IR, 0) +
            NVL(IMP.VLR_INSS, 0) +
            CASE 
                WHEN ITE.CODTRIBISS = 1 THEN NVL(ISS.VLR_ISS, 0) 
                ELSE 0 
            END
        )
    ) AS VALOR_LIQUIDO,

    TO_CHAR(
        (
            ITE.VALOR_BRUTO -
            (
                NVL(IMP.VLR_PIS, 0) +
                NVL(IMP.VLR_COFINS, 0) +
                NVL(IMP.VLR_CSLL, 0) +
                NVL(IMP.VLR_IR, 0) +
                NVL(IMP.VLR_INSS, 0) +
                CASE 
                    WHEN ITE.CODTRIBISS = 1 THEN NVL(ISS.VLR_ISS, 0) 
                    ELSE 0 
                END
            )
        ),
        'FM999G999G999G990D00',
        'NLS_NUMERIC_CHARACTERS = '',.'''
    ) AS VALOR_LIQUIDO_FMT,

    CASE ITE.CODTRIBISS
        WHEN 0 THEN 'TRIBUTADO'
        WHEN 1 THEN 'ISS RETIDO'
        WHEN 7 THEN 'NÃO TRIBUTADO'
        WHEN 6 THEN 'ISENTO'
        ELSE 'OUTROS'
    END AS INC_ISS

FROM ITENS_TOP ITE
LEFT JOIN ISS_AGR ISS
    ON ISS.NUNOTA = ITE.NUNOTA
   AND ISS.SEQUENCIA = ITE.SEQUENCIA
LEFT JOIN IMPOSTOS_AGR IMP
    ON IMP.NUNOTA = ITE.NUNOTA
   AND IMP.SEQUENCIA = ITE.SEQUENCIA
ORDER BY ITE.DTNEG DESC, ITE.NUNOTA DESC, ITE.SEQUENCIA
</snk:query>

<snk:query var="q_mapa_resumo">
WITH BASE_ITENS AS (
    SELECT /*+ MATERIALIZE */
        CAB.NUNOTA,
        CAB.VLRISS,
        ITE.SEQUENCIA,
        ITE.VLRTOT
    FROM TGFCAB CAB
    INNER JOIN TGFITE ITE ON ITE.NUNOTA = CAB.NUNOTA
    INNER JOIN TGFPRO PRO ON PRO.CODPROD = ITE.CODPROD
    INNER JOIN TGFPAR PAR ON PAR.CODPARC = CAB.CODPARC
    INNER JOIN TSICID CID ON CID.CODCID = PAR.CODCID
    WHERE CAB.STATUSNOTA = 'L'
      AND CAB.TIPMOV = 'V'
      AND PRO.USOPROD = 'S'
      AND (:P_DATA_INI IS NULL OR CAB.DTNEG >= :P_DATA_INI)
      AND (:P_DATA_FIM IS NULL OR CAB.DTNEG <= :P_DATA_FIM)
      AND (:P_EMPRESA IS NULL OR CAB.CODEMP IN (:P_EMPRESA))
      AND (:P_TOP IS NULL OR CAB.CODTIPOPER IN (:P_TOP))
      AND (:P_UF IS NULL OR CID.UF IN (:P_UF))
),

ISS_AGR AS (
    SELECT
        D.NUNOTA,
        D.SEQUENCIA,
        SUM(NVL(D.VALOR, 0)) AS VLR_ISS
    FROM TGFDIN D
    INNER JOIN BASE_ITENS B
        ON B.NUNOTA = D.NUNOTA
       AND B.SEQUENCIA = D.SEQUENCIA
    WHERE D.CODIMP = 4
    GROUP BY D.NUNOTA, D.SEQUENCIA
),

IMPOSTOS_AGR AS (
    SELECT
        M.NUNOTA,
        M.SEQUENCIA,
        SUM(CASE WHEN M.CODIMP = 2 THEN NVL(M.VALOR, 0) ELSE 0 END) AS VLR_PIS,
        SUM(CASE WHEN M.CODIMP = 3 THEN NVL(M.VALOR, 0) ELSE 0 END) AS VLR_COFINS,
        SUM(CASE WHEN M.CODIMP = 4 THEN NVL(M.VALOR, 0) ELSE 0 END) AS VLR_CSLL,
        SUM(CASE WHEN M.CODIMP = 7 THEN NVL(M.VALOR, 0) ELSE 0 END) AS VLR_IR,
        SUM(CASE WHEN M.CODIMP = 6 THEN NVL(M.VALOR, 0) ELSE 0 END) AS VLR_INSS
    FROM TGFIMN M
    INNER JOIN BASE_ITENS B
        ON B.NUNOTA = M.NUNOTA
       AND B.SEQUENCIA = M.SEQUENCIA
    WHERE M.CODIMP IN (2, 3, 4, 6, 7)
    GROUP BY M.NUNOTA, M.SEQUENCIA
),

RESUMO AS (
    SELECT
        B.NUNOTA,
        B.VLRISS AS VLRISS_CAB,
        B.VLRTOT AS VALOR_BRUTO,
        NVL(ISS.VLR_ISS, 0) AS VLR_ISS,
        NVL(IMP.VLR_PIS, 0) AS VLR_PIS,
        NVL(IMP.VLR_COFINS, 0) AS VLR_COFINS,
        NVL(IMP.VLR_CSLL, 0) AS VLR_CSLL,
        NVL(IMP.VLR_IR, 0) AS VLR_IR,
        NVL(IMP.VLR_INSS, 0) AS VLR_INSS
    FROM BASE_ITENS B
    LEFT JOIN ISS_AGR ISS
        ON ISS.NUNOTA = B.NUNOTA
       AND ISS.SEQUENCIA = B.SEQUENCIA
    LEFT JOIN IMPOSTOS_AGR IMP
        ON IMP.NUNOTA = B.NUNOTA
       AND IMP.SEQUENCIA = B.SEQUENCIA
)

SELECT
    COUNT(DISTINCT NUNOTA) AS QTD_NOTAS,

    TO_CHAR(
        COUNT(DISTINCT NUNOTA),
        'FM999G999G990',
        'NLS_NUMERIC_CHARACTERS = '',.'''
    ) AS QTD_NOTAS_FMT,

    NVL(SUM(VALOR_BRUTO), 0) AS VALOR_BRUTO,

    TO_CHAR(
        NVL(SUM(VALOR_BRUTO), 0),
        'FM999G999G999G990D00',
        'NLS_NUMERIC_CHARACTERS = '',.'''
    ) AS VALOR_BRUTO_FMT,

    NVL(SUM(VLR_ISS), 0) AS VLR_ISS,
    NVL(SUM(VLR_PIS), 0) AS VLR_PIS,
    NVL(SUM(VLR_COFINS), 0) AS VLR_COFINS,
    NVL(SUM(VLR_CSLL), 0) AS VLR_CSLL,
    NVL(SUM(VLR_IR), 0) AS VLR_IR,
    NVL(SUM(VLR_INSS), 0) AS VLR_INSS,

    TO_CHAR(
        NVL(SUM(VLR_ISS + VLR_PIS + VLR_COFINS + VLR_CSLL + VLR_IR + VLR_INSS), 0),
        'FM999G999G999G990D00',
        'NLS_NUMERIC_CHARACTERS = '',.'''
    ) AS TOTAL_IMPOSTOS_FMT,

    TO_CHAR(NVL(SUM(VLR_ISS), 0), 'FM999999999990D00', 'NLS_NUMERIC_CHARACTERS = ''.,''') AS VLR_ISS_JS,
    TO_CHAR(NVL(SUM(VLR_PIS), 0), 'FM999999999990D00', 'NLS_NUMERIC_CHARACTERS = ''.,''') AS VLR_PIS_JS,
    TO_CHAR(NVL(SUM(VLR_COFINS), 0), 'FM999999999990D00', 'NLS_NUMERIC_CHARACTERS = ''.,''') AS VLR_COFINS_JS,
    TO_CHAR(NVL(SUM(VLR_CSLL), 0), 'FM999999999990D00', 'NLS_NUMERIC_CHARACTERS = ''.,''') AS VLR_CSLL_JS,
    TO_CHAR(NVL(SUM(VLR_IR), 0), 'FM999999999990D00', 'NLS_NUMERIC_CHARACTERS = ''.,''') AS VLR_IR_JS,
    TO_CHAR(NVL(SUM(VLR_INSS), 0), 'FM999999999990D00', 'NLS_NUMERIC_CHARACTERS = ''.,''') AS VLR_INSS_JS,

    COUNT(DISTINCT CASE WHEN NVL(VLRISS_CAB, 0) = 0 THEN NUNOTA END) AS QTD_NOTAS_ISS_ZERADO,

    TO_CHAR(
        NVL(SUM(CASE WHEN NVL(VLRISS_CAB, 0) = 0 THEN VALOR_BRUTO ELSE 0 END), 0),
        'FM999G999G999G990D00',
        'NLS_NUMERIC_CHARACTERS = '',.'''
    ) AS VALOR_TOTAL_ISS_ZERADO_FMT
FROM RESUMO
</snk:query>





<snk:query var="q_resumo_serv_sem_mov">
WITH SERVICOS_SEM_MOV AS (
    SELECT PROD.CODPROD, ULTIMA.DTNEG
    FROM TGFPRO PROD
    LEFT JOIN (
        SELECT ITE.CODPROD, MAX(CAB.DTNEG) AS DTNEG
        FROM TGFITE ITE
        INNER JOIN TGFCAB CAB ON CAB.NUNOTA = ITE.NUNOTA
        WHERE CAB.STATUSNOTA = 'L'
          AND CAB.TIPMOV = 'V'
        GROUP BY ITE.CODPROD
    ) ULTIMA ON ULTIMA.CODPROD = PROD.CODPROD
    WHERE PROD.USOPROD = 'S'
      AND PROD.ATIVO = 'S'
      AND NOT EXISTS (
          SELECT 1
          FROM TGFITE ITE_F
          INNER JOIN TGFCAB CAB_F ON CAB_F.NUNOTA = ITE_F.NUNOTA
          INNER JOIN TGFPAR PAR_F ON PAR_F.CODPARC = CAB_F.CODPARC
          INNER JOIN TSICID CID_F ON CID_F.CODCID = PAR_F.CODCID
          WHERE ITE_F.CODPROD = PROD.CODPROD
            AND CAB_F.STATUSNOTA = 'L'
            AND CAB_F.TIPMOV = 'V'
            AND (:P_DATA_INI IS NULL OR CAB_F.DTNEG >= :P_DATA_INI)
            AND (:P_DATA_FIM IS NULL OR CAB_F.DTNEG <= :P_DATA_FIM)
            AND (:P_EMPRESA IS NULL OR CAB_F.CODEMP IN (:P_EMPRESA))
            AND (:P_TOP IS NULL OR CAB_F.CODTIPOPER IN (:P_TOP))
            AND (:P_UF IS NULL OR CID_F.UF IN (:P_UF))
      )
)
SELECT
    COUNT(*) AS QTD_SERVICOS,
    TO_CHAR(COUNT(*), 'FM999G999G990', 'NLS_NUMERIC_CHARACTERS = '',.''') AS QTD_SERVICOS_FMT,
    COUNT(CASE WHEN DTNEG IS NULL THEN 1 END) AS QTD_NUNCA_USADOS,
    TO_CHAR(COUNT(CASE WHEN DTNEG IS NULL THEN 1 END), 'FM999G999G990', 'NLS_NUMERIC_CHARACTERS = '',.''') AS QTD_NUNCA_USADOS_FMT,
    TO_CHAR(NVL(MAX(TRUNC(SYSDATE) - TRUNC(DTNEG)), 0), 'FM999G999G990', 'NLS_NUMERIC_CHARACTERS = '',.''') AS MAIOR_INATIVIDADE_FMT
FROM SERVICOS_SEM_MOV
</snk:query>

<snk:query var="q_resumo_serv_cad_incompleto">
WITH SERVICOS AS (
    SELECT
        PROD.CODPROD,
        CASE WHEN NVL(PROD.TEMISS, 'N') NOT IN ('S', 'T') THEN 1 ELSE 0 END AS FALTA_TEM_ISS,
        CASE WHEN NOT EXISTS (
            SELECT 1
            FROM TGFISS ISS
            WHERE ISS.CODPROD = PROD.CODPROD
        ) THEN 1 ELSE 0 END AS FALTA_ALIQ_ISS,
        CASE WHEN PROD.CODLST IS NULL THEN 1 ELSE 0 END AS FALTA_TIPO_SERVICO,
        CASE WHEN PROD.CODTRIBMUNISS IS NULL THEN 1 ELSE 0 END AS FALTA_COD_TRIB_MUN,
        CASE WHEN PROD.CNAE IS NULL THEN 1 ELSE 0 END AS FALTA_CNAE,
        CASE WHEN PROD.CODNBS IS NULL THEN 1 ELSE 0 END AS FALTA_NBS,
        CASE WHEN NOT EXISTS (
            SELECT 1
            FROM TGFPEM PEM
            WHERE PEM.CODPROD = PROD.CODPROD
              AND (:P_EMPRESA IS NULL OR PEM.CODEMP IN (:P_EMPRESA))
        ) THEN 1 ELSE 0 END AS FALTA_CONFIG_EMPRESA
    FROM TGFPRO PROD
    WHERE PROD.USOPROD = 'S'
      AND PROD.ATIVO = 'S'
),
PENDENCIAS AS (
    SELECT
        CODPROD,
        FALTA_TEM_ISS,
        FALTA_ALIQ_ISS,
        FALTA_TIPO_SERVICO,
        FALTA_COD_TRIB_MUN,
        FALTA_CNAE,
        FALTA_NBS,
        FALTA_CONFIG_EMPRESA,
        FALTA_TEM_ISS + FALTA_ALIQ_ISS + FALTA_TIPO_SERVICO + FALTA_COD_TRIB_MUN + FALTA_CNAE + FALTA_NBS AS QTD_PENDENCIAS
    FROM SERVICOS
)
SELECT
    COUNT(*) AS QTD_SERVICOS_INCOMPLETOS,
    TO_CHAR(COUNT(*), 'FM999G999G990', 'NLS_NUMERIC_CHARACTERS = '',.''') AS QTD_SERVICOS_INCOMPLETOS_FMT,
    TO_CHAR(NVL(MAX(QTD_PENDENCIAS), 0), 'FM999G999G990', 'NLS_NUMERIC_CHARACTERS = '',.''') AS MAIOR_QTD_PENDENCIAS_FMT,
    TO_CHAR(NVL(SUM(FALTA_TEM_ISS), 0), 'FM999G999G990', 'NLS_NUMERIC_CHARACTERS = '',.''') AS FALTA_TEM_ISS_FMT,
    TO_CHAR(NVL(SUM(FALTA_ALIQ_ISS), 0), 'FM999G999G990', 'NLS_NUMERIC_CHARACTERS = '',.''') AS FALTA_ALIQ_ISS_FMT,
    TO_CHAR(NVL(SUM(FALTA_TIPO_SERVICO), 0), 'FM999G999G990', 'NLS_NUMERIC_CHARACTERS = '',.''') AS FALTA_TIPO_SERVICO_FMT,
    TO_CHAR(NVL(SUM(FALTA_COD_TRIB_MUN), 0), 'FM999G999G990', 'NLS_NUMERIC_CHARACTERS = '',.''') AS FALTA_COD_TRIB_MUN_FMT,
    TO_CHAR(NVL(SUM(FALTA_CNAE), 0), 'FM999G999G990', 'NLS_NUMERIC_CHARACTERS = '',.''') AS FALTA_CNAE_FMT,
    TO_CHAR(NVL(SUM(FALTA_NBS), 0), 'FM999G999G990', 'NLS_NUMERIC_CHARACTERS = '',.''') AS FALTA_NBS_FMT,
    TO_CHAR(NVL(SUM(FALTA_CONFIG_EMPRESA), 0), 'FM999G999G990', 'NLS_NUMERIC_CHARACTERS = '',.''') AS FALTA_CONFIG_EMPRESA_FMT
FROM PENDENCIAS
WHERE QTD_PENDENCIAS > 0
   OR FALTA_CONFIG_EMPRESA = 1
</snk:query>

<snk:query var="q_grd_serv_cad_incompleto">
SELECT *
FROM (
    SELECT
        CODPROD,
        DESCRPROD,
        QTD_PENDENCIAS,
        TO_CHAR(QTD_PENDENCIAS, 'FM999G999G990', 'NLS_NUMERIC_CHARACTERS = '',.''') AS QTD_PENDENCIAS_FMT,
        CASE WHEN FALTA_CONFIG_EMPRESA = 1 THEN 'NÃO' ELSE 'SIM' END AS CONFIG_EMPRESA,
        NVL(REGEXP_REPLACE(
            CASE WHEN FALTA_TEM_ISS = 1 THEN 'Tem ISS; ' ELSE '' END ||
            CASE WHEN FALTA_ALIQ_ISS = 1 THEN 'Alíquotas de ISS; ' ELSE '' END ||
            CASE WHEN FALTA_TIPO_SERVICO = 1 THEN 'Tipo de Serviço; ' ELSE '' END ||
            CASE WHEN FALTA_COD_TRIB_MUN = 1 THEN 'Cód. Trib. Município NFS-e; ' ELSE '' END ||
            CASE WHEN FALTA_CNAE = 1 THEN 'CNAE; ' ELSE '' END ||
            CASE WHEN FALTA_NBS = 1 THEN 'Código NBS; ' ELSE '' END,
            '; $',
            ''
        ), 'Sem pendência fiscal') AS PENDENCIAS
    FROM (
        SELECT
            PROD.CODPROD,
            PROD.DESCRPROD,
            CASE WHEN NVL(PROD.TEMISS, 'N') NOT IN ('S', 'T') THEN 1 ELSE 0 END AS FALTA_TEM_ISS,
            CASE WHEN NOT EXISTS (
                SELECT 1
                FROM TGFISS ISS
                WHERE ISS.CODPROD = PROD.CODPROD
            ) THEN 1 ELSE 0 END AS FALTA_ALIQ_ISS,
            CASE WHEN PROD.CODLST IS NULL THEN 1 ELSE 0 END AS FALTA_TIPO_SERVICO,
            CASE WHEN PROD.CODTRIBMUNISS IS NULL THEN 1 ELSE 0 END AS FALTA_COD_TRIB_MUN,
            CASE WHEN PROD.CNAE IS NULL THEN 1 ELSE 0 END AS FALTA_CNAE,
            CASE WHEN PROD.CODNBS IS NULL THEN 1 ELSE 0 END AS FALTA_NBS,
            CASE WHEN NOT EXISTS (
                SELECT 1
                FROM TGFPEM PEM
                WHERE PEM.CODPROD = PROD.CODPROD
                  AND (:P_EMPRESA IS NULL OR PEM.CODEMP IN (:P_EMPRESA))
            ) THEN 1 ELSE 0 END AS FALTA_CONFIG_EMPRESA,
            CASE WHEN NVL(PROD.TEMISS, 'N') NOT IN ('S', 'T') THEN 1 ELSE 0 END +
            CASE WHEN NOT EXISTS (
                SELECT 1
                FROM TGFISS ISS
                WHERE ISS.CODPROD = PROD.CODPROD
            ) THEN 1 ELSE 0 END +
            CASE WHEN PROD.CODLST IS NULL THEN 1 ELSE 0 END +
            CASE WHEN PROD.CODTRIBMUNISS IS NULL THEN 1 ELSE 0 END +
            CASE WHEN PROD.CNAE IS NULL THEN 1 ELSE 0 END +
            CASE WHEN PROD.CODNBS IS NULL THEN 1 ELSE 0 END AS QTD_PENDENCIAS
        FROM TGFPRO PROD
        WHERE PROD.USOPROD = 'S'
          AND PROD.ATIVO = 'S'
    )
    WHERE QTD_PENDENCIAS > 0
       OR FALTA_CONFIG_EMPRESA = 1
    ORDER BY QTD_PENDENCIAS DESC, FALTA_CONFIG_EMPRESA DESC, DESCRPROD
)
WHERE ROWNUM <= 50
</snk:query>

<snk:query var="q_grd_serv_sem_mov">
SELECT *
FROM (
    SELECT
        PROD.CODPROD,
        PROD.DESCRPROD,
        ULTIMA.DTNEG AS DATA_ULTIMA_VEZ,
        TO_CHAR(ULTIMA.DTNEG, 'DD-MM-YYYY') AS DATA_ULTIMA_VEZ_FMT,
        ULTIMA.NUNOTA AS NOTA_ULTIMA_VEZ,
        ULTIMA.NOMEPARC AS ULTIMO_PARCEIRO,
        CASE WHEN ULTIMA.DTNEG IS NULL THEN 'Nunca utilizado' ELSE TO_CHAR(TRUNC(SYSDATE) - TRUNC(ULTIMA.DTNEG)) || ' dias' END AS DIAS_INATIVO,
        CASE WHEN ULTIMA.DTNEG IS NULL THEN 365 ELSE TRUNC(SYSDATE) - TRUNC(ULTIMA.DTNEG) END AS DIAS_NUMERICO
    FROM TGFPRO PROD
    LEFT JOIN (
        SELECT *
        FROM (
            SELECT ITE.CODPROD, CAB.DTNEG, CAB.NUNOTA, PAR.NOMEPARC,
                   ROW_NUMBER() OVER (PARTITION BY ITE.CODPROD ORDER BY CAB.DTNEG DESC, CAB.NUNOTA DESC) AS RNK
            FROM TGFITE ITE
            INNER JOIN TGFCAB CAB ON CAB.NUNOTA = ITE.NUNOTA
            INNER JOIN TGFPAR PAR ON PAR.CODPARC = CAB.CODPARC
            WHERE CAB.STATUSNOTA = 'L'
              AND CAB.TIPMOV = 'V'
        )
        WHERE RNK = 1
    ) ULTIMA ON ULTIMA.CODPROD = PROD.CODPROD
    WHERE PROD.USOPROD = 'S'
      AND PROD.ATIVO = 'S'
      AND NOT EXISTS (
          SELECT 1
          FROM TGFITE ITE_F
          INNER JOIN TGFCAB CAB_F ON CAB_F.NUNOTA = ITE_F.NUNOTA
          INNER JOIN TGFPAR PAR_F ON PAR_F.CODPARC = CAB_F.CODPARC
          INNER JOIN TSICID CID_F ON CID_F.CODCID = PAR_F.CODCID
          WHERE ITE_F.CODPROD = PROD.CODPROD
            AND CAB_F.STATUSNOTA = 'L'
            AND CAB_F.TIPMOV = 'V'
            AND (:P_DATA_INI IS NULL OR CAB_F.DTNEG >= :P_DATA_INI)
            AND (:P_DATA_FIM IS NULL OR CAB_F.DTNEG <= :P_DATA_FIM)
            AND (:P_EMPRESA IS NULL OR CAB_F.CODEMP IN (:P_EMPRESA))
            AND (:P_TOP IS NULL OR CAB_F.CODTIPOPER IN (:P_TOP))
            AND (:P_UF IS NULL OR CID_F.UF IN (:P_UF))
      )
    ORDER BY DIAS_NUMERICO DESC, ULTIMA.DTNEG ASC NULLS FIRST, PROD.DESCRPROD
)
WHERE ROWNUM <= 50
</snk:query>

<snk:query var="q_cht_serv_sem_mov">
SELECT *
FROM (
    SELECT
        PROD.DESCRPROD AS SERVICO,
        CASE WHEN ULTIMA.DTNEG IS NULL THEN 365 ELSE TRUNC(SYSDATE) - TRUNC(ULTIMA.DTNEG) END AS DIAS_NUMERICO,
        TO_CHAR(CASE WHEN ULTIMA.DTNEG IS NULL THEN 365 ELSE TRUNC(SYSDATE) - TRUNC(ULTIMA.DTNEG) END, 'FM999999999990D00', 'NLS_NUMERIC_CHARACTERS = ''.,''') AS DIAS_JS
    FROM TGFPRO PROD
    LEFT JOIN (
        SELECT ITE.CODPROD, MAX(CAB.DTNEG) AS DTNEG
        FROM TGFITE ITE
        INNER JOIN TGFCAB CAB ON CAB.NUNOTA = ITE.NUNOTA
        WHERE CAB.STATUSNOTA = 'L'
          AND CAB.TIPMOV = 'V'
        GROUP BY ITE.CODPROD
    ) ULTIMA ON ULTIMA.CODPROD = PROD.CODPROD
    WHERE PROD.USOPROD = 'S'
      AND PROD.ATIVO = 'S'
      AND NOT EXISTS (
          SELECT 1
          FROM TGFITE ITE_F
          INNER JOIN TGFCAB CAB_F ON CAB_F.NUNOTA = ITE_F.NUNOTA
          INNER JOIN TGFPAR PAR_F ON PAR_F.CODPARC = CAB_F.CODPARC
          INNER JOIN TSICID CID_F ON CID_F.CODCID = PAR_F.CODCID
          WHERE ITE_F.CODPROD = PROD.CODPROD
            AND CAB_F.STATUSNOTA = 'L'
            AND CAB_F.TIPMOV = 'V'
            AND (:P_DATA_INI IS NULL OR CAB_F.DTNEG >= :P_DATA_INI)
            AND (:P_DATA_FIM IS NULL OR CAB_F.DTNEG <= :P_DATA_FIM)
            AND (:P_EMPRESA IS NULL OR CAB_F.CODEMP IN (:P_EMPRESA))
            AND (:P_TOP IS NULL OR CAB_F.CODTIPOPER IN (:P_TOP))
            AND (:P_UF IS NULL OR CID_F.UF IN (:P_UF))
      )
    ORDER BY DIAS_NUMERICO DESC, PROD.DESCRPROD
)
WHERE ROWNUM <= 10
</snk:query>

<snk:query var="q_servicos_mais_utilizados">
SELECT *
FROM (
    SELECT
        PRO.DESCRPROD AS SERVICO,
        SUM(ITE.QTDNEG) AS QTD,
        TO_CHAR(SUM(ITE.QTDNEG), 'FM999999999990D00', 'NLS_NUMERIC_CHARACTERS = ''.,''') AS QTD_JS,
        SUM(ITE.VLRTOT) AS VALOR,
        TO_CHAR(SUM(ITE.VLRTOT), 'FM999999999990D00', 'NLS_NUMERIC_CHARACTERS = ''.,''') AS VALOR_JS
    FROM TGFITE ITE
    INNER JOIN TGFCAB CAB ON ITE.NUNOTA = CAB.NUNOTA
    INNER JOIN TGFPRO PRO ON ITE.CODPROD = PRO.CODPROD
    INNER JOIN TGFPAR PAR ON CAB.CODPARC = PAR.CODPARC
    INNER JOIN TSICID CID ON PAR.CODCID = CID.CODCID
    INNER JOIN TSIUFS UFS ON CID.UF = UFS.CODUF
    WHERE CAB.STATUSNOTA = 'L'
      AND CAB.TIPMOV = 'V'
      AND PRO.USOPROD = 'S'
      AND (:P_DATA_INI IS NULL OR CAB.DTNEG >= :P_DATA_INI)
      AND (:P_DATA_FIM IS NULL OR CAB.DTNEG <= :P_DATA_FIM)
      AND (:P_EMPRESA IS NULL OR CAB.CODEMP IN (:P_EMPRESA))
      AND (:P_TOP IS NULL OR CAB.CODTIPOPER IN (:P_TOP))
      AND (:P_UF IS NULL OR UFS.CODUF IN (:P_UF))
    GROUP BY PRO.DESCRPROD
    ORDER BY SUM(ITE.QTDNEG) DESC
)
WHERE ROWNUM <= 10
</snk:query>

<snk:query var="q_resumo_iss_municipio">
WITH BASE AS (
    SELECT
        CID.NOMECID,
        UFS.UF,
        SUM(NVL(ITE.VLRISS, 0)) AS VALOR_ISS
    FROM TGFITE ITE
    INNER JOIN TGFCAB CAB ON ITE.NUNOTA = CAB.NUNOTA
    INNER JOIN TSICID CID ON CAB.CODCIDPREST = CID.CODCID
    INNER JOIN TSIUFS UFS ON CID.UF = UFS.CODUF
    INNER JOIN TGFPRO PRO ON ITE.CODPROD = PRO.CODPROD
    WHERE CAB.STATUSNOTA = 'L'
      AND CAB.TIPMOV = 'V'
      AND PRO.USOPROD = 'S'
      AND (:P_DATA_INI IS NULL OR CAB.DTNEG >= :P_DATA_INI)
      AND (:P_DATA_FIM IS NULL OR CAB.DTNEG <= :P_DATA_FIM)
      AND (:P_EMPRESA IS NULL OR CAB.CODEMP IN (:P_EMPRESA))
      AND (:P_TOP IS NULL OR CAB.CODTIPOPER IN (:P_TOP))
      AND (:P_UF IS NULL OR UFS.CODUF IN (:P_UF))
    GROUP BY CID.NOMECID, UFS.UF
    HAVING SUM(NVL(ITE.VLRISS, 0)) > 0
)
SELECT
    COUNT(*) AS QTD_MUNICIPIOS,
    TO_CHAR(COUNT(*), 'FM999G999G990', 'NLS_NUMERIC_CHARACTERS = '',.''') AS QTD_MUNICIPIOS_FMT,
    NVL(SUM(VALOR_ISS), 0) AS TOTAL_ISS,
    TO_CHAR(NVL(SUM(VALOR_ISS), 0), 'FM999G999G999G990D00', 'NLS_NUMERIC_CHARACTERS = '',.''') AS TOTAL_ISS_FMT,
    TO_CHAR(NVL(MAX(VALOR_ISS), 0), 'FM999G999G999G990D00', 'NLS_NUMERIC_CHARACTERS = '',.''') AS MAIOR_ISS_FMT
FROM BASE
</snk:query>

<snk:query var="q_grd_iss_municipio">
SELECT
    NOMECID,
    DESCRICAO,
    UF,
    VALOR_ISS,
    TO_CHAR(VALOR_ISS, 'FM999G999G999G990D00', 'NLS_NUMERIC_CHARACTERS = '',.''') AS VALOR_ISS_FMT,
    (VALOR_ISS / NULLIF(SUM(VALOR_ISS) OVER(), 0)) * 100 AS PERC,
    TO_CHAR((VALOR_ISS / NULLIF(SUM(VALOR_ISS) OVER(), 0)) * 100, 'FM990D00', 'NLS_NUMERIC_CHARACTERS = '',.''') AS PERC_FMT
FROM (
    SELECT
        CID.NOMECID,
        UFS.DESCRICAO,
        UFS.UF,
        SUM(NVL(ITE.VLRISS, 0)) AS VALOR_ISS
    FROM TGFITE ITE
    INNER JOIN TGFCAB CAB ON ITE.NUNOTA = CAB.NUNOTA
    INNER JOIN TSICID CID ON CAB.CODCIDPREST = CID.CODCID
    INNER JOIN TSIUFS UFS ON CID.UF = UFS.CODUF
    INNER JOIN TGFPRO PRO ON ITE.CODPROD = PRO.CODPROD
    WHERE CAB.STATUSNOTA = 'L'
      AND CAB.TIPMOV = 'V'
      AND PRO.USOPROD = 'S'
      AND (:P_DATA_INI IS NULL OR CAB.DTNEG >= :P_DATA_INI)
      AND (:P_DATA_FIM IS NULL OR CAB.DTNEG <= :P_DATA_FIM)
      AND (:P_EMPRESA IS NULL OR CAB.CODEMP IN (:P_EMPRESA))
      AND (:P_TOP IS NULL OR CAB.CODTIPOPER IN (:P_TOP))
      AND (:P_UF IS NULL OR UFS.CODUF IN (:P_UF))
    GROUP BY CID.NOMECID, UFS.DESCRICAO, UFS.UF
    HAVING SUM(NVL(ITE.VLRISS, 0)) > 0
)
ORDER BY VALOR_ISS DESC
</snk:query>

<snk:query var="q_cht_iss_municipio">
SELECT *
FROM (
    SELECT
        CID.NOMECID AS CIDADE,
        SUM(NVL(ITE.VLRISS, 0)) AS VALOR,
        TO_CHAR(SUM(NVL(ITE.VLRISS, 0)), 'FM999999999990D00', 'NLS_NUMERIC_CHARACTERS = ''.,''') AS VALOR_JS
    FROM TGFITE ITE
    INNER JOIN TGFCAB CAB ON ITE.NUNOTA = CAB.NUNOTA
    INNER JOIN TSICID CID ON CAB.CODCIDPREST = CID.CODCID
    INNER JOIN TSIUFS UFS ON CID.UF = UFS.CODUF
    INNER JOIN TGFPRO PRO ON ITE.CODPROD = PRO.CODPROD
    WHERE CAB.STATUSNOTA = 'L'
      AND CAB.TIPMOV = 'V'
      AND PRO.USOPROD = 'S'
      AND (:P_DATA_INI IS NULL OR CAB.DTNEG >= :P_DATA_INI)
      AND (:P_DATA_FIM IS NULL OR CAB.DTNEG <= :P_DATA_FIM)
      AND (:P_EMPRESA IS NULL OR CAB.CODEMP IN (:P_EMPRESA))
      AND (:P_TOP IS NULL OR CAB.CODTIPOPER IN (:P_TOP))
      AND (:P_UF IS NULL OR UFS.CODUF IN (:P_UF))
    GROUP BY CID.NOMECID
    HAVING SUM(NVL(ITE.VLRISS, 0)) > 0
    ORDER BY VALOR DESC
)
WHERE ROWNUM <= 10
</snk:query>

<snk:query var="q_cht_evolucao">
SELECT
    TO_CHAR(CAB.DTNEG, 'MM/YYYY') AS MES,
    COUNT(CAB.NUNOTA) AS QTD,
    TO_CHAR(
        COUNT(CAB.NUNOTA),
        'FM999999999990D00',
        'NLS_NUMERIC_CHARACTERS = ''.,'''
    ) AS QTD_JS
FROM TGFCAB CAB
INNER JOIN TGFPAR PAR ON PAR.CODPARC = CAB.CODPARC
INNER JOIN TSICID CID ON CID.CODCID = PAR.CODCID
WHERE CAB.STATUSNOTA = 'L'
  AND CAB.TIPMOV = 'V'
  AND CAB.VLRISS = 0
  AND (:P_DATA_INI IS NULL OR CAB.DTNEG >= :P_DATA_INI)
  AND (:P_DATA_FIM IS NULL OR CAB.DTNEG <= :P_DATA_FIM)
  AND (:P_EMPRESA IS NULL OR CAB.CODEMP IN (:P_EMPRESA))
  AND (:P_TOP IS NULL OR CAB.CODTIPOPER IN (:P_TOP))
  AND (:P_UF IS NULL OR CID.UF IN (:P_UF))
  AND EXISTS (
        SELECT 1
        FROM TGFITE ITE
        INNER JOIN TGFPRO PRO ON PRO.CODPROD = ITE.CODPROD
        WHERE ITE.NUNOTA = CAB.NUNOTA
          AND PRO.USOPROD = 'S'
  )
GROUP BY
    TO_CHAR(CAB.DTNEG, 'MM/YYYY'),
    TO_CHAR(CAB.DTNEG, 'YYYYMM')
ORDER BY
    TO_CHAR(CAB.DTNEG, 'YYYYMM')
</snk:query>


<snk:query var="q_grd_iss_zerado">
WITH CAB_FILTRADA AS (
    SELECT /*+ MATERIALIZE */
        CAB.NUNOTA,
        PAR.NOMEPARC
    FROM TGFCAB CAB
    INNER JOIN TGFPAR PAR ON PAR.CODPARC = CAB.CODPARC
    INNER JOIN TSICID CID ON CID.CODCID = PAR.CODCID
    WHERE CAB.STATUSNOTA = 'L'
      AND CAB.TIPMOV = 'V'
      AND CAB.VLRISS = 0
      AND (:P_DATA_INI IS NULL OR CAB.DTNEG >= :P_DATA_INI)
      AND (:P_DATA_FIM IS NULL OR CAB.DTNEG <= :P_DATA_FIM)
      AND (:P_EMPRESA IS NULL OR CAB.CODEMP IN (:P_EMPRESA))
      AND (:P_TOP IS NULL OR CAB.CODTIPOPER IN (:P_TOP))
      AND (:P_UF IS NULL OR CID.UF IN (:P_UF))
),

RESUMO_NOTA AS (
    SELECT
        CAB.NUNOTA,
        CAB.NOMEPARC,
        SUM(ITE.VLRTOT) AS VALOR_NOTA
    FROM CAB_FILTRADA CAB
    INNER JOIN TGFITE ITE ON ITE.NUNOTA = CAB.NUNOTA
    WHERE EXISTS (
        SELECT 1
        FROM TGFPRO PRO
        WHERE PRO.CODPROD = ITE.CODPROD
          AND PRO.USOPROD = 'S'
    )
    GROUP BY CAB.NUNOTA, CAB.NOMEPARC
)

SELECT *
FROM (
    SELECT
        R.NUNOTA,
        R.NOMEPARC,
        R.VALOR_NOTA,
        TO_CHAR(
            R.VALOR_NOTA,
            'FM999G999G999G990D00',
            'NLS_NUMERIC_CHARACTERS = '',.'''
        ) AS VALOR_NOTA_FMT
    FROM RESUMO_NOTA R
    ORDER BY R.VALOR_NOTA DESC
)
WHERE ROWNUM <= 10
</snk:query>

<snk:query var="q_cht_clientes_iss_zerado">
SELECT *
FROM (
    SELECT
        PAR.NOMEPARC AS CLIENTE,
        SUM(ITE.VLRTOT) AS TOTAL,
        TO_CHAR(
            SUM(ITE.VLRTOT),
            'FM999999999990D00',
            'NLS_NUMERIC_CHARACTERS = ''.,'''
        ) AS TOTAL_JS
    FROM TGFCAB CAB
    INNER JOIN TGFPAR PAR ON PAR.CODPARC = CAB.CODPARC
    INNER JOIN TSICID CID ON CID.CODCID = PAR.CODCID
    INNER JOIN TGFITE ITE ON ITE.NUNOTA = CAB.NUNOTA
    INNER JOIN TGFPRO PRO ON PRO.CODPROD = ITE.CODPROD
    WHERE CAB.STATUSNOTA = 'L'
      AND CAB.TIPMOV = 'V'
      AND CAB.VLRISS = 0
      AND PRO.USOPROD = 'S'
      AND (:P_DATA_INI IS NULL OR CAB.DTNEG >= :P_DATA_INI)
      AND (:P_DATA_FIM IS NULL OR CAB.DTNEG <= :P_DATA_FIM)
      AND (:P_EMPRESA IS NULL OR CAB.CODEMP IN (:P_EMPRESA))
      AND (:P_TOP IS NULL OR CAB.CODTIPOPER IN (:P_TOP))
      AND (:P_UF IS NULL OR CID.UF IN (:P_UF))
    GROUP BY PAR.NOMEPARC
    ORDER BY TOTAL DESC
)
WHERE ROWNUM <= 5
</snk:query>

<snk:query var="q_grd_iss_zerado_detalhe">
WITH CAB_FILTRADA AS (
    SELECT /*+ MATERIALIZE */
        CAB.NUNOTA,
        CAB.DTNEG,
        CAB.CODEMP,
        CAB.CODTIPOPER,
        CAB.ISSRETIDO,
        PAR.NOMEPARC
    FROM TGFCAB CAB
    INNER JOIN TGFPAR PAR ON PAR.CODPARC = CAB.CODPARC
    INNER JOIN TSICID CID ON CID.CODCID = PAR.CODCID
    WHERE CAB.STATUSNOTA = 'L'
      AND CAB.TIPMOV = 'V'
      AND CAB.VLRISS = 0
      AND (:P_DATA_INI IS NULL OR CAB.DTNEG >= :P_DATA_INI)
      AND (:P_DATA_FIM IS NULL OR CAB.DTNEG <= :P_DATA_FIM)
      AND (:P_EMPRESA IS NULL OR CAB.CODEMP IN (:P_EMPRESA))
      AND (:P_TOP IS NULL OR CAB.CODTIPOPER IN (:P_TOP))
      AND (:P_UF IS NULL OR CID.UF IN (:P_UF))
),

BASE_ITENS AS (
    SELECT
        CAB.NUNOTA,
        CAB.DTNEG,
        CAB.CODEMP,
        CAB.CODTIPOPER,
        CAB.NOMEPARC,
        CAB.ISSRETIDO AS ISS_RETIDO_CAB,
        ITE.SEQUENCIA,
        ITE.CODTRIBISS,
        ITE.VLRTOT AS VALOR_BRUTO,
        PRO.DESCRPROD
    FROM CAB_FILTRADA CAB
    INNER JOIN TGFITE ITE ON ITE.NUNOTA = CAB.NUNOTA
    INNER JOIN TGFPRO PRO ON PRO.CODPROD = ITE.CODPROD
    WHERE PRO.USOPROD = 'S'
),

ISS_AGR AS (
    SELECT
        D.NUNOTA,
        D.SEQUENCIA,
        SUM(NVL(D.VALOR, 0)) AS VLR_ISS
    FROM TGFDIN D
    INNER JOIN BASE_ITENS ITE
        ON ITE.NUNOTA = D.NUNOTA
       AND ITE.SEQUENCIA = D.SEQUENCIA
    WHERE D.CODIMP = 4
    GROUP BY D.NUNOTA, D.SEQUENCIA
),

IMPOSTOS_AGR AS (
    SELECT
        M.NUNOTA,
        M.SEQUENCIA,
        SUM(CASE WHEN M.CODIMP = 2 THEN NVL(M.VALOR, 0) ELSE 0 END) AS VLR_PIS,
        SUM(CASE WHEN M.CODIMP = 3 THEN NVL(M.VALOR, 0) ELSE 0 END) AS VLR_COFINS,
        SUM(CASE WHEN M.CODIMP = 4 THEN NVL(M.VALOR, 0) ELSE 0 END) AS VLR_CSLL,
        SUM(CASE WHEN M.CODIMP = 7 THEN NVL(M.VALOR, 0) ELSE 0 END) AS VLR_IR,
        SUM(CASE WHEN M.CODIMP = 6 THEN NVL(M.VALOR, 0) ELSE 0 END) AS VLR_INSS
    FROM TGFIMN M
    INNER JOIN BASE_ITENS ITE
        ON ITE.NUNOTA = M.NUNOTA
       AND ITE.SEQUENCIA = M.SEQUENCIA
    WHERE M.CODIMP IN (2, 3, 4, 6, 7)
    GROUP BY M.NUNOTA, M.SEQUENCIA
)

SELECT
    ITE.NUNOTA,
    ITE.DTNEG,
    TO_CHAR(ITE.DTNEG, 'DD-MM-YYYY') AS DTNEG_FMT,
    ITE.CODEMP,
    ITE.NOMEPARC,
    ITE.DESCRPROD,
    ITE.CODTIPOPER,
    ITE.ISS_RETIDO_CAB,

    ITE.VALOR_BRUTO,
    TO_CHAR(ITE.VALOR_BRUTO, 'FM999G999G999G990D00', 'NLS_NUMERIC_CHARACTERS = '',.''') AS VALOR_BRUTO_FMT,

    NVL(ISS.VLR_ISS, 0) AS VLR_ISS,
    TO_CHAR(NVL(ISS.VLR_ISS, 0), 'FM999G999G999G990D00', 'NLS_NUMERIC_CHARACTERS = '',.''') AS VLR_ISS_FMT,

    NVL(IMP.VLR_PIS, 0) AS VLR_PIS,
    TO_CHAR(NVL(IMP.VLR_PIS, 0), 'FM999G999G999G990D00', 'NLS_NUMERIC_CHARACTERS = '',.''') AS VLR_PIS_FMT,

    NVL(IMP.VLR_COFINS, 0) AS VLR_COFINS,
    TO_CHAR(NVL(IMP.VLR_COFINS, 0), 'FM999G999G999G990D00', 'NLS_NUMERIC_CHARACTERS = '',.''') AS VLR_COFINS_FMT,

    NVL(IMP.VLR_CSLL, 0) AS VLR_CSLL,
    TO_CHAR(NVL(IMP.VLR_CSLL, 0), 'FM999G999G999G990D00', 'NLS_NUMERIC_CHARACTERS = '',.''') AS VLR_CSLL_FMT,

    NVL(IMP.VLR_IR, 0) AS VLR_IR,
    TO_CHAR(NVL(IMP.VLR_IR, 0), 'FM999G999G999G990D00', 'NLS_NUMERIC_CHARACTERS = '',.''') AS VLR_IR_FMT,

    NVL(IMP.VLR_INSS, 0) AS VLR_INSS,
    TO_CHAR(NVL(IMP.VLR_INSS, 0), 'FM999G999G999G990D00', 'NLS_NUMERIC_CHARACTERS = '',.''') AS VLR_INSS_FMT,

    ITE.VALOR_BRUTO - (
        NVL(IMP.VLR_PIS, 0) + NVL(IMP.VLR_COFINS, 0) + NVL(IMP.VLR_CSLL, 0) +
        NVL(IMP.VLR_IR, 0) + NVL(IMP.VLR_INSS, 0) +
        CASE WHEN ITE.CODTRIBISS = 1 THEN NVL(ISS.VLR_ISS, 0) ELSE 0 END
    ) AS VALOR_LIQUIDO,
    TO_CHAR(
        ITE.VALOR_BRUTO - (
            NVL(IMP.VLR_PIS, 0) + NVL(IMP.VLR_COFINS, 0) + NVL(IMP.VLR_CSLL, 0) +
            NVL(IMP.VLR_IR, 0) + NVL(IMP.VLR_INSS, 0) +
            CASE WHEN ITE.CODTRIBISS = 1 THEN NVL(ISS.VLR_ISS, 0) ELSE 0 END
        ),
        'FM999G999G999G990D00',
        'NLS_NUMERIC_CHARACTERS = '',.'''
    ) AS VALOR_LIQUIDO_FMT
FROM BASE_ITENS ITE
LEFT JOIN ISS_AGR ISS
    ON ISS.NUNOTA = ITE.NUNOTA
   AND ISS.SEQUENCIA = ITE.SEQUENCIA
LEFT JOIN IMPOSTOS_AGR IMP
    ON IMP.NUNOTA = ITE.NUNOTA
   AND IMP.SEQUENCIA = ITE.SEQUENCIA
ORDER BY ITE.DTNEG DESC, ITE.NUNOTA DESC, ITE.SEQUENCIA
</snk:query>


<div id="dados-graficos-auditoria" style="display:none;">
    <div id="dados-iss-evolucao">
        <c:forEach items="${q_cht_evolucao.rows}" var="row">
            <span class="iss-evolucao-row"
                  data-mes="<c:out value='${row.MES}'/>"
                  data-qtd="<c:out value='${row.QTD_JS}'/>"></span>
        </c:forEach>
    </div>

    <div id="dados-clientes-iss">
        <c:forEach items="${q_cht_clientes_iss_zerado.rows}" var="row">
            <span class="cliente-iss-row"
                  data-total="<c:out value='${row.TOTAL_JS}'/>"><c:out value="${row.CLIENTE}"/></span>
        </c:forEach>
    </div>

    <div id="dados-servicos-sem-mov">
        <c:forEach items="${q_cht_serv_sem_mov.rows}" var="row">
            <span class="servico-sem-mov-row"
                  data-dias="<c:out value='${row.DIAS_JS}'/>"><c:out value="${row.SERVICO}"/></span>
        </c:forEach>
    </div>

    <div id="dados-servicos-utilizados">
        <c:forEach items="${q_servicos_mais_utilizados.rows}" var="row">
            <span class="servico-utilizado-row"
                  data-qtd="<c:out value='${row.QTD_JS}'/>"
                  data-valor="<c:out value='${row.VALOR_JS}'/>"><c:out value="${row.SERVICO}"/></span>
        </c:forEach>
    </div>

    <div id="dados-iss-municipio">
        <c:forEach items="${q_cht_iss_municipio.rows}" var="row">
            <span class="iss-municipio-row"
                  data-valor="<c:out value='${row.VALOR_JS}'/>"><c:out value="${row.CIDADE}"/></span>
        </c:forEach>
    </div>
</div>


<div class="app">
    <aside class="sidebar">
        <div class="brand" onclick="voltarMenuInicial()" title="Voltar ao menu inicial">
            <div class="brand-icon">
                <i class="fa-solid fa-bars"></i>
            </div>
            <span>Menu Inicial</span>
        </div>

        <div class="nav-title">Dashboard</div>  
        <button class="nav-item" type="button" onclick="voltarMenuInicial()">
            <i class="fa-solid fa-house"></i> Início
        </button>

        <button class="nav-item" type="button" onclick="openLevel('lvl_tomadores')">
            <i class="fa-solid fa-briefcase"></i> Análise Tomadores
        </button>

        <button class="nav-item" type="button" onclick="openLevel('lvl_fat_cidade')">
            <i class="fa-solid fa-city"></i> Movimento por Município
        </button>

        <button class="nav-item" id="btnMenuIssMunicipio" type="button" onclick="abrirIssMunicipio()">
            <i class="fa-solid fa-map-location-dot"></i> ISS por Município
        </button>

        <button class="nav-item active" type="button" onclick="openLevel('lvl_mapa_tributario')">
            <i class="fa-solid fa-layer-group"></i> Auditoria de Impostos
        </button>

        <button class="nav-item" id="btnMenuServicosSemMov" type="button" onclick="toggleServicosSemMov()">
            <i class="fa-solid fa-screwdriver-wrench"></i> Serviços
        </button>
        <button class="nav-item" type="button" onclick="openLevel('lvl_servicos_prestados_tomados')">
            <i class="fa-solid fa-clipboard-list"></i> Prestados / Tomados
        </button>

    
    </aside>

    <main class="main">
        <section class="topbar">
            <div class="topbar-left">
                <div class="title-icon"><i class="fa-solid fa-scale-balanced"></i></div>
                <div>
                    <h1>Mapa Tributário - Serviços</h1>
                </div>
            </div>
        </section>

        <section class="kpi-grid">
            <c:forEach items="${q_mapa_resumo.rows}" var="mapa">
                <article class="kpi blue">
                    <div class="kpi-icon"><i class="fa-solid fa-file-invoice"></i></div>
                    <div>
                        <span class="kpi-label">Notas analisadas</span>
                        <div class="kpi-value">${mapa.QTD_NOTAS_FMT}</div>
                    </div>
                </article>

                <article class="kpi">
                    <div class="kpi-icon"><i class="fa-solid fa-sack-dollar"></i></div>
                    <div>
                        <span class="kpi-label">Valor bruto</span>
                        <div class="kpi-value">R$ ${mapa.VALOR_BRUTO_FMT}</div>
                    </div>
                </article>

                <article class="kpi warning">
                    <div class="kpi-icon"><i class="fa-solid fa-receipt"></i></div>
                    <div>
                        <span class="kpi-label">Total de impostos</span>
                        <div class="kpi-value">R$ ${mapa.TOTAL_IMPOSTOS_FMT}</div>
                    </div>
                </article>
            </c:forEach>
        </section>

        <section class="dash-grid">
            <section class="inline-detail" id="servicosSemMovInline">
                <c:forEach items="${q_resumo_serv_cad_incompleto.rows}" var="cad">
                    <article class="card detail-card service-card span-12">
                        <div class="detail-card-main">
                            <div class="detail-card-icon">
                                <i class="fa-solid fa-clipboard-check"></i>
                            </div>
                            <div>
                                <div class="detail-card-label">Cadastro de serviços incompleto</div>
                                <div class="detail-card-value">${cad.QTD_SERVICOS_INCOMPLETOS_FMT} serviço(s) para revisar</div>
                                <div class="detail-card-sub">ISS: ${cad.FALTA_TEM_ISS_FMT} | Alíquotas: ${cad.FALTA_ALIQ_ISS_FMT} | Tipo: ${cad.FALTA_TIPO_SERVICO_FMT} | Cód. município: ${cad.FALTA_COD_TRIB_MUN_FMT} | CNAE: ${cad.FALTA_CNAE_FMT} | NBS: ${cad.FALTA_NBS_FMT} | sem config. empresa: ${cad.FALTA_CONFIG_EMPRESA_FMT}</div>
                            </div>
                        </div>
                        <button class="detail-card-action" type="button" onclick="document.getElementById('servicosCadastroIncompleto').scrollIntoView({ behavior: 'smooth', block: 'start' });">
                            Ver pendências
                        </button>
                    </article>
                </c:forEach>

                <article class="card span-12" id="servicosCadastroIncompleto">
                    <div class="card-head">
                        <h2 class="card-title warning"><i class="fa-solid fa-clipboard-list"></i> Cadastro de serviços incompleto</h2>
                        <span class="badge">Duplo clique para corrigir</span>
                    </div>
                    <div class="table-wrapper">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th class="col-cod">Cód.</th>
                                    <th>Serviço</th>
                                    <th class="col-qtd">Qtd.</th>
                                    <th class="col-config">Config. Empresa</th>
                                    <th>Pendências</th>
                                </tr>
                            </thead>
                            <tbody>
                                <c:forEach items="${q_grd_serv_cad_incompleto.rows}" var="row">
                                    <tr class="row-warning clickable-row" ondblclick="abrirCadastroServico('${row.CODPROD}')" title="Duplo clique para abrir o cadastro do serviço">
                                        <td class="col-cod">${row.CODPROD}</td>
                                        <td><c:out value="${row.DESCRPROD}"/></td>
                                        <td class="col-qtd">${row.QTD_PENDENCIAS_FMT}</td>
                                        <td class="col-config">${row.CONFIG_EMPRESA}</td>
                                        <td><c:out value="${row.PENDENCIAS}"/></td>
                                    </tr>
                                </c:forEach>
                            </tbody>
                        </table>
                    </div>
                </article>

                <c:forEach items="${q_resumo_serv_sem_mov.rows}" var="serv">
                    <article class="card detail-card service-card span-12">
                        <div class="detail-card-main">
                            <div class="detail-card-icon">
                                <i class="fa-solid fa-screwdriver-wrench"></i>
                            </div>
                            <div>
                                <div class="detail-card-label">Serviços sem movimento</div>
                                <div class="detail-card-value">${serv.QTD_SERVICOS_FMT} serviço(s) sem uso no período</div>
                                <div class="detail-card-sub">${serv.QTD_NUNCA_USADOS_FMT} nunca utilizado(s) | maior inatividade: ${serv.MAIOR_INATIVIDADE_FMT} dias</div>
                            </div>
                        </div>
                        <button class="detail-card-action" type="button" onclick="toggleServicosSemMov()">
                            Ocultar detalhe
                        </button>
                    </article>
                </c:forEach>

                <article class="card span-6">
                    <div class="card-head">
                        <h2 class="card-title"><i class="fa-solid fa-chart-pie"></i> Serviços mais utilizados</h2>
                    </div>
                    <div id="chartServicosMaisUtilizados" class="chart-box"></div>
                </article>

                <article class="card span-6">
                    <div class="card-head">
                        <h2 class="card-title warning"><i class="fa-solid fa-chart-bar"></i> Top 10 serviços parados</h2>
                    </div>
                    <div id="chartServicosSemMov" class="chart-box"></div>
                </article>

                <article class="card span-12">
                    <div class="card-head">
                        <h2 class="card-title warning"><i class="fa-solid fa-table-list"></i> Serviços sem movimento</h2>
                    </div>
                    <div class="table-wrapper">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th class="align-center">Cód.</th>
                                    <th>Serviço</th>
                                    <th class="align-center">Dt. últ. nota</th>
                                    <th class="align-center">Últ. nota</th>
                                    <th>Último parceiro</th>
                                    <th>Inatividade</th>
                                </tr>
                            </thead>
                            <tbody>
                                <c:forEach items="${q_grd_serv_sem_mov.rows}" var="row">
                                    <tr>
                                        <td class="align-center">${row.CODPROD}</td>
                                        <td><c:out value="${row.DESCRPROD}"/></td>
                                        <td class="align-center">${row.DATA_ULTIMA_VEZ_FMT}</td>
                                        <td class="align-center">${row.NOTA_ULTIMA_VEZ}</td>
                                        <td><c:out value="${row.ULTIMO_PARCEIRO}"/></td>
                                        <td>${row.DIAS_INATIVO}</td>
                                    </tr>
                                </c:forEach>
                            </tbody>
                        </table>
                    </div>
                </article>
            </section>

            <section class="inline-detail" id="issMunicipioInline">
                <c:forEach items="${q_resumo_iss_municipio.rows}" var="issmun">
                    <article class="card detail-card service-card span-12">
                        <div class="detail-card-main">
                            <div class="detail-card-icon">
                                <i class="fa-solid fa-map-location-dot"></i>
                            </div>
                            <div>
                                <div class="detail-card-label">Análise de ISS por Município</div>
                                <div class="detail-card-value">R$ ${issmun.TOTAL_ISS_FMT}</div>
                                <div class="detail-card-sub">${issmun.QTD_MUNICIPIOS_FMT} município(s) com ISS | maior concentração: R$ ${issmun.MAIOR_ISS_FMT}</div>
                            </div>
                        </div>
                        <button class="detail-card-action" type="button" onclick="toggleIssMunicipio()">
                            Ocultar detalhe
                        </button>
                    </article>
                </c:forEach>

                <article class="card span-6">
                    <div class="card-head">
                        <h2 class="card-title warning"><i class="fa-solid fa-chart-column"></i> Top 10 cidades por ISS</h2>
                    </div>
                    <div id="chartIssMunicipio" class="chart-box"></div>
                </article>

                <article class="card span-6">
                    <div class="card-head">
                        <h2 class="card-title warning"><i class="fa-solid fa-table-list"></i> Ranking de municípios</h2>
                    </div>
                    <div class="table-wrapper">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Cidade</th>
                                    <th>UF</th>
                                    <th>Estado</th>
                                    <th class="align-right">ISS Retido</th>
                                    <th class="align-right">%</th>
                                </tr>
                            </thead>
                            <tbody>
                                <c:forEach items="${q_grd_iss_municipio.rows}" var="row">
                                    <tr>
                                        <td><c:out value="${row.NOMECID}"/></td>
                                        <td>${row.UF}</td>
                                        <td><c:out value="${row.DESCRICAO}"/></td>
                                        <td class="align-right">R$ ${row.VALOR_ISS_FMT}</td>
                                        <td class="align-right">${row.PERC_FMT}%</td>
                                    </tr>
                                </c:forEach>
                            </tbody>
                        </table>
                    </div>
                </article>
            </section>

            <c:forEach items="${q_mapa_resumo.rows}" var="iss">
                <article class="card detail-card span-12">
                    <div class="detail-card-main">
                        <div class="detail-card-icon">
                            <i class="fa-solid fa-file-circle-exclamation"></i>
                        </div>
                        <div>
                            <div class="detail-card-label">Auditoria Fiscal - Impostos</div>
                            <div class="detail-card-value">${iss.QTD_NOTAS_ISS_ZERADO} nota(s) com ISS zerado</div>
                            <div class="detail-card-sub">Total em possivel inconsistencia: R$ ${iss.VALOR_TOTAL_ISS_ZERADO_FMT}</div>
                        </div>
                    </div>
                    <button class="detail-card-action" id="btnIssDetalhe" type="button" onclick="toggleIssDetalhe()">
                        Ver detalhe completo
                    </button>
                </article>
            </c:forEach>

            <section class="inline-detail" id="issDetalheInline">
                <article class="card span-6">
                    <div class="card-head">
                        <h2 class="card-title danger"><i class="fa-solid fa-chart-column"></i> Evolução mensal do ISS zerado</h2>
                    </div>
                    <div id="chartIssDetalheEvolucao" class="chart-box"></div>
                </article>

                <article class="card span-6">
                    <div class="card-head">
                        <h2 class="card-title danger"><i class="fa-solid fa-ranking-star"></i> Top 5 clientes com ISS zerado</h2>
                    </div>
                    <div id="chartIssClientes" class="chart-box"></div>
                </article>

                <article class="card span-12">
                    <div class="card-head">
                        <h2 class="card-title danger"><i class="fa-solid fa-table-list"></i> Detalhamento completo - Auditoria Fiscal</h2>
                    </div>
                    <div class="table-wrapper detail-table-wrapper">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th class="align-center">Nota</th>
                                    <th class="align-center">Data</th>
                                    <th>Cliente</th>
                                    <th>Serviço</th>
                                    <th class="align-center">TOP</th>
                                    <th class="align-right">Total Bruto</th>
                                    <th class="align-center">ISS Retido</th>
                                    <th class="align-right">ISS</th>
                                    <th class="align-right">PIS</th>
                                    <th class="align-right">COFINS</th>
                                    <th class="align-right">CSLL</th>
                                    <th class="align-right">IRRF</th>
                                    <th class="align-right">INSS</th>
                                    <th class="align-right">Valor Líquido</th>
                                </tr>
                            </thead>
                            <tbody>
                                <c:forEach items="${q_grd_iss_zerado_detalhe.rows}" var="row">
                                    <tr class="row-danger clickable-row" ondblclick="abrirNotaCentral('${row.NUNOTA}')" title="Duplo clique para abrir a nota na Central">
                                        <td class="align-center"><span class="nota-link">${row.NUNOTA}</span></td>
                                        <td class="align-center">${row.DTNEG_FMT}</td>
                                        <td><c:out value="${row.NOMEPARC}"/></td>
                                        <td><c:out value="${row.DESCRPROD}"/></td>
                                        <td class="align-center">${row.CODTIPOPER}</td>
                                        <td class="align-right">R$ ${row.VALOR_BRUTO_FMT}</td>
                                        <td class="align-center">${row.ISS_RETIDO_CAB}</td>
                                        <td class="align-right">R$ ${row.VLR_ISS_FMT}</td>
                                        <td class="align-right">R$ ${row.VLR_PIS_FMT}</td>
                                        <td class="align-right">R$ ${row.VLR_COFINS_FMT}</td>
                                        <td class="align-right">R$ ${row.VLR_CSLL_FMT}</td>
                                        <td class="align-right">R$ ${row.VLR_IR_FMT}</td>
                                        <td class="align-right">R$ ${row.VLR_INSS_FMT}</td>
                                        <td class="align-right">R$ ${row.VALOR_LIQUIDO_FMT}</td>
                                    </tr>
                                </c:forEach>
                            </tbody>
                        </table>
                    </div>
                </article>
            </section>

            <article class="card span-6">
                <div class="card-head">
                    <h2 class="card-title"><i class="fa-solid fa-chart-column"></i> Composição Tributária</h2>
                </div>
                <div id="chartMapaTributario" class="chart-box"></div>
            </article>

            <article class="card span-6" id="blocoIssZerado">
                <div class="card-head">
                    <h2 class="card-title danger"><i class="fa-solid fa-triangle-exclamation"></i> Evolução de ISS Zerado</h2>
                </div>
                <div id="chartIssZerado" class="chart-box"></div>
            </article>

            <article class="card span-12">
                <div class="card-head">
                    <h2 class="card-title danger"><i class="fa-solid fa-file-circle-exclamation"></i> Top 10 Notas com ISS Zerado</h2>
                </div>
                <div class="table-wrapper">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Nota</th>
                                <th>Cliente</th>
                                <th class="align-right">Valor da Nota</th>
                            </tr>
                        </thead>
                        <tbody>
                            <c:forEach items="${q_grd_iss_zerado.rows}" var="row">
                                <tr class="row-danger clickable-row" ondblclick="abrirNotaCentral('${row.NUNOTA}')" title="Duplo clique para abrir a nota na Central">
                                    <td><span class="nota-link">${row.NUNOTA}</span></td>
                                    <td><c:out value="${row.NOMEPARC}"/></td>
                                    <td class="align-right">R$ ${row.VALOR_NOTA_FMT}</td>
                                </tr>
                            </c:forEach>
                        </tbody>
                    </table>
                </div>
            </article>

            <article class="card span-12" id="tabelaMapa">
                <div class="card-head">
                    <h2 class="card-title"><i class="fa-solid fa-table-list"></i> Detalhamento do Mapa Tributário</h2>
                    <button onclick="baixarMapaTributario()" style="background:#21a366; color:white; border:none; padding:10px 16px; border-radius:8px; cursor:pointer; font-weight:600;">Baixar planilha completa</button>
                </div>
                <div class="table-wrapper">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th class="align-center">NUNOTA</th>
                                <th class="align-center">Dt. Negociação</th>
                                <th class="align-center">Empresa</th>
                                <th>Descrição</th>
                                <th class="align-right">Valor Bruto</th>
                                <th class="align-right">ISS</th>
                                <th class="align-center">ISS Retido</th>
                                <th class="align-right">PIS</th>
                                <th class="align-right">COFINS</th>
                                <th class="align-right">CSLL</th>
                                <th class="align-right">IR</th>
                                <th class="align-right">INSS</th>
                                <th class="align-right">Valor Líquido</th>
                                <th>Incidência ISS</th>
                            </tr>
                        </thead>
                        <tbody>
                            <c:forEach items="${q_grd_mapa_servicos.rows}" var="row">
                                <tr>
                                    <td class="align-center">${row.NUNOTA}</td>
                                    <td class="align-center">${row.DTNEG_FMT}</td>
                                    <td class="align-center">${row.CODEMP}</td>
                                    <td><c:out value="${row.DESCRPROD}"/></td>
                                    <td class="align-right">R$ ${row.VALOR_BRUTO_FMT}</td>
                                    <td class="align-right">R$ ${row.VLR_ISS_FMT}</td>
                                    <td class="align-center">${row.ISS_RETIDO_CAB}</td>
                                    <td class="align-right">R$ ${row.VLR_PIS_FMT}</td>
                                    <td class="align-right">R$ ${row.VLR_COFINS_FMT}</td>
                                    <td class="align-right">R$ ${row.VLR_CSLL_FMT}</td>
                                    <td class="align-right">R$ ${row.VLR_IR_FMT}</td>
                                    <td class="align-right">R$ ${row.VLR_INSS_FMT}</td>
                                    <td class="align-right">R$ ${row.VALOR_LIQUIDO_FMT}</td>
                                    <td>${row.INC_ISS}</td>
                                </tr>
                            </c:forEach>
                        </tbody>
                    </table>
                </div>
            </article>
        </section>
    </main>
</div>

<script>
    function voltarMenuInicial() {
        openLevel('lvl_serv_capa', {});
    }
function baixarMapaTributario() {
    var urlAtual = window.location.href;
    var baseUrl = urlAtual.split('?')[0];

    var query = window.location.search.substring(1);
    var partes = query ? query.split('&') : [];
    var novaQuery = [];

    for (var i = 0; i < partes.length; i++) {
        if (partes[i].indexOf('entryPoint=') !== 0 && partes[i] !== '') {
            novaQuery.push(partes[i]);
        }
    }

    novaQuery.push('entryPoint=export_mapa_tributario.jsp');

    window.open(baseUrl + '?' + novaQuery.join('&'), '_blank');
}

function abrirNotaCentral(nunota) {
    var resourceId = 'br.com.sankhya.com.mov.CentralNotas';
    var params = { NUNOTA: String(nunota) };

    function tentar(fn) {
        try {
            fn();
            return true;
        } catch (e) {
            return false;
        }
    }

    var alvos = [
        contextPage,
        window.parent,
        window.parent && window.parent.JX,
        window.parent && window.parent.sankhya,
        typeof JX !== 'undefined' ? JX : null
    ];

    for (var i = 0; i < alvos.length; i++) {
        var alvo = alvos[i];
        if (!alvo) continue;

        if (typeof alvo.openApp === 'function' && tentar(function() { alvo.openApp(resourceId, params); })) return;
        if (typeof alvo.openApp === 'function' && tentar(function() { alvo.openApp(resourceId, [{ name: 'NUNOTA', value: String(nunota) }]); })) return;
        if (typeof alvo.openResource === 'function' && tentar(function() { alvo.openResource(resourceId, params); })) return;
        if (typeof alvo.launcher === 'function' && tentar(function() { alvo.launcher(resourceId, params); })) return;
        if (typeof alvo.openPage === 'function' && tentar(function() { alvo.openPage(resourceId, params); })) return;
    }

    if (window.parent && window.parent.postMessage) {
        window.parent.postMessage({
            type: 'openApp',
            resourceId: resourceId,
            params: params
        }, '*');
        return;
    }

    alert('Não foi possível abrir a nota ' + nunota + ' na Central de Notas.');
}

function abrirCadastroServico(codprod) {
    if (!resourceCadastroServico) {
        alert('Não foi possível localizar automaticamente o resourceID da tela Serviço/Produto em TSIACM.');
        return;
    }

    var params = { CODPROD: String(codprod) };

    function tentar(fn) {
        try {
            fn();
            return true;
        } catch (e) {
            return false;
        }
    }

    var alvos = [
        contextPage,
        window.parent,
        window.parent && window.parent.JX,
        window.parent && window.parent.sankhya,
        typeof JX !== 'undefined' ? JX : null
    ];

    for (var i = 0; i < alvos.length; i++) {
        var alvo = alvos[i];
        if (!alvo) continue;

        if (typeof alvo.openApp === 'function' && tentar(function() { alvo.openApp(resourceCadastroServico, params); })) return;
        if (typeof alvo.openApp === 'function' && tentar(function() { alvo.openApp(resourceCadastroServico, [{ name: 'CODPROD', value: String(codprod) }]); })) return;
        if (typeof alvo.openResource === 'function' && tentar(function() { alvo.openResource(resourceCadastroServico, params); })) return;
        if (typeof alvo.launcher === 'function' && tentar(function() { alvo.launcher(resourceCadastroServico, params); })) return;
        if (typeof alvo.openPage === 'function' && tentar(function() { alvo.openPage(resourceCadastroServico, params); })) return;
    }

    if (window.parent && window.parent.postMessage) {
        window.parent.postMessage({
            type: 'openApp',
            resourceId: resourceCadastroServico,
            params: params
        }, '*');
        return;
    }

    alert('Não foi possível abrir o cadastro do serviço ' + codprod + '.');
}

var issDetalheRenderizado = false;
var servicosSemMovRenderizado = false;
var issMunicipioRenderizado = false;
function toggleIssDetalhe() {
    var detalhe = document.getElementById('issDetalheInline');
    var botao = document.getElementById('btnIssDetalhe');
    if (!detalhe || !botao) return;

    var vaiAbrir = !detalhe.classList.contains('is-open');
    detalhe.classList.toggle('is-open', vaiAbrir);
    botao.innerText = vaiAbrir ? 'Ocultar detalhe' : 'Ver detalhe completo';

    if (vaiAbrir) {
        if (typeof window.renderIssDetalheCharts === 'function') {
            window.renderIssDetalheCharts();
        }
        detalhe.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
}

function toggleServicosSemMov() {
    var detalhe = document.getElementById('servicosSemMovInline');
    var botao = document.getElementById('btnMenuServicosSemMov');
    if (!detalhe || !botao) return;

    var vaiAbrir = !detalhe.classList.contains('is-open');
    detalhe.classList.toggle('is-open', vaiAbrir);
    botao.classList.toggle('active', vaiAbrir);

    if (vaiAbrir) {
        if (typeof window.renderServicosSemMovChart === 'function') {
            window.renderServicosSemMovChart();
        }
        detalhe.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
}

function abrirIssMunicipio() {
    try {
        if (window.parent) {
            window.parent.__abrirIssMunicipio = true;
        }
    } catch (e) {}
    openLevel('lvl_fat_cidade', { ABRIR_ISS_MUNICIPIO: 'S' });
}

function toggleIssMunicipio() {
    var detalhe = document.getElementById('issMunicipioInline');
    var botao = document.getElementById('btnMenuIssMunicipio');
    if (!detalhe || !botao) return;

    var vaiAbrir = !detalhe.classList.contains('is-open');
    detalhe.classList.toggle('is-open', vaiAbrir);
    botao.classList.toggle('active', vaiAbrir);

    if (vaiAbrir) {
        if (typeof window.renderIssMunicipioChart === 'function') {
            window.renderIssMunicipioChart();
        }
        detalhe.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
}

document.addEventListener('DOMContentLoaded', function() {
    function brToNumber(v) {
        if (v === null || v === undefined || v === '') return 0;
        return parseFloat(String(v).replace(',', '.')) || 0;
    }

    function formatBRL(v) {
        return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(v || 0);
    }

    if (typeof Highcharts === 'undefined') {
        document.getElementById('chartMapaTributario').innerHTML = '<div style="padding:20px;color:#b91c1c;font-weight:700;">Highcharts não carregou.</div>';
        document.getElementById('chartIssZerado').innerHTML = '<div style="padding:20px;color:#b91c1c;font-weight:700;">Highcharts não carregou.</div>';
        document.getElementById('chartIssDetalheEvolucao').innerHTML = '<div style="padding:20px;color:#b91c1c;font-weight:700;">Highcharts não carregou.</div>';
        document.getElementById('chartIssClientes').innerHTML = '<div style="padding:20px;color:#b91c1c;font-weight:700;">Highcharts não carregou.</div>';
        document.getElementById('chartServicosMaisUtilizados').innerHTML = '<div style="padding:20px;color:#b91c1c;font-weight:700;">Highcharts não carregou.</div>';
        document.getElementById('chartServicosSemMov').innerHTML = '<div style="padding:20px;color:#b91c1c;font-weight:700;">Highcharts não carregou.</div>';
        document.getElementById('chartIssMunicipio').innerHTML = '<div style="padding:20px;color:#b91c1c;font-weight:700;">Highcharts não carregou.</div>';
        return;
    }

    var impostos = [0,0,0,0,0,0];
    <c:forEach items="${q_mapa_resumo.rows}" var="mapa">
        impostos = [
            brToNumber('${mapa.VLR_ISS_JS}'),
            brToNumber('${mapa.VLR_PIS_JS}'),
            brToNumber('${mapa.VLR_COFINS_JS}'),
            brToNumber('${mapa.VLR_CSLL_JS}'),
            brToNumber('${mapa.VLR_IR_JS}'),
            brToNumber('${mapa.VLR_INSS_JS}')
        ];
    </c:forEach>

    var issCats = [];
    var issData = [];
    document.querySelectorAll('#dados-iss-evolucao .iss-evolucao-row').forEach(function (el) {
        issCats.push(el.getAttribute('data-mes') || '');
        issData.push(brToNumber(el.getAttribute('data-qtd')));
    });

    var clienteCats = [];
    var clienteData = [];
    document.querySelectorAll('#dados-clientes-iss .cliente-iss-row').forEach(function (el) {
        clienteCats.push((el.textContent || '').trim());
        clienteData.push(brToNumber(el.getAttribute('data-total')));
    });

    var servicoCats = [];
    var servicoData = [];
    document.querySelectorAll('#dados-servicos-sem-mov .servico-sem-mov-row').forEach(function (el) {
        servicoCats.push((el.textContent || '').trim());
        servicoData.push(brToNumber(el.getAttribute('data-dias')));
    });

    var servicosUtilizadosData = [];
    document.querySelectorAll('#dados-servicos-utilizados .servico-utilizado-row').forEach(function (el) {
        servicosUtilizadosData.push({
            name: (el.textContent || '').trim(),
            y: brToNumber(el.getAttribute('data-qtd')),
            valor: brToNumber(el.getAttribute('data-valor'))
        });
    });

    var issMunicipioCats = [];
    var issMunicipioData = [];
    document.querySelectorAll('#dados-iss-municipio .iss-municipio-row').forEach(function (el) {
        issMunicipioCats.push((el.textContent || '').trim());
        issMunicipioData.push(brToNumber(el.getAttribute('data-valor')));
    });

    window.renderServicosSemMovChart = function() {
        if (servicosSemMovRenderizado) return;
        servicosSemMovRenderizado = true;

        Highcharts.chart('chartServicosSemMov', {
            chart: { type: 'bar', backgroundColor: 'transparent', animation: false },
            accessibility: { enabled: false },
            title: { text: null },
            credits: { enabled: false },
            xAxis: { categories: servicoCats, labels: { style: { color: '#5e6b7f', fontSize: '11px' } } },
            yAxis: { title: { text: null }, gridLineColor: '#edf1f6' },
            tooltip: { formatter: function() { return '<b>' + Highcharts.numberFormat(this.y, 0, ',', '.') + ' dias</b>'; } },
            plotOptions: {
                bar: {
                    animation: false,
                    borderRadius: 7,
                    dataLabels: {
                        enabled: true,
                        formatter: function() { return Highcharts.numberFormat(this.y, 0, ',', '.') + ' dias'; },
                        style: { color: '#92400e', textOutline: 'none', fontSize: '10px' }
                    }
                }
            },
            series: [{ name: 'Dias parado', data: servicoData, color: '#f59e0b' }]
        });

        Highcharts.chart('chartServicosMaisUtilizados', {
            chart: { type: 'pie', backgroundColor: 'transparent', animation: false },
            accessibility: { enabled: false },
            title: { text: null },
            credits: { enabled: false },
            tooltip: {
                pointFormatter: function() {
                    return '<b>' + Highcharts.numberFormat(this.y, 0, ',', '.') + '</b> uso(s)<br>' +
                           'Valor: <b>' + formatBRL(this.valor) + '</b><br>' +
                           Highcharts.numberFormat(this.percentage, 1, ',', '.') + '%';
                }
            },
            plotOptions: {
                pie: {
                    innerSize: '58%',
                    animation: false,
                    borderWidth: 0,
                    dataLabels: {
                        enabled: true,
                        distance: 18,
                        formatter: function() {
                            return this.percentage >= 4 ? this.point.name : null;
                        },
                        style: { color: '#5e6b7f', textOutline: 'none', fontSize: '10px' }
                    }
                }
            },
            series: [{
                name: 'Serviços',
                data: servicosUtilizadosData,
                colors: ['#21a366', '#2563eb', '#f59e0b', '#7c3aed', '#ef4444', '#0ea5e9', '#14b8a6', '#84cc16', '#f97316', '#64748b']
            }]
        });
    };

    window.renderIssMunicipioChart = function() {
        if (issMunicipioRenderizado) return;
        issMunicipioRenderizado = true;

        Highcharts.chart('chartIssMunicipio', {
            chart: { type: 'column', backgroundColor: 'transparent', animation: false },
            accessibility: { enabled: false },
            title: { text: null },
            credits: { enabled: false },
            xAxis: { categories: issMunicipioCats, labels: { rotation: -35, style: { color: '#5e6b7f', fontSize: '11px' } } },
            yAxis: { title: { text: null }, gridLineColor: '#edf1f6' },
            tooltip: { formatter: function() { return '<b>' + formatBRL(this.y) + '</b>'; } },
            plotOptions: {
                column: {
                    animation: false,
                    borderRadius: 7,
                    dataLabels: {
                        enabled: true,
                        formatter: function() { return formatBRL(this.y); },
                        style: { color: '#92400e', textOutline: 'none', fontSize: '10px' }
                    }
                }
            },
            series: [{ name: 'ISS Retido', data: issMunicipioData, color: '#f59e0b' }]
        });
    };

    window.renderIssDetalheCharts = function() {
        if (issDetalheRenderizado) return;
        issDetalheRenderizado = true;

        Highcharts.chart('chartIssDetalheEvolucao', {
            chart: { type: 'column', backgroundColor: 'transparent', animation: false },
            accessibility: { enabled: false },
            title: { text: null },
            credits: { enabled: false },
            xAxis: { categories: issCats },
            yAxis: { title: { text: null }, gridLineColor: '#edf1f6' },
            tooltip: { shared: true },
            plotOptions: {
                series: {
                    animation: false,
                    dataLabels: { enabled: true, style: { color: '#991b1b', textOutline: 'none' } }
                }
            },
            series: [{ name: 'Notas com ISS zerado', type: 'column', data: issData, color: '#ef4444' }]
        });

        Highcharts.chart('chartIssClientes', {
            chart: { type: 'bar', backgroundColor: 'transparent', animation: false },
            accessibility: { enabled: false },
            title: { text: null },
            credits: { enabled: false },
            xAxis: { categories: clienteCats, labels: { style: { color: '#5e6b7f', fontSize: '11px' } } },
            yAxis: { title: { text: null }, gridLineColor: '#edf1f6' },
            tooltip: { formatter: function() { return '<b>' + formatBRL(this.y) + '</b>'; } },
            plotOptions: {
                bar: {
                    animation: false,
                    borderRadius: 7,
                    dataLabels: {
                        enabled: true,
                        formatter: function() { return formatBRL(this.y); },
                        style: { color: '#991b1b', textOutline: 'none', fontSize: '10px' }
                    }
                }
            },
            series: [{ name: 'Total', data: clienteData, color: '#ef4444' }]
        });
    };

    requestAnimationFrame(function() {
    Highcharts.chart('chartMapaTributario', {
        chart: { type: 'column', backgroundColor: 'transparent', animation: false },
        accessibility: { enabled: false },
        title: { text: null },
        credits: { enabled: false },
        xAxis: { categories: ['ISS', 'PIS', 'COFINS', 'CSLL', 'IR', 'INSS'] },
        yAxis: { title: { text: null }, gridLineColor: '#edf1f6' },
        tooltip: { formatter: function() { return '<b>' + formatBRL(this.y) + '</b>'; } },
        plotOptions: {
            column: {
                animation: false,
                borderRadius: 7,
                dataLabels: {
                    enabled: true,
                    formatter: function() { return formatBRL(this.y); },
                    style: { color: '#5e6b7f', textOutline: 'none', fontSize: '10px' }
                }
            }
        },
        series: [{ name: 'Valor', data: impostos, color: '#21a366' }]
    });

    Highcharts.chart('chartIssZerado', {
        chart: { type: 'column', backgroundColor: 'transparent', animation: false },
        accessibility: { enabled: false },
        title: { text: null },
        credits: { enabled: false },
        xAxis: { categories: issCats },
        yAxis: { title: { text: null }, gridLineColor: '#edf1f6' },
        tooltip: { shared: true },
        plotOptions: {
            series: {
                animation: false,
                dataLabels: { enabled: true, style: { color: '#991b1b', textOutline: 'none' } }
            }
        },
        series: [{ name: 'Notas com ISS zerado', type: 'column', data: issData, color: '#ef4444' }]
    });

    var abrirServicosViaMenu = false;
    try {
        abrirServicosViaMenu = !!(window.parent && window.parent.__abrirServicosSemMov);
        if (abrirServicosViaMenu) {
            window.parent.__abrirServicosSemMov = false;
        }
    } catch (e) {}

    if (abrirServicosInicial === 'S' || abrirServicosViaMenu) {
        setTimeout(function() {
            toggleServicosSemMov();
        }, 120);
    }
    });
});
</script>

</body>
</html>
