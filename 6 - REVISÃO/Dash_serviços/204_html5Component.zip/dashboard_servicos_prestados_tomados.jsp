<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false"%>
<%@ taglib uri="http://java.sun.com/jstl/core_rt" prefix="c" %>
<%@ taglib prefix="snk" uri="/WEB-INF/tld/sankhyaUtil.tld" %>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Serviços Prestados e Tomados</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" rel="stylesheet">
    <snk:load/>
    <style>
        :root {
            --bg: #f4f7fb;
            --surface: #ffffff;
            --surface-2: #f8fbff;
            --line: #dbe3ee;
            --text: #263445;
            --muted: #7b8796;
            --green: #23b26d;
            --green-2: #168c53;
            --blue: #2563eb;
            --orange: #f59e0b;
            --danger: #ef4444;
            --shadow: 0 14px 30px rgba(28, 39, 57, .08);
        }

        * { box-sizing: border-box; }

        body {
            margin: 0;
            padding: 18px;
            color: var(--text);
            font-family: "Segoe UI", Arial, sans-serif;
            background: var(--bg);
        }

        .page {
            display: grid;
            grid-template-columns: minmax(320px, .9fr) minmax(0, 1.55fr);
            gap: 18px;
            min-height: calc(100vh - 36px);
        }

        .panel {
            min-width: 0;
            background: var(--surface);
            border: 1px solid var(--line);
            border-radius: 16px;
            box-shadow: var(--shadow);
            overflow: hidden;
        }

        .panel-head {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            padding: 16px 18px;
            border-bottom: 1px solid var(--line);
            background: linear-gradient(180deg, #ffffff, #f7fafc);
        }

        .title {
            display: flex;
            align-items: center;
            gap: 10px;
            min-width: 0;
        }

        .title i {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 36px;
            height: 36px;
            border-radius: 11px;
            color: var(--green);
            background: rgba(35, 178, 109, .12);
        }

        h1,
        h2 {
            margin: 0;
            color: var(--text);
            font-size: 18px;
            line-height: 1.2;
        }

        .subtitle {
            margin-top: 4px;
            color: var(--muted);
            font-size: 12px;
        }

        .badge {
            display: inline-flex;
            align-items: center;
            min-height: 26px;
            padding: 0 10px;
            border-radius: 999px;
            color: var(--green-2);
            background: rgba(35, 178, 109, .1);
            border: 1px solid rgba(35, 178, 109, .24);
            font-size: 12px;
            font-weight: 700;
            white-space: nowrap;
        }

        .kpis {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 12px;
            padding: 14px;
            border-bottom: 1px solid var(--line);
            background: var(--surface-2);
        }

        .kpi {
            padding: 14px;
            border: 1px solid var(--line);
            border-radius: 14px;
            background: #fff;
        }

        .kpi span {
            display: block;
            color: var(--muted);
            font-size: 11px;
            font-weight: 800;
            letter-spacing: .08em;
            text-transform: uppercase;
        }

        .kpi strong {
            display: block;
            margin-top: 6px;
            font-size: 24px;
            line-height: 1;
        }

        .table-wrap {
            max-height: calc(100vh - 188px);
            overflow: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            position: sticky;
            top: 0;
            z-index: 1;
            padding: 11px 12px;
            color: var(--muted);
            background: #f2f6fb;
            border-bottom: 1px solid var(--line);
            font-size: 11px;
            text-align: left;
            text-transform: uppercase;
            white-space: nowrap;
        }

        td {
            padding: 11px 12px;
            border-bottom: 1px solid #edf2f7;
            font-size: 13px;
            vertical-align: top;
        }

        tr:hover td {
            background: #f8fbff;
        }

        .align-right { text-align: right; }
        .service-name { font-weight: 800; color: var(--text); }
        .service-origin { color: var(--muted); font-size: 12px; margin-top: 3px; }

        .open-btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            min-height: 30px;
            padding: 0 10px;
            border: 0;
            border-radius: 9px;
            color: #fff;
            background: var(--green);
            cursor: pointer;
            font-weight: 800;
            white-space: nowrap;
        }

        .details {
            display: grid;
            grid-template-rows: auto 1fr 1fr;
            gap: 18px;
        }

        .hint {
            margin: 0;
            padding: 14px 18px;
            color: var(--muted);
            background: #f8fbff;
            border-bottom: 1px solid var(--line);
            font-size: 13px;
            line-height: 1.45;
        }

        .split {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 18px;
        }

        .status {
            display: inline-flex;
            align-items: center;
            min-height: 24px;
            padding: 0 8px;
            border-radius: 999px;
            font-size: 11px;
            font-weight: 800;
            color: var(--green-2);
            background: rgba(35, 178, 109, .1);
        }

        .status.compra {
            color: #9a6700;
            background: rgba(245, 158, 11, .14);
        }

        @media (max-width: 1200px) {
            .page,
            .split {
                grid-template-columns: 1fr;
            }

            .table-wrap {
                max-height: 520px;
            }
        }

        .mini-menu {
            position: sticky;
            top: 0;
            z-index: 20;
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 10px 12px;
            margin: -18px -18px 18px;
            background: rgba(255, 255, 255, .96);
            border-bottom: 1px solid var(--line);
            box-shadow: 0 8px 18px rgba(28, 39, 57, .06);
            overflow-x: auto;
        }
        .mini-menu .brand-mini { display: inline-flex; align-items: center; gap: 8px; margin-right: 8px; color: var(--text); font-weight: 900; white-space: nowrap; }
        .mini-menu button { display: inline-flex; align-items: center; gap: 7px; min-height: 34px; padding: 0 10px; border: 0; border-radius: 10px; color: #5f6f84; background: transparent; cursor: pointer; font-weight: 800; white-space: nowrap; }
        .mini-menu button:hover, .mini-menu button.active { color: var(--green-2); background: rgba(35, 178, 109, .12); }
        tr.service-row { cursor: pointer; }
        tr.service-row.selected td { background: rgba(35, 178, 109, .12); }
        .empty-state { padding: 22px; color: var(--muted); font-weight: 700; }
        .detail-stack { display: grid; gap: 18px; }
        .detail-panel .table-wrap { max-height: 310px; }
        .detail-row.is-hidden { display: none; }

    </style>
</head>
<body>
    <nav class="mini-menu" aria-label="Menu principal">
        <div class="brand-mini"><i class="fa-solid fa-bars"></i> Menu Inicial</div>
        <button type="button" onclick="abrirNivel('lvl_serv_capa')"><i class="fa-solid fa-house"></i> Início</button>
        <button type="button" onclick="abrirNivel('lvl_tomadores')"><i class="fa-solid fa-briefcase"></i> Análise Tomadores</button>
        <button type="button" onclick="abrirNivel('lvl_fat_cidade')"><i class="fa-solid fa-city"></i> Movimento por Município</button>
        <button type="button" onclick="abrirIssMunicipio()"><i class="fa-solid fa-map-location-dot"></i> ISS por Município</button>
        <button type="button" onclick="abrirNivel('lvl_mapa_tributario')"><i class="fa-solid fa-layer-group"></i> Auditoria de Impostos</button>
        <button type="button" onclick="abrirServicosSemMovimento()"><i class="fa-solid fa-screwdriver-wrench"></i> Serviços</button>
        <button class="active" type="button" onclick="abrirNivel('lvl_servicos_prestados_tomados')"><i class="fa-solid fa-clipboard-list"></i> Prestados / Tomados</button>
    </nav>

<snk:query var="q_servicos_kpi">
        SELECT
            COUNT(DISTINCT PRO.CODPROD) AS QTD_SERVICOS,
            COUNT(DISTINCT CASE WHEN CAB.TIPMOV = 'V' THEN CAB.NUNOTA END) AS QTD_PRESTADOS,
            COUNT(DISTINCT CASE WHEN CAB.TIPMOV = 'C' THEN CAB.NUNOTA END) AS QTD_TOMADOS
        FROM TGFPRO PRO
        LEFT JOIN TGFITE ITE ON ITE.CODPROD = PRO.CODPROD
        LEFT JOIN TGFCAB CAB ON CAB.NUNOTA = ITE.NUNOTA AND CAB.STATUSNOTA = 'L'
        WHERE PRO.USOPROD = 'S'
    </snk:query>

    <snk:query var="q_servicos">
        SELECT
            PRO.CODPROD,
            PRO.DESCRPROD,
            PRO.AD_ORIGDEPLOY,
            COUNT(ITE.NUNOTA) AS QTD_MOV
        FROM TGFPRO PRO
        LEFT JOIN TGFITE ITE ON ITE.CODPROD = PRO.CODPROD
        WHERE PRO.USOPROD = 'S'
        GROUP BY PRO.CODPROD, PRO.DESCRPROD, PRO.AD_ORIGDEPLOY
        ORDER BY QTD_MOV DESC, PRO.DESCRPROD
    </snk:query>

    <snk:query var="q_produto_base">
        SELECT CODPROD
        FROM (
            SELECT
                PRO.CODPROD,
                COUNT(ITE.NUNOTA) AS QTD_MOV
            FROM TGFPRO PRO
            LEFT JOIN TGFITE ITE ON ITE.CODPROD = PRO.CODPROD
            WHERE PRO.USOPROD = 'S'
            GROUP BY PRO.CODPROD
            ORDER BY COUNT(ITE.NUNOTA) DESC, PRO.CODPROD
        )
        WHERE ROWNUM = 1
    </snk:query>

    <snk:query var="q_prestados_inline">
        SELECT
            CAB.NUNOTA,
            CAB.NUMNFSE,
            CAB.DTNEG,
            CAB.CODEMP,
            CAB.CODPARC,
            ITE.CODPROD,
            ITE.ALIQISS,
            NVL(ROUND((CAB.VLRISS / NULLIF(CAB.BASEISS, 0)) * 100, 2), 0) AS PERC_ISS,
            CAB.VLRISS,
            CAB.BASEISS,
            CAB.ISSRETIDO,
            NVL(CID.NOMECID, 'Sem cidade') AS NOMECID
        FROM TGFCAB CAB
        INNER JOIN TGFITE ITE ON CAB.NUNOTA = ITE.NUNOTA
        INNER JOIN TGFPRO PRO ON ITE.CODPROD = PRO.CODPROD
        LEFT JOIN TSICID CID ON CAB.CODCIDPREST = CID.CODCID
        WHERE PRO.USOPROD = 'S'
          AND CAB.STATUSNOTA = 'L'
          AND CAB.TIPMOV = 'V'
        ORDER BY ITE.CODPROD, CAB.DTNEG DESC, CAB.NUNOTA DESC
    </snk:query>

    <snk:query var="q_tomados_inline">
        SELECT
            CAB.NUNOTA,
            CAB.NUMNFSE,
            CAB.DTNEG,
            CAB.CODEMP,
            CAB.CODPARC,
            ITE.CODPROD,
            ITE.ALIQISS,
            NVL(ROUND((CAB.VLRISS / NULLIF(CAB.BASEISS, 0)) * 100, 2), 0) AS PERC_ISS,
            CAB.VLRISS,
            CAB.BASEISS,
            CAB.ISSRETIDO,
            NVL(CID.NOMECID, 'Sem cidade') AS NOMECID
        FROM TGFCAB CAB
        INNER JOIN TGFITE ITE ON CAB.NUNOTA = ITE.NUNOTA
        INNER JOIN TGFPRO PRO ON ITE.CODPROD = PRO.CODPROD
        LEFT JOIN TSICID CID ON CAB.CODCIDPREST = CID.CODCID
        WHERE PRO.USOPROD = 'S'
          AND CAB.STATUSNOTA = 'L'
          AND CAB.TIPMOV = 'C'
        ORDER BY ITE.CODPROD, CAB.DTNEG DESC, CAB.NUNOTA DESC
    </snk:query>

    <div class="page">
        <section class="panel">
            <div class="panel-head">
                <div class="title">
                    <i class="fa-solid fa-screwdriver-wrench"></i>
                    <div>
                        <h1>Catálogo de Serviços</h1>
                        <div class="subtitle">Selecione um serviço para conferir notas prestadas e tomadas.</div>
                    </div>
                </div>
                <c:forEach items="${q_produto_base.rows}" var="base">
                    <span class="badge">Serviço base: ${base.CODPROD}</span>
                </c:forEach>
            </div>

            <div class="kpis">
                <c:forEach items="${q_servicos_kpi.rows}" var="kpi">
                    <div class="kpi"><span>Serviços</span><strong>${kpi.QTD_SERVICOS}</strong></div>
                    <div class="kpi"><span>Prestados</span><strong>${kpi.QTD_PRESTADOS}</strong></div>
                    <div class="kpi"><span>Tomados</span><strong>${kpi.QTD_TOMADOS}</strong></div>
                </c:forEach>
            </div>

            <div class="table-wrap">
                <table>
                    <thead>
                        <tr>
                            <th>Serviço</th>
                            <th>Origem</th>
                            <th class="align-right">Mov.</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <c:forEach items="${q_servicos.rows}" var="row">
                            <tr class="service-row" data-codprod="${row.CODPROD}" onclick="selecionarServico('${row.CODPROD}', this)">
                                <td>
                                    <div class="service-name">${row.CODPROD} - ${row.DESCRPROD}</div>
                                </td>
                                <td><div class="service-origin">${row.AD_ORIGDEPLOY}</div></td>
                                <td class="align-right">${row.QTD_MOV}</td>
                                <td class="align-right">
                                    <button class="open-btn" type="button" onclick="event.stopPropagation(); selecionarServico('${row.CODPROD}', this.closest('tr'))">
                                        <i class="fa-solid fa-arrow-right"></i> Abrir
                                    </button>
                                </td>
                            </tr>
                        </c:forEach>
                    </tbody>
                </table>
            </div>
        </section>

                <section class="details detail-stack">
            <section class="panel">
                <div class="panel-head">
                    <div class="title">
                        <i class="fa-solid fa-circle-info"></i>
                        <div>
                            <h2>Prestados / Tomados</h2>
                            <div class="subtitle" id="servicoSelecionado">Clique em um serviço da lista para ver as notas na mesma tela.</div>
                        </div>
                    </div>
                    <span class="badge" id="badgeServico">Selecione</span>
                </div>
                <p class="hint">O detalhe é carregado nesta área, sem abrir outro nível do Sankhya.</p>
            </section>

            <section class="panel detail-panel">
                <div class="panel-head">
                    <div class="title">
                        <i class="fa-solid fa-share-from-square"></i>
                        <div>
                            <h2>Serviços Prestados</h2>
                            <div class="subtitle">Notas de venda de serviço.</div>
                        </div>
                    </div>
                    <span class="status" id="countPrestados">0 notas</span>
                </div>
                <div class="table-wrap">
                    <table>
                        <thead>
                            <tr>
                                <th>Nota</th><th>NFSe</th><th>Data</th><th>Empresa</th><th>Parceiro</th>
                                <th class="align-right">Aliq. ISS</th><th class="align-right">ISS Calc.</th>
                                <th class="align-right">Vlr ISS</th><th class="align-right">Base ISS</th><th>Cidade</th>
                            </tr>
                        </thead>
                        <tbody id="tbodyPrestados">
                            <c:forEach items="${q_prestados_inline.rows}" var="row">
                                <tr class="detail-row is-hidden" data-kind="prestado" data-codprod="${row.CODPROD}">
                                    <td>${row.NUNOTA}</td><td>${row.NUMNFSE}</td><td>${row.DTNEG}</td><td>${row.CODEMP}</td><td>${row.CODPARC}</td>
                                    <td class="align-right pct">${row.ALIQISS}</td><td class="align-right pct">${row.PERC_ISS}</td>
                                    <td class="align-right money">${row.VLRISS}</td><td class="align-right money">${row.BASEISS}</td><td>${row.NOMECID}</td>
                                </tr>
                            </c:forEach>
                        </tbody>
                    </table>
                    <div class="empty-state" id="emptyPrestados">Selecione um serviço.</div>
                </div>
            </section>

            <section class="panel detail-panel">
                <div class="panel-head">
                    <div class="title">
                        <i class="fa-solid fa-cart-shopping"></i>
                        <div>
                            <h2>Serviços Tomados</h2>
                            <div class="subtitle">Notas de compra de serviço.</div>
                        </div>
                    </div>
                    <span class="status compra" id="countTomados">0 notas</span>
                </div>
                <div class="table-wrap">
                    <table>
                        <thead>
                            <tr>
                                <th>Nota</th><th>NFSe</th><th>Data</th><th>Empresa</th><th>Parceiro</th>
                                <th class="align-right">Aliq. ISS</th><th class="align-right">ISS Calc.</th>
                                <th class="align-right">Vlr ISS</th><th class="align-right">Base ISS</th><th>Cidade</th>
                            </tr>
                        </thead>
                        <tbody id="tbodyTomados">
                            <c:forEach items="${q_tomados_inline.rows}" var="row">
                                <tr class="detail-row is-hidden" data-kind="tomado" data-codprod="${row.CODPROD}">
                                    <td>${row.NUNOTA}</td><td>${row.NUMNFSE}</td><td>${row.DTNEG}</td><td>${row.CODEMP}</td><td>${row.CODPARC}</td>
                                    <td class="align-right pct">${row.ALIQISS}</td><td class="align-right pct">${row.PERC_ISS}</td>
                                    <td class="align-right money">${row.VLRISS}</td><td class="align-right money">${row.BASEISS}</td><td>${row.NOMECID}</td>
                                </tr>
                            </c:forEach>
                        </tbody>
                    </table>
                    <div class="empty-state" id="emptyTomados">Selecione um serviço.</div>
                </div>
            </section>
        </section>
    </div>

    <script>
        function parseNumber(value) {
            value = String(value || '').replace(/R\$/g, '').replace(/%/g, '').replace(/\s/g, '');
            if (value.indexOf(',') >= 0 && value.indexOf('.') >= 0) {
                value = value.replace(/\./g, '').replace(',', '.');
            } else if (value.indexOf(',') >= 0) {
                value = value.replace(',', '.');
            }
            var number = Number(value);
            return isNaN(number) ? 0 : number;
        }

        function formatBRL(value) {
            return parseNumber(value).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL', minimumFractionDigits: 2, maximumFractionDigits: 2 });
        }

        function formatPercent(value) {
            return parseNumber(value).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + '%';
        }

        function abrirServico(codprod) {
            selecionarServico(codprod, document.querySelector('tr.service-row[data-codprod="' + codprod + '"]'));
        }

        function selecionarServico(codprod, rowElement) {
            document.querySelectorAll('tr.service-row').forEach(function (row) { row.classList.remove('selected'); });
            if (rowElement) rowElement.classList.add('selected');

            var selectedName = rowElement ? (rowElement.querySelector('.service-name').textContent || '').trim() : ('Serviço ' + codprod);
            var title = document.getElementById('servicoSelecionado');
            var badge = document.getElementById('badgeServico');
            if (title) title.textContent = selectedName;
            if (badge) badge.textContent = 'Serviço ' + codprod;

            var prestados = 0;
            var tomados = 0;
            document.querySelectorAll('.detail-row').forEach(function (row) {
                var show = row.getAttribute('data-codprod') === String(codprod);
                row.classList.toggle('is-hidden', !show);
                if (show && row.getAttribute('data-kind') === 'prestado') prestados += 1;
                if (show && row.getAttribute('data-kind') === 'tomado') tomados += 1;
            });

            document.getElementById('countPrestados').textContent = prestados + (prestados === 1 ? ' nota' : ' notas');
            document.getElementById('countTomados').textContent = tomados + (tomados === 1 ? ' nota' : ' notas');
            document.getElementById('emptyPrestados').style.display = prestados ? 'none' : 'block';
            document.getElementById('emptyTomados').style.display = tomados ? 'none' : 'block';
        }

        function abrirServicosSemMovimento() {
            if (window.parent) window.parent.__abrirServicosSemMov = true;
            abrirNivel('lvl_mapa_tributario', { ABRIR_SERVICOS: 'S' });
        }
        function abrirIssMunicipio() {
            if (window.parent) window.parent.__abrirIssMunicipio = true;
            abrirNivel('lvl_fat_cidade', { ABRIR_ISS_MUNICIPIO: 'S' });
        }



        function abrirNivel(levelId, params) {
            params = params || {};
            if (typeof openLevel === 'function') {
                openLevel(levelId, params);
                return;
            }
            if (window.parent && typeof window.parent.openLevel === 'function') {
                window.parent.openLevel(levelId, params);
                return;
            }
            if (typeof JX !== 'undefined' && JX.openLevel) {
                JX.openLevel(levelId, params);
            }
        }

        document.addEventListener('DOMContentLoaded', function () {
            document.querySelectorAll('.money').forEach(function (el) { el.textContent = formatBRL(el.textContent); });
            document.querySelectorAll('.pct').forEach(function (el) { el.textContent = formatPercent(el.textContent); });
            var firstRow = document.querySelector('tr.service-row');
            if (firstRow) selecionarServico(firstRow.getAttribute('data-codprod'), firstRow);
        });
    </script>
</body>
</html>
