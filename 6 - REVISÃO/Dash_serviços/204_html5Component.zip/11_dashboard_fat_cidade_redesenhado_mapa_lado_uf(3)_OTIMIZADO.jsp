<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" isELIgnored="false"%>
<%@ taglib uri="http://java.sun.com/jstl/core_rt" prefix="c" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/functions" prefix="fn" %>
<%@ taglib prefix="snk" uri="/WEB-INF/tld/sankhyaUtil.tld" %>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <snk:load/>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://cdnjs.cloudflare.com">
    <link rel="preconnect" href="https://code.highcharts.com">
    <title>Faturamento por Cidade / UF</title>
    <script defer src="https://code.highcharts.com/maps/highmaps.js"></script>
    <script defer src="https://code.highcharts.com/mapdata/countries/br/br-all.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" rel="stylesheet">
</head>

<body>

<script type="text/javascript">
    var gadGetID = '${param.gadGetID}';
    var nuGdg = '${param.nuGdg}';
    var contextPage = window.parent.dashboard[nuGdg];
    var abrirIssMunicipioInicial = '${param.ABRIR_ISS_MUNICIPIO}';

    function openLevel(nivel, params) {
        contextPage.openLevel(nivel, params || {});
    }
</script>

    <style>
        :root {
            --bg-page: #f4f7fb;
            --bg-panel: #ffffff;
            --bg-sidebar: #ffffff;
            --bg-card: #ffffff;
            --text-title: #172033;
            --text-body: #5e6b7f;
            --text-muted: #8a97a8;
            --green: #21a366;
            --green-soft: #e7f6ee;
            --blue: #2563eb;
            --blue-soft: #e8f0ff;
            --purple: #7c3aed;
            --purple-soft: #f1eaff;
            --orange: #f59e0b;
            --orange-soft: #fff4dd;
            --border: #e5eaf1;
            --shadow: 0 12px 30px rgba(15, 23, 42, .08);
            --radius: 18px;
        }
        * { box-sizing: border-box; }
        body {
            margin: 0;
            background: var(--bg-page);
            color: var(--text-title);
            font-family: "Segoe UI", Arial, sans-serif;
            overflow-x: hidden;
        }
        .app {
            display: grid;
            grid-template-columns: 230px minmax(0, 1fr);
            min-height: 100vh;
        }
        .sidebar {
            background: var(--bg-sidebar);
            border-right: 1px solid var(--border);
            padding: 18px 14px;
        }
        .brand {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 8px 10px 20px;
            font-weight: 800;
            color: var(--text-title);
        }
        .brand-icon {
            width: 34px;
            height: 34px;
            border-radius: 11px;
            display: grid;
            place-items: center;
            background: var(--green-soft);
            color: var(--green);
        }
        .nav-title {
            font-size: 11px;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: .12em;
            margin: 16px 12px 8px;
            font-weight: 700;
        }
        .nav-item {
            display: flex;
            align-items: center;
            gap: 11px;
            width: 100%;
            border: 0;
            background: transparent;
            color: var(--text-body);
            padding: 11px 12px;
            border-radius: 12px;
            font-size: 14px;
            text-align: left;
            cursor: pointer;
            transition: .18s ease;
        }
        .nav-item:hover, .nav-item.active {
            background: var(--green-soft);
            color: var(--green);
            font-weight: 700;
        }
        .main {
            padding: 18px 24px 28px;
            min-width: 0;
        }
        .topbar {
            background: var(--bg-panel);
            border: 1px solid var(--border);
            border-radius: 16px;
            min-height: 64px;
            padding: 0 18px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: 0 6px 18px rgba(15, 23, 42, .04);
            margin-bottom: 18px;
        }
        .topbar-left { display: flex; align-items: center; gap: 12px; }
        .title-icon {
            width: 38px;
            height: 38px;
            border-radius: 13px;
            display: grid;
            place-items: center;
            background: var(--green-soft);
            color: var(--green);
        }
        .topbar h1 { margin: 0; font-size: 18px; font-weight: 850; color: var(--text-title); }
        .periodo { color: var(--text-muted); font-size: 12px; margin-top: 3px; }
        .badge {
            font-size: 11px;
            font-weight: 800;
            color: var(--green);
            background: var(--green-soft);
            border: 1px solid #c7ecd8;
            border-radius: 999px;
            padding: 6px 10px;
            white-space: nowrap;
        }
        .dash-grid {
            display: grid;
            grid-template-columns: repeat(12, minmax(0, 1fr));
            gap: 18px;
        }
        .card {
            background: var(--bg-card);
            border: 1px solid var(--border);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            padding: 18px;
            min-width: 0;
        }
        .span-12 { grid-column: span 12; }
        .span-7 { grid-column: span 7; }
        .span-5 { grid-column: span 5; }
        .span-6 { grid-column: span 6; }
        .card-head {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            margin-bottom: 14px;
        }
        .card-title { margin: 0; font-size: 15px; font-weight: 850; color: var(--text-title); }
        .card-title i { color: var(--green); margin-right: 7px; }
        .card-title.warning i { color: var(--orange); }
        .inline-detail {
            display: none;
            grid-column: span 12;
            grid-template-columns: repeat(12, minmax(0, 1fr));
            gap: 18px;
        }
        .inline-detail.is-open { display: grid; }
        .section-action {
            border: 0;
            border-radius: 12px;
            background: var(--orange);
            color: #fff;
            cursor: pointer;
            font-weight: 800;
            padding: 11px 15px;
            white-space: nowrap;
            box-shadow: 0 10px 22px rgba(245, 158, 11, .18);
        }
        .section-action:hover { background: #d97706; }
        .resumo-card {
            display: grid;
            grid-template-columns: 1.35fr repeat(3, minmax(0, 1fr));
            gap: 14px;
            align-items: stretch;
        }
        .resumo-total {
            border: 1px solid var(--border);
            background: linear-gradient(135deg, #ffffff 0%, #f7fbff 100%);
            border-radius: 16px;
            padding: 18px;
            display: flex;
            gap: 14px;
            align-items: center;
        }
        .resumo-icon {
            width: 52px;
            height: 52px;
            min-width: 52px;
            border-radius: 16px;
            display: grid;
            place-items: center;
            background: var(--green-soft);
            color: var(--green);
            font-size: 22px;
        }
        .resumo-label {
            display: block;
            color: var(--text-muted);
            font-size: 11px;
            letter-spacing: .06em;
            text-transform: uppercase;
            font-weight: 800;
            margin-bottom: 6px;
        }
        .resumo-value {
            font-size: 25px;
            font-weight: 900;
            color: var(--text-title);
            line-height: 1.05;
        }
        .resumo-sub {
            margin-top: 5px;
            color: var(--text-body);
            font-size: 12px;
        }
        .metric-box {
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 16px;
            min-width: 0;
        }
        .metric-box.cidades { background: var(--blue-soft); }
        .metric-box.estados { background: var(--purple-soft); }
        .metric-box.topcidade { background: var(--orange-soft); }
        .metric-top { display: flex; align-items: center; justify-content: space-between; gap: 10px; }
        .metric-icon {
            width: 34px;
            height: 34px;
            border-radius: 12px;
            display: grid;
            place-items: center;
            color: #fff;
        }
        .metric-box.cidades .metric-icon { background: var(--blue); }
        .metric-box.estados .metric-icon { background: var(--purple); }
        .metric-box.topcidade .metric-icon { background: var(--orange); }
        .metric-value { font-size: 24px; font-weight: 900; color: var(--text-title); margin-top: 12px; }
        .metric-desc { color: var(--text-body); font-size: 12px; margin-top: 3px; }
        .chart { height: 360px; }
        .table-wrapper {
            max-height: 430px;
            overflow: auto;
            border: 1px solid var(--border);
            border-radius: 14px;
        }
        .data-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 13px;
        }
        .data-table th {
            position: sticky;
            top: 0;
            z-index: 1;
            background: #f8fafc;
            color: var(--text-muted);
            text-align: left;
            padding: 11px 12px;
            border-bottom: 1px solid var(--border);
            font-size: 11px;
            letter-spacing: .05em;
            text-transform: uppercase;
            white-space: nowrap;
        }
        .data-table td {
            padding: 11px 12px;
            border-bottom: 1px solid var(--border);
            color: var(--text-body);
            vertical-align: middle;
        }
        .data-table tr:hover td { background: #fbfdff; }
        .align-right { text-align: right; }
        .align-center { text-align: center; }
        .iss-municipio-table {
            table-layout: fixed;
        }
        .iss-municipio-table .col-cidade { width: 26%; }
        .iss-municipio-table .col-uf { width: 9%; }
        .iss-municipio-table .col-estado { width: 27%; }
        .iss-municipio-table .col-valor { width: 24%; }
        .iss-municipio-table .col-perc { width: 14%; }
        .iss-municipio-table th,
        .iss-municipio-table td {
            vertical-align: middle;
        }
        .iss-municipio-table .money-cell,
        .iss-municipio-table .perc-cell {
            white-space: nowrap;
            font-variant-numeric: tabular-nums;
        }
        .uf-pill {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 34px;
            height: 24px;
            border-radius: 999px;
            font-size: 12px;
            font-weight: 900;
            color: var(--green);
            background: var(--green-soft);
            padding: 0 9px;
        }
        @media (max-width: 1150px) {
            .app { grid-template-columns: 1fr; }
            .sidebar { display: none; }
            .resumo-card { grid-template-columns: 1fr; }
            .span-7, .span-5, .span-6 { grid-column: span 12; }
            .inline-detail { grid-template-columns: 1fr; }
            .main { padding: 12px; }
            .topbar { align-items: flex-start; flex-direction: column; padding: 14px 16px; }
        }
        .mapa-card {
            padding: 18px;
        }

        #mapaBrasil,
        #mapaIssBrasil {
            width: 100%;
            height: 430px;
            border-radius: 18px;
            overflow: hidden;
        }
    
        /* Otimizações de renderização: limita reflows/repaints em blocos independentes */
        .card, .kpi, .resumo-total, .mini-card, .table-wrap, .ranking-list {
            contain: layout paint;
        }
        table { table-layout: fixed; }
</style>
</head>
<body>

<snk:query var="q_resumo_fat_cidade">
WITH BASE AS (
    SELECT
        CID.NOMECID,
        UFS.UF,
        UFS.DESCRICAO AS ESTADO,
        SUM(ITE.VLRTOT) AS VALOR
    FROM TGFCAB CAB
    INNER JOIN TGFPAR PAR ON CAB.CODPARC = PAR.CODPARC
    INNER JOIN TSICID CID ON PAR.CODCID = CID.CODCID
    INNER JOIN TSIUFS UFS ON CID.UF = UFS.CODUF
    INNER JOIN TGFITE ITE ON CAB.NUNOTA = ITE.NUNOTA
    INNER JOIN TGFPRO PRO ON ITE.CODPROD = PRO.CODPROD
    WHERE CAB.STATUSNOTA = 'L'
      AND CAB.TIPMOV = 'V'
      AND PRO.USOPROD = 'S'
      AND (CAB.DTNEG >= :P_DATA_INI OR :P_DATA_INI IS NULL)
      AND (CAB.DTNEG <= :P_DATA_FIM OR :P_DATA_FIM IS NULL)
      AND (:P_EMPRESA IS NULL OR CAB.CODEMP IN (:P_EMPRESA))
      AND (:P_UF IS NULL OR UFS.CODUF IN (:P_UF))
      AND (:P_TOP IS NULL OR CAB.CODTIPOPER IN (:P_TOP))
    GROUP BY CID.NOMECID, UFS.UF, UFS.DESCRICAO
), RANK_CIDADE AS (
    SELECT
        NOMECID,
        UF,
        VALOR,
        ROW_NUMBER() OVER (ORDER BY VALOR DESC, NOMECID) AS RN
    FROM BASE
)
SELECT
    COUNT(*) AS QTD_CIDADES,
    TO_CHAR(COUNT(*), 'FM999G999G999G990', 'NLS_NUMERIC_CHARACTERS = '',.''') AS QTD_CIDADES_FMT,
    COUNT(DISTINCT UF) AS QTD_ESTADOS,
    TO_CHAR(COUNT(DISTINCT UF), 'FM999G999G990', 'NLS_NUMERIC_CHARACTERS = '',.''') AS QTD_ESTADOS_FMT,
    SUM(VALOR) AS FAT_TOTAL,
    TO_CHAR(NVL(SUM(VALOR), 0), 'FM999G999G999G990D00', 'NLS_NUMERIC_CHARACTERS = '',.''') AS FAT_TOTAL_FMT,
    MAX(CASE WHEN RN = 1 THEN NOMECID || ' / ' || UF END) AS TOP_CIDADE,
    MAX(CASE WHEN RN = 1 THEN VALOR END) AS TOP_VALOR,
    TO_CHAR(NVL(MAX(CASE WHEN RN = 1 THEN VALOR END), 0), 'FM999G999G999G990D00', 'NLS_NUMERIC_CHARACTERS = '',.''') AS TOP_VALOR_FMT
FROM RANK_CIDADE
</snk:query>

<snk:query var="q_fat_estado">
SELECT
    UFS.UF AS UF,
    UFS.DESCRICAO AS ESTADO,
    SUM(ITE.VLRTOT) AS VALOR,
    TO_CHAR(SUM(ITE.VLRTOT), 'FM999G999G999G990D00', 'NLS_NUMERIC_CHARACTERS = '',.''') AS VALOR_FMT,
    TO_CHAR(SUM(ITE.VLRTOT), 'FM999999999990D00', 'NLS_NUMERIC_CHARACTERS = ''.,''') AS VALOR_JS
FROM TGFCAB CAB
INNER JOIN TGFPAR PAR ON CAB.CODPARC = PAR.CODPARC
INNER JOIN TSICID CID ON PAR.CODCID = CID.CODCID
INNER JOIN TSIUFS UFS ON CID.UF = UFS.CODUF
INNER JOIN TGFITE ITE ON CAB.NUNOTA = ITE.NUNOTA
INNER JOIN TGFPRO PRO ON ITE.CODPROD = PRO.CODPROD
WHERE CAB.STATUSNOTA = 'L'
  AND CAB.TIPMOV = 'V'
  AND PRO.USOPROD = 'S'
  AND (CAB.DTNEG >= :P_DATA_INI OR :P_DATA_INI IS NULL)
  AND (CAB.DTNEG <= :P_DATA_FIM OR :P_DATA_FIM IS NULL)
  AND (:P_EMPRESA IS NULL OR CAB.CODEMP IN (:P_EMPRESA))
  AND (:P_UF IS NULL OR UFS.CODUF IN (:P_UF))
  AND (:P_TOP IS NULL OR CAB.CODTIPOPER IN (:P_TOP))
GROUP BY UFS.UF, UFS.DESCRICAO
ORDER BY VALOR DESC
</snk:query>

<snk:query var="q_fat_cidade">
SELECT
    CID.NOMECID AS CIDADE,
    UFS.DESCRICAO AS ESTADO,
    UFS.UF AS UF,
    SUM(ITE.VLRTOT) AS VALOR,
    TO_CHAR(SUM(ITE.VLRTOT), 'FM999G999G999G990D00', 'NLS_NUMERIC_CHARACTERS = '',.''') AS VALOR_FMT,
    ROUND((SUM(ITE.VLRTOT) / NULLIF(SUM(SUM(ITE.VLRTOT)) OVER (), 0)) * 100, 2) AS PERC,
    TO_CHAR(ROUND((SUM(ITE.VLRTOT) / NULLIF(SUM(SUM(ITE.VLRTOT)) OVER (), 0)) * 100, 2), 'FM990D00', 'NLS_NUMERIC_CHARACTERS = '',.''') AS PERC_FMT
FROM TGFCAB CAB
INNER JOIN TGFPAR PAR ON CAB.CODPARC = PAR.CODPARC
INNER JOIN TSICID CID ON PAR.CODCID = CID.CODCID
INNER JOIN TSIUFS UFS ON CID.UF = UFS.CODUF
INNER JOIN TGFITE ITE ON CAB.NUNOTA = ITE.NUNOTA
INNER JOIN TGFPRO PRO ON ITE.CODPROD = PRO.CODPROD
WHERE CAB.STATUSNOTA = 'L'
  AND CAB.TIPMOV = 'V'
  AND PRO.USOPROD = 'S'
  AND (CAB.DTNEG >= :P_DATA_INI OR :P_DATA_INI IS NULL)
  AND (CAB.DTNEG <= :P_DATA_FIM OR :P_DATA_FIM IS NULL)
  AND (:P_EMPRESA IS NULL OR CAB.CODEMP IN (:P_EMPRESA))
  AND (:P_UF IS NULL OR UFS.CODUF IN (:P_UF))
  AND (:P_TOP IS NULL OR CAB.CODTIPOPER IN (:P_TOP))
GROUP BY CID.NOMECID, UFS.DESCRICAO, UFS.UF
ORDER BY VALOR DESC
</snk:query>



<snk:query var="q_mapa_cidades">
SELECT
    LOWER(UFS.UF) AS UF,
    UFS.UF AS ESTADO,
    SUM(ITE.VLRTOT) AS TOTAL_VENDAS,
    TO_CHAR(SUM(ITE.VLRTOT), 'FM999999999990D00', 'NLS_NUMERIC_CHARACTERS = ''.,''') AS TOTAL_VENDAS_JS
FROM TGFCAB CAB
INNER JOIN TGFITE ITE ON CAB.NUNOTA = ITE.NUNOTA
INNER JOIN TGFPRO PRO ON PRO.CODPROD = ITE.CODPROD
INNER JOIN TGFPAR PAR ON CAB.CODPARC = PAR.CODPARC
INNER JOIN TSICID CID ON PAR.CODCID = CID.CODCID
INNER JOIN TSIUFS UFS ON CID.UF = UFS.CODUF
WHERE CAB.STATUSNOTA = 'L'
  AND CAB.TIPMOV = 'V'
  AND PRO.USOPROD = 'S'
  AND (CAB.DTNEG >= :P_DATA_INI OR :P_DATA_INI IS NULL)
  AND (CAB.DTNEG <= :P_DATA_FIM OR :P_DATA_FIM IS NULL)
  AND (:P_EMPRESA IS NULL OR CAB.CODEMP IN (:P_EMPRESA))
  AND (:P_TOP IS NULL OR CAB.CODTIPOPER IN (:P_TOP))
  AND (:P_UF IS NULL OR UFS.CODUF IN (:P_UF))
GROUP BY UFS.UF
ORDER BY TOTAL_VENDAS DESC
</snk:query>

<snk:query var="q_resumo_iss_municipio">
WITH BASE AS (
    SELECT
        CID.NOMECID,
        UFS.UF,
        SUM(NVL(ITE.VLRISS, 0)) AS VALOR_ISS
    FROM TGFCAB CAB
    INNER JOIN TGFITE ITE ON CAB.NUNOTA = ITE.NUNOTA
    INNER JOIN TGFPRO PRO ON PRO.CODPROD = ITE.CODPROD
    INNER JOIN TSICID CID ON CAB.CODCIDPREST = CID.CODCID
    INNER JOIN TSIUFS UFS ON CID.UF = UFS.CODUF
    WHERE CAB.STATUSNOTA = 'L'
      AND CAB.TIPMOV = 'V'
      AND PRO.USOPROD = 'S'
      AND (CAB.DTNEG >= :P_DATA_INI OR :P_DATA_INI IS NULL)
      AND (CAB.DTNEG <= :P_DATA_FIM OR :P_DATA_FIM IS NULL)
      AND (:P_EMPRESA IS NULL OR CAB.CODEMP IN (:P_EMPRESA))
      AND (:P_TOP IS NULL OR CAB.CODTIPOPER IN (:P_TOP))
      AND (:P_UF IS NULL OR UFS.CODUF IN (:P_UF))
    GROUP BY CID.NOMECID, UFS.UF
    HAVING SUM(NVL(ITE.VLRISS, 0)) > 0
)
SELECT
    COUNT(*) AS QTD_MUNICIPIOS,
    TO_CHAR(COUNT(*), 'FM999G999G990', 'NLS_NUMERIC_CHARACTERS = '',.''') AS QTD_MUNICIPIOS_FMT,
    COUNT(DISTINCT UF) AS QTD_ESTADOS,
    TO_CHAR(COUNT(DISTINCT UF), 'FM999G999G990', 'NLS_NUMERIC_CHARACTERS = '',.''') AS QTD_ESTADOS_FMT,
    TO_CHAR(NVL(SUM(VALOR_ISS), 0), 'FM999G999G999G990D00', 'NLS_NUMERIC_CHARACTERS = '',.''') AS TOTAL_ISS_FMT,
    TO_CHAR(NVL(MAX(VALOR_ISS), 0), 'FM999G999G999G990D00', 'NLS_NUMERIC_CHARACTERS = '',.''') AS MAIOR_ISS_FMT
FROM BASE
</snk:query>

<snk:query var="q_mapa_iss_estado">
SELECT
    LOWER(UFS.UF) AS UF,
    UFS.UF AS ESTADO,
    UFS.DESCRICAO AS NOME_ESTADO,
    SUM(NVL(ITE.VLRISS, 0)) AS TOTAL_ISS,
    TO_CHAR(SUM(NVL(ITE.VLRISS, 0)), 'FM999G999G999G990D00', 'NLS_NUMERIC_CHARACTERS = '',.''') AS TOTAL_ISS_FMT,
    TO_CHAR(SUM(NVL(ITE.VLRISS, 0)), 'FM999999999990D00', 'NLS_NUMERIC_CHARACTERS = ''.,''') AS TOTAL_ISS_JS
FROM TGFCAB CAB
INNER JOIN TGFITE ITE ON CAB.NUNOTA = ITE.NUNOTA
INNER JOIN TGFPRO PRO ON PRO.CODPROD = ITE.CODPROD
INNER JOIN TSICID CID ON CAB.CODCIDPREST = CID.CODCID
INNER JOIN TSIUFS UFS ON CID.UF = UFS.CODUF
WHERE CAB.STATUSNOTA = 'L'
  AND CAB.TIPMOV = 'V'
  AND PRO.USOPROD = 'S'
  AND (CAB.DTNEG >= :P_DATA_INI OR :P_DATA_INI IS NULL)
  AND (CAB.DTNEG <= :P_DATA_FIM OR :P_DATA_FIM IS NULL)
  AND (:P_EMPRESA IS NULL OR CAB.CODEMP IN (:P_EMPRESA))
  AND (:P_TOP IS NULL OR CAB.CODTIPOPER IN (:P_TOP))
  AND (:P_UF IS NULL OR UFS.CODUF IN (:P_UF))
GROUP BY UFS.UF, UFS.DESCRICAO
HAVING SUM(NVL(ITE.VLRISS, 0)) > 0
ORDER BY TOTAL_ISS DESC
</snk:query>

<snk:query var="q_iss_municipio">
SELECT
    NOMECID,
    DESCRICAO,
    UF,
    VALOR_ISS,
    TO_CHAR(VALOR_ISS, 'FM999G999G999G990D00', 'NLS_NUMERIC_CHARACTERS = '',.''') AS VALOR_ISS_FMT,
    (VALOR_ISS / NULLIF(SUM(VALOR_ISS) OVER(), 0)) * 100 AS PERC,
    TO_CHAR((VALOR_ISS / NULLIF(SUM(VALOR_ISS) OVER(), 0)) * 100, 'FM990D00', 'NLS_NUMERIC_CHARACTERS = '',.''') AS PERC_FMT
FROM (
    SELECT
        CID.NOMECID,
        UFS.DESCRICAO,
        UFS.UF,
        SUM(NVL(ITE.VLRISS, 0)) AS VALOR_ISS
    FROM TGFCAB CAB
    INNER JOIN TGFITE ITE ON CAB.NUNOTA = ITE.NUNOTA
    INNER JOIN TGFPRO PRO ON PRO.CODPROD = ITE.CODPROD
    INNER JOIN TSICID CID ON CAB.CODCIDPREST = CID.CODCID
    INNER JOIN TSIUFS UFS ON CID.UF = UFS.CODUF
    WHERE CAB.STATUSNOTA = 'L'
      AND CAB.TIPMOV = 'V'
      AND PRO.USOPROD = 'S'
      AND (CAB.DTNEG >= :P_DATA_INI OR :P_DATA_INI IS NULL)
      AND (CAB.DTNEG <= :P_DATA_FIM OR :P_DATA_FIM IS NULL)
      AND (:P_EMPRESA IS NULL OR CAB.CODEMP IN (:P_EMPRESA))
      AND (:P_TOP IS NULL OR CAB.CODTIPOPER IN (:P_TOP))
      AND (:P_UF IS NULL OR UFS.CODUF IN (:P_UF))
    GROUP BY CID.NOMECID, UFS.DESCRICAO, UFS.UF
    HAVING SUM(NVL(ITE.VLRISS, 0)) > 0
)
ORDER BY VALOR_ISS DESC
</snk:query>

<snk:query var="q_cht_iss_municipio">
SELECT *
FROM (
    SELECT
        CID.NOMECID AS CIDADE,
        SUM(NVL(ITE.VLRISS, 0)) AS VALOR,
        TO_CHAR(SUM(NVL(ITE.VLRISS, 0)), 'FM999999999990D00', 'NLS_NUMERIC_CHARACTERS = ''.,''') AS VALOR_JS
    FROM TGFCAB CAB
    INNER JOIN TGFITE ITE ON CAB.NUNOTA = ITE.NUNOTA
    INNER JOIN TGFPRO PRO ON PRO.CODPROD = ITE.CODPROD
    INNER JOIN TSICID CID ON CAB.CODCIDPREST = CID.CODCID
    INNER JOIN TSIUFS UFS ON CID.UF = UFS.CODUF
    WHERE CAB.STATUSNOTA = 'L'
      AND CAB.TIPMOV = 'V'
      AND PRO.USOPROD = 'S'
      AND (CAB.DTNEG >= :P_DATA_INI OR :P_DATA_INI IS NULL)
      AND (CAB.DTNEG <= :P_DATA_FIM OR :P_DATA_FIM IS NULL)
      AND (:P_EMPRESA IS NULL OR CAB.CODEMP IN (:P_EMPRESA))
      AND (:P_TOP IS NULL OR CAB.CODTIPOPER IN (:P_TOP))
      AND (:P_UF IS NULL OR UFS.CODUF IN (:P_UF))
    GROUP BY CID.NOMECID
    HAVING SUM(NVL(ITE.VLRISS, 0)) > 0
    ORDER BY VALOR DESC
)
WHERE ROWNUM <= 10
</snk:query>

<div id="dados-graficos-cidade" style="display:none;">
    <div id="dados-iss-municipio">
        <c:forEach var="row" items="${q_cht_iss_municipio.rows}">
            <span class="iss-municipio-row"
                  data-valor="<c:out value='${row.VALOR_JS}'/>"><c:out value="${row.CIDADE}"/></span>
        </c:forEach>
    </div>
</div>

<div class="app">
    <aside class="sidebar">
        <div class="brand" onclick="voltarMenuInicial()" title="Voltar ao menu inicial">
            <div class="brand-icon">
                <i class="fa-solid fa-bars"></i>
            </div>
            <span>Menu Inicial</span>
        </div>

        <div class="nav-title">Dashboard</div>
        <button class="nav-item" type="button" onclick="voltarMenuInicial()">
            <i class="fa-solid fa-house"></i> Início
        </button>

        <button class="nav-item" type="button" onclick="abrirNivel('lvl_tomadores')">
            <i class="fa-solid fa-briefcase"></i> Análise Tomadores
        </button>

        <button class="nav-item active" type="button" onclick="abrirNivel('lvl_fat_cidade')">
            <i class="fa-solid fa-city"></i> Movimento por Município
        </button>
        <button class="nav-item" id="btnMenuIssMunicipio" type="button" onclick="toggleIssMunicipio()">
            <i class="fa-solid fa-map-location-dot"></i> ISS por Município
        </button>

        <button class="nav-item" type="button" onclick="abrirNivel('lvl_mapa_tributario')">
            <i class="fa-solid fa-layer-group"></i> Auditoria de Impostos
        </button>
        <button class="nav-item" type="button" onclick="abrirServicosSemMovimento()">
            <i class="fa-solid fa-screwdriver-wrench"></i> Serviços
        </button>
        <button class="nav-item" type="button" onclick="abrirNivel('lvl_servicos_prestados_tomados')">
            <i class="fa-solid fa-clipboard-list"></i> Prestados / Tomados
        </button>
        <button class="nav-item" type="button" onclick="abrirNivel('lvl_ajuda_painel')"><i class="fa-solid fa-circle-question"></i> Ajuda / FAQ</button>
    
    
    </aside>

    <main class="main">
        <section class="topbar">
            <div class="topbar-left">
                <div class="title-icon"><i class="fa-solid fa-city"></i></div>
                <div>
                    <h1>Faturamento por Cidade / UF</h1>
                </div>
            </div>
        </section>

        <section class="dash-grid">
            <div class="card span-12">
                <c:forEach items="${q_resumo_fat_cidade.rows}" var="resumo">
                    <div class="resumo-card">
                        <div class="resumo-total">
                            <div class="resumo-icon"><i class="fa-solid fa-sack-dollar"></i></div>
                            <div>
                                <span class="resumo-label">Faturamento</span>
                                <div class="resumo-value">R$ ${resumo.FAT_TOTAL_FMT}</div>
                            </div>
                        </div>

                        <div class="metric-box cidades">
                            <div class="metric-top">
                                <span class="resumo-label">Cidades</span>
                                <span class="metric-icon"><i class="fa-solid fa-location-dot"></i></span>
                            </div>
                            <div class="metric-value">${resumo.QTD_CIDADES_FMT}</div>
                            <div class="metric-desc">cidade(s) com faturamento</div>
                        </div>

                        <div class="metric-box estados">
                            <div class="metric-top">
                                <span class="resumo-label">Estados</span>
                                <span class="metric-icon"><i class="fa-solid fa-map"></i></span>
                            </div>
                            <div class="metric-value">${resumo.QTD_ESTADOS_FMT}</div>
                            <div class="metric-desc">UF(s) alcançadas</div>
                        </div>

                        <div class="metric-box topcidade">
                            <div class="metric-top">
                                <span class="resumo-label">Cidade destaque</span>
                                <span class="metric-icon"><i class="fa-solid fa-trophy"></i></span>
                            </div>
                            <div class="metric-value" style="font-size:18px;">${resumo.TOP_CIDADE}</div>
                        </div>
                    </div>
                </c:forEach>
            </div>

            <div class="card mapa-card span-7">
                <div class="card-head">
                    <div>
                        <h2 class="card-title"><i class="fa-solid fa-map-location-dot"></i> Mapa de Calor por UF</h2>
                    </div>
                </div>

                <div id="mapaBrasil"></div>
            </div>

            <div class="card span-5">
                <div class="card-head">
                    <h2 class="card-title"><i class="fa-solid fa-map"></i> Faturamento por UF</h2>
                </div>
                <div class="table-wrapper">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>UF</th>
                                <th>Estado</th>
                                <th class="align-right">Faturamento</th>
                            </tr>
                        </thead>
                        <tbody>
                            <c:forEach items="${q_fat_estado.rows}" var="row">
                                <tr>
                                    <td><span class="uf-pill">${row.UF}</span></td>
                                    <td>${row.ESTADO}</td>
                                    <td class="align-right">R$ ${row.VALOR_FMT}</td>
                                </tr>
                            </c:forEach>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="card span-12">
                <div class="card-head">
                    <h2 class="card-title"><i class="fa-solid fa-table-list"></i> Detalhamento por cidade</h2>
                </div>
                <div class="table-wrapper">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Cidade</th>
                                <th>UF</th>
                                <th>Estado</th>
                                <th class="align-right">Faturamento</th>
                                <th class="align-right">% Part.</th>
                            </tr>
                        </thead>
                        <tbody>
                            <c:forEach items="${q_fat_cidade.rows}" var="row">
                                <tr>
                                    <td>${row.CIDADE}</td>
                                    <td><span class="uf-pill">${row.UF}</span></td>
                                    <td>${row.ESTADO}</td>
                                    <td class="align-right">R$ ${row.VALOR_FMT}</td>
                                    <td class="align-right">${row.PERC_FMT}%</td>
                                </tr>
                            </c:forEach>
                        </tbody>
                    </table>
                </div>
            </div>

            <section class="inline-detail" id="issMunicipioInline">
            <div class="card span-12">
                <c:forEach items="${q_resumo_iss_municipio.rows}" var="issmun">
                    <div class="resumo-card">
                        <div class="resumo-total">
                            <div class="resumo-icon" style="background:var(--orange-soft); color:var(--orange);"><i class="fa-solid fa-scale-balanced"></i></div>
                            <div>
                                <span class="resumo-label">ISS por Município</span>
                                <div class="resumo-value">R$ ${issmun.TOTAL_ISS_FMT}</div>
                                <div class="resumo-sub">${issmun.QTD_MUNICIPIOS_FMT} município(s) com ISS retido</div>
                            </div>
                            <button class="section-action" type="button" onclick="toggleIssMunicipio()">Ocultar detalhe</button>
                        </div>

                        <div class="metric-box cidades">
                            <div class="metric-top">
                                <span class="resumo-label">Municípios</span>
                                <span class="metric-icon"><i class="fa-solid fa-location-dot"></i></span>
                            </div>
                            <div class="metric-value">${issmun.QTD_MUNICIPIOS_FMT}</div>
                            <div class="metric-desc">com recolhimento de ISS</div>
                        </div>

                        <div class="metric-box estados">
                            <div class="metric-top">
                                <span class="resumo-label">Estados</span>
                                <span class="metric-icon"><i class="fa-solid fa-map"></i></span>
                            </div>
                            <div class="metric-value">${issmun.QTD_ESTADOS_FMT}</div>
                            <div class="metric-desc">UF(s) com ISS</div>
                        </div>

                        <div class="metric-box topcidade">
                            <div class="metric-top">
                                <span class="resumo-label">Maior ISS</span>
                                <span class="metric-icon"><i class="fa-solid fa-arrow-trend-up"></i></span>
                            </div>
                            <div class="metric-value" style="font-size:18px;">R$ ${issmun.MAIOR_ISS_FMT}</div>
                        </div>
                    </div>
                </c:forEach>
            </div>

            <div class="card mapa-card span-7">
                <div class="card-head">
                    <h2 class="card-title warning"><i class="fa-solid fa-map-location-dot"></i> Mapa de ISS por UF</h2>
                </div>
                <div id="mapaIssBrasil"></div>
            </div>

            <div class="card span-5">
                <div class="card-head">
                    <h2 class="card-title warning"><i class="fa-solid fa-map"></i> ISS por UF</h2>
                </div>
                <div class="table-wrapper">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>UF</th>
                                <th>Estado</th>
                                <th class="align-right">ISS Retido</th>
                            </tr>
                        </thead>
                        <tbody>
                            <c:forEach items="${q_mapa_iss_estado.rows}" var="row">
                                <tr>
                                    <td><span class="uf-pill">${row.ESTADO}</span></td>
                                    <td>${row.NOME_ESTADO}</td>
                                    <td class="align-right">R$ ${row.TOTAL_ISS_FMT}</td>
                                </tr>
                            </c:forEach>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="card span-12">
                <div class="card-head">
                    <h2 class="card-title warning"><i class="fa-solid fa-chart-column"></i> Top 10 cidades por ISS</h2>
                </div>
                <div id="chartIssMunicipio" class="chart"></div>
            </div>

            <div class="card span-12">
                <div class="card-head">
                    <h2 class="card-title warning"><i class="fa-solid fa-table-list"></i> Detalhamento de ISS por município</h2>
                    <span class="badge">Ordenado por ISS retido</span>
                </div>
                <div class="table-wrapper">
                    <table class="data-table iss-municipio-table">
                        <colgroup>
                            <col class="col-cidade">
                            <col class="col-uf">
                            <col class="col-estado">
                            <col class="col-valor">
                            <col class="col-perc">
                        </colgroup>
                        <thead>
                            <tr>
                                <th>Cidade</th>
                                <th class="align-center">UF</th>
                                <th>Estado</th>
                                <th class="align-right money-cell">ISS Retido</th>
                                <th class="align-right perc-cell">% Part.</th>
                            </tr>
                        </thead>
                        <tbody>
                            <c:forEach items="${q_iss_municipio.rows}" var="row">
                                <tr>
                                    <td>${row.NOMECID}</td>
                                    <td class="align-center"><span class="uf-pill">${row.UF}</span></td>
                                    <td>${row.DESCRICAO}</td>
                                    <td class="align-right money-cell">R$ ${row.VALOR_ISS_FMT}</td>
                                    <td class="align-right perc-cell">${row.PERC_FMT}%</td>
                                </tr>
                            </c:forEach>
                        </tbody>
                    </table>
                </div>
            </div>
            </section>
        </section>
    </main>
</div>

<script>
    function voltarMenuInicial() {
        openLevel('lvl_serv_capa', {});
    }
    
    function abrirNivel(levelId, params) {
        params = params || {};
        try {
            if (typeof openLevel === 'function') {
                openLevel(levelId, params);
            } else if (window.parent && typeof window.parent.openLevel === 'function') {
                window.parent.openLevel(levelId, params);
            } else {
                alert('Não foi possível abrir o nível: ' + levelId);
            }
        } catch (e) {
            console.error('Erro ao abrir nível:', levelId, e);
        }
    }

    function abrirServicosSemMovimento() {
        try {
            if (window.parent) {
                window.parent.__abrirServicosSemMov = true;
            }
        } catch (e) {}
        abrirNivel('lvl_mapa_tributario', { ABRIR_SERVICOS: 'S' });
    }

    function toggleIssMunicipio() {
        var detalhe = document.getElementById('issMunicipioInline');
        var botao = document.getElementById('btnMenuIssMunicipio');
        if (!detalhe || !botao) return;

        var vaiAbrir = !detalhe.classList.contains('is-open');
        detalhe.classList.toggle('is-open', vaiAbrir);
        botao.classList.toggle('active', vaiAbrir);

        if (vaiAbrir) {
            detalhe.scrollIntoView({ behavior: 'smooth', block: 'start' });
            setTimeout(function() {
                if (window.mapaIssChart && typeof window.mapaIssChart.reflow === 'function') window.mapaIssChart.reflow();
                if (window.chartIssMunicipio && typeof window.chartIssMunicipio.reflow === 'function') window.chartIssMunicipio.reflow();
            }, 120);
        }
    }

    function toNumber(value) {
        if (value === null || value === undefined || value === '') return 0;
        value = String(value).trim();
        if (value.indexOf(',') >= 0) {
            value = value.replace(/\./g, '').replace(',', '.');
        }
        return Number(value) || 0;
    }

    var dadosMapa = [];
    <c:forEach var="row" items="${q_mapa_cidades.rows}">
        dadosMapa.push([
            'br-${fn:toLowerCase(row.UF)}',
            toNumber('${row.TOTAL_VENDAS_JS}')
        ]);
    </c:forEach>

    var dadosMapaIss = [];
    <c:forEach var="row" items="${q_mapa_iss_estado.rows}">
        dadosMapaIss.push([
            'br-${fn:toLowerCase(row.UF)}',
            toNumber('${row.TOTAL_ISS_JS}')
        ]);
    </c:forEach>

    var issMunicipioCats = [];
    var issMunicipioData = [];
    document.querySelectorAll('#dados-iss-municipio .iss-municipio-row').forEach(function (el) {
        issMunicipioCats.push((el.textContent || '').trim());
        issMunicipioData.push(toNumber(el.getAttribute('data-valor')));
    });

    document.addEventListener('DOMContentLoaded', function() {
        if (typeof Highcharts === 'undefined') {
            document.getElementById('mapaBrasil').innerHTML =
                '<div style="padding:20px;color:#b91c1c;font-weight:700;">Highcharts não carregou.</div>';
            return;
        }

        Highcharts.setOptions({
            chart: { animation: false },
            plotOptions: { series: { animation: false } },
            accessibility: { enabled: false }
        });

        if (Highcharts.maps && Highcharts.maps['countries/br/br-all']) {
            Highcharts.mapChart('mapaBrasil', {
                chart: {
                    map: Highcharts.maps['countries/br/br-all'],
                    backgroundColor: 'transparent',
                    spacing: [8, 8, 8, 8]
                },
                title: { text: null },
                accessibility: { enabled: false },
                credits: { enabled: false },
                exporting: { enabled: false },
                legend: {
                    layout: 'horizontal',
                    align: 'center',
                    verticalAlign: 'bottom',
                    itemStyle: { color: '#5e6b7f', fontSize: '11px' }
                },
                mapNavigation: {
                    enabled: true,
                    buttonOptions: { verticalAlign: 'bottom' }
                },
                colorAxis: {
                    min: 0,
                    minColor: '#dbeafe',
                    maxColor: '#1d4ed8',
                    labels: {
                        formatter: function () {
                            return 'R$ ' + Highcharts.numberFormat(this.value, 0, ',', '.');
                        },
                        style: { color: '#5e6b7f', fontSize: '10px' }
                    }
                },
                tooltip: {
                    useHTML: true,
                    formatter: function () {
                        var valor = this.point.value || 0;
                        return '<div style="padding:4px 6px;">' +
                               '<b>' + this.point.name + '</b><br>' +
                               'Faturamento:<br><b>R$ ' + Highcharts.numberFormat(valor, 2, ',', '.') + '</b>' +
                               '</div>';
                    }
                },
                series: [{
                    type: 'map',
                    mapData: Highcharts.maps['countries/br/br-all'],
                    data: dadosMapa,
                    keys: ['hc-key', 'value'],
                    joinBy: 'hc-key',
                    allAreas: true,
                    nullColor: '#edf2f7',
                    name: 'Faturamento',
                    borderColor: '#ffffff',
                    borderWidth: 0.8,
                    states: { hover: { color: '#f59e0b' } },
                    dataLabels: {
                        enabled: true,
                        format: '{point.properties.postal-code}',
                        style: {
                            color: '#172033',
                            textOutline: 'none',
                            fontSize: '10px',
                            fontWeight: '700'
                        }
                    }
                }]
            });
            window.mapaIssChart = Highcharts.mapChart('mapaIssBrasil', {
                chart: {
                    map: Highcharts.maps['countries/br/br-all'],
                    backgroundColor: 'transparent',
                    spacing: [8, 8, 8, 8]
                },
                title: { text: null },
                accessibility: { enabled: false },
                credits: { enabled: false },
                exporting: { enabled: false },
                legend: {
                    layout: 'horizontal',
                    align: 'center',
                    verticalAlign: 'bottom',
                    itemStyle: { color: '#5e6b7f', fontSize: '11px' }
                },
                mapNavigation: {
                    enabled: true,
                    buttonOptions: { verticalAlign: 'bottom' }
                },
                colorAxis: {
                    min: 0,
                    minColor: '#fff7ed',
                    maxColor: '#ea580c',
                    labels: {
                        formatter: function () {
                            return 'R$ ' + Highcharts.numberFormat(this.value, 0, ',', '.');
                        },
                        style: { color: '#5e6b7f', fontSize: '10px' }
                    }
                },
                tooltip: {
                    useHTML: true,
                    formatter: function () {
                        var valor = this.point.value || 0;
                        return '<div style="padding:4px 6px;">' +
                               '<b>' + this.point.name + '</b><br>' +
                               'ISS retido:<br><b>R$ ' + Highcharts.numberFormat(valor, 2, ',', '.') + '</b>' +
                               '</div>';
                    }
                },
                series: [{
                    type: 'map',
                    mapData: Highcharts.maps['countries/br/br-all'],
                    data: dadosMapaIss,
                    keys: ['hc-key', 'value'],
                    joinBy: 'hc-key',
                    allAreas: true,
                    nullColor: '#fff7ed',
                    name: 'ISS retido',
                    borderColor: '#ffffff',
                    borderWidth: 0.8,
                    states: { hover: { color: '#21a366' } },
                    dataLabels: {
                        enabled: true,
                        format: '{point.properties.postal-code}',
                        style: {
                            color: '#172033',
                            textOutline: 'none',
                            fontSize: '10px',
                            fontWeight: '700'
                        }
                    }
                }]
            });
        } else {
            document.getElementById('mapaBrasil').innerHTML =
                '<div style="padding:20px;color:#b91c1c;font-weight:700;">Mapa do Brasil não carregado. Verifique se o arquivo br-all.js está na mesma pasta do JSP.</div>';
        }

        window.chartIssMunicipio = Highcharts.chart('chartIssMunicipio', {
            chart: { type: 'column', backgroundColor: 'transparent', animation: false },
            accessibility: { enabled: false },
            title: { text: null },
            credits: { enabled: false },
            xAxis: {
                categories: issMunicipioCats,
                labels: { rotation: -35, style: { color: '#5e6b7f', fontSize: '11px' } }
            },
            yAxis: { title: { text: null }, gridLineColor: '#edf1f6' },
            tooltip: {
                formatter: function() {
                    return '<b>R$ ' + Highcharts.numberFormat(this.y, 2, ',', '.') + '</b>';
                }
            },
            plotOptions: {
                column: {
                    animation: false,
                    borderRadius: 7,
                    color: '#f59e0b',
                    dataLabels: {
                        enabled: true,
                        formatter: function() {
                            return 'R$ ' + Highcharts.numberFormat(this.y, 2, ',', '.');
                        },
                        style: { color: '#92400e', textOutline: 'none', fontSize: '10px' }
                    }
                }
            },
            series: [{ name: 'ISS retido', data: issMunicipioData }]
        });

        var abrirIssViaMenu = false;
        try {
            abrirIssViaMenu = !!(window.parent && window.parent.__abrirIssMunicipio);
            if (abrirIssViaMenu) {
                window.parent.__abrirIssMunicipio = false;
            }
        } catch (e) {}

        if (abrirIssMunicipioInicial === 'S' || abrirIssViaMenu) {
            setTimeout(function() {
                toggleIssMunicipio();
            }, 120);
        }
    });
</script>
</body>
</html>
