<%@ page language="java" contentType="application/vnd.ms-excel; charset=UTF-8" pageEncoding="UTF-8" trimDirectiveWhitespaces="true" isELIgnored="false" %>
<%@ taglib uri="http://java.sun.com/jstl/core_rt" prefix="c" %>
<%@ taglib prefix="snk" uri="/WEB-INF/tld/sankhyaUtil.tld" %>

<%
    response.setContentType("application/vnd.ms-excel; charset=UTF-8");
    response.setCharacterEncoding("UTF-8");
    response.setHeader("Content-Disposition", "attachment; filename=\"mapa_tributario.xls\"");
    response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
    response.setHeader("Pragma", "no-cache");
    response.setDateHeader("Expires", 0);
%>

<snk:query var="q_export_mapa">
SELECT
    CAB.NUNOTA,
    CAB.DTNEG,
    TO_CHAR(CAB.DTNEG, 'DD/MM/YYYY') AS DTNEG_FMT,
    CAB.CODEMP,
    PRO.DESCRPROD,
    ITE.VLRTOT AS VALOR_BRUTO,
    TO_CHAR(ITE.VLRTOT, 'FM999G999G999G990D00', 'NLS_NUMERIC_CHARACTERS = '',.''') AS VALOR_BRUTO_FMT,
    NVL(D.VALOR, 0) AS VLR_ISS,
    TO_CHAR(NVL(D.VALOR, 0), 'FM999G999G999G990D00', 'NLS_NUMERIC_CHARACTERS = '',.''') AS VLR_ISS_FMT,
    CAB.ISSRETIDO AS ISS_RETIDO_CAB,
    NVL(M.VALOR, 0) AS VLR_PIS,
    TO_CHAR(NVL(M.VALOR, 0), 'FM999G999G999G990D00', 'NLS_NUMERIC_CHARACTERS = '',.''') AS VLR_PIS_FMT,
    NVL(M2.VALOR, 0) AS VLR_COFINS,
    TO_CHAR(NVL(M2.VALOR, 0), 'FM999G999G999G990D00', 'NLS_NUMERIC_CHARACTERS = '',.''') AS VLR_COFINS_FMT,
    NVL(M3.VALOR, 0) AS VLR_CSLL,
    TO_CHAR(NVL(M3.VALOR, 0), 'FM999G999G999G990D00', 'NLS_NUMERIC_CHARACTERS = '',.''') AS VLR_CSLL_FMT,
    NVL(M4.VALOR, 0) AS VLR_IR,
    TO_CHAR(NVL(M4.VALOR, 0), 'FM999G999G999G990D00', 'NLS_NUMERIC_CHARACTERS = '',.''') AS VLR_IR_FMT,
    NVL(M5.VALOR, 0) AS VLR_INSS,
    TO_CHAR(NVL(M5.VALOR, 0), 'FM999G999G999G990D00', 'NLS_NUMERIC_CHARACTERS = '',.''') AS VLR_INSS_FMT,
    (ITE.VLRTOT - (NVL(M.VALOR, 0) + NVL(M2.VALOR, 0) + NVL(M3.VALOR, 0) + NVL(M4.VALOR, 0) + NVL(M5.VALOR, 0) + CASE WHEN ITE.CODTRIBISS = 1 THEN NVL(D.VALOR, 0) ELSE 0 END)) AS VALOR_LIQUIDO,
    TO_CHAR((ITE.VLRTOT - (NVL(M.VALOR, 0) + NVL(M2.VALOR, 0) + NVL(M3.VALOR, 0) + NVL(M4.VALOR, 0) + NVL(M5.VALOR, 0) + CASE WHEN ITE.CODTRIBISS = 1 THEN NVL(D.VALOR, 0) ELSE 0 END)), 'FM999G999G999G990D00', 'NLS_NUMERIC_CHARACTERS = '',.''') AS VALOR_LIQUIDO_FMT,
    CASE ITE.CODTRIBISS
        WHEN 0 THEN 'TRIBUTADO'
        WHEN 1 THEN 'ISS RETIDO'
        WHEN 7 THEN 'NÃO TRIBUTADO'
        WHEN 6 THEN 'ISENTO'
        ELSE 'OUTROS'
    END AS INC_ISS
FROM TGFCAB CAB
INNER JOIN TGFITE ITE ON ITE.NUNOTA = CAB.NUNOTA
INNER JOIN TGFPRO PRO ON PRO.CODPROD = ITE.CODPROD
INNER JOIN TGFPAR PAR ON PAR.CODPARC = CAB.CODPARC
INNER JOIN TSICID CID ON CID.CODCID = PAR.CODCID
INNER JOIN TSIUFS UFS ON UFS.CODUF = CID.UF
LEFT JOIN TGFDIN D ON D.NUNOTA = ITE.NUNOTA AND ITE.SEQUENCIA = D.SEQUENCIA AND D.CODIMP = 4
LEFT JOIN TGFIMN M ON M.NUNOTA = ITE.NUNOTA AND ITE.SEQUENCIA = M.SEQUENCIA AND M.CODIMP = 2
LEFT JOIN TGFIMN M2 ON M2.NUNOTA = ITE.NUNOTA AND ITE.SEQUENCIA = M2.SEQUENCIA AND M2.CODIMP = 3
LEFT JOIN TGFIMN M3 ON M3.NUNOTA = ITE.NUNOTA AND ITE.SEQUENCIA = M3.SEQUENCIA AND M3.CODIMP = 4
LEFT JOIN TGFIMN M4 ON M4.NUNOTA = ITE.NUNOTA AND ITE.SEQUENCIA = M4.SEQUENCIA AND M4.CODIMP = 7
LEFT JOIN TGFIMN M5 ON M5.NUNOTA = ITE.NUNOTA AND ITE.SEQUENCIA = M5.SEQUENCIA AND M5.CODIMP = 6
WHERE CAB.STATUSNOTA = 'L'
    AND CAB.TIPMOV = 'V'
    AND PRO.USOPROD = 'S'
    AND (CAB.DTNEG >= :P_DATA_INI OR :P_DATA_INI IS NULL)
    AND (CAB.DTNEG <= :P_DATA_FIM OR :P_DATA_FIM IS NULL)
ORDER BY CAB.DTNEG DESC, CAB.NUNOTA DESC
</snk:query>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <style>
        table {
            border-collapse: collapse;
            font-family: Arial, sans-serif;
            font-size: 12px;
        }
        th {
            background: #1f4e78;
            color: #ffffff;
            font-weight: bold;
            border: 1px solid #d9e2f3;
            padding: 6px;
            text-align: center;
            white-space: nowrap;
        }
        td {
            border: 1px solid #d9e2f3;
            padding: 5px;
            vertical-align: top;
        }
        .texto {
            mso-number-format: "\\@";
        }
        .numero {
            mso-number-format: "\\#\\.\\#\\#0\\,00";
            text-align: right;
        }
        .inteiro {
            mso-number-format: "0";
            text-align: right;
        }
        .data {
            mso-number-format: "dd/mm/yyyy";
            text-align: center;
        }
    </style>
</head>
<body>
    <table>
        <thead>
            <tr>
                <th>NUNOTA</th>
                <th>DATA</th>
                <th>EMPRESA</th>
                <th>SERVIÇO</th>
                <th>VALOR BRUTO</th>
                <th>ISS</th>
                <th>PIS</th>
                <th>COFINS</th>
                <th>CSLL</th>
                <th>IR</th>
                <th>INSS</th>
                <th>VALOR LÍQUIDO</th>
                <th>INCIDÊNCIA ISS</th>
            </tr>
        </thead>
        <tbody>
            <c:forEach items="${q_export_mapa.rows}" var="row">
                <tr>
                    <td class="inteiro"><c:out value="${row.NUNOTA}"/></td>
                    <td class="data"><c:out value="${row.DTNEG_FMT}"/></td>
                    <td class="inteiro"><c:out value="${row.CODEMP}"/></td>
                    <td class="texto"><c:out value="${row.DESCRPROD}"/></td>
                    <td class="numero"><c:out value="${row.VALOR_BRUTO_FMT}"/></td>
                    <td class="numero"><c:out value="${row.VLR_ISS_FMT}"/></td>
                    <td class="numero"><c:out value="${row.VLR_PIS_FMT}"/></td>
                    <td class="numero"><c:out value="${row.VLR_COFINS_FMT}"/></td>
                    <td class="numero"><c:out value="${row.VLR_CSLL_FMT}"/></td>
                    <td class="numero"><c:out value="${row.VLR_IR_FMT}"/></td>
                    <td class="numero"><c:out value="${row.VLR_INSS_FMT}"/></td>
                    <td class="numero"><c:out value="${row.VALOR_LIQUIDO_FMT}"/></td>
                    <td class="texto"><c:out value="${row.INC_ISS}"/></td>
                </tr>
            </c:forEach>
        </tbody>
    </table>
</body>
</html>
