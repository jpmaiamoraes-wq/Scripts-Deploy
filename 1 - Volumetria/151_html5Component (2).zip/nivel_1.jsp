<%@ page language="java" contentType="text/html; charset=ISO-8859-1" pageEncoding="UTF-8" isELIgnored ="false"%>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<%@ page import="java.util.*" %>
<%@ taglib uri="http://java.sun.com/jstl/core_rt" prefix="c" %>
<%@ taglib prefix="snk" uri="/WEB-INF/tld/sankhyaUtil.tld" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/functions" prefix="fn" %>
<html lang="pt-BR">
<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Volumetria - Deploy Agent - Nivel 1</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <snk:load/> <!-- essa tag deve ficar nesta posição -->

    <!-- abrir nivel Comercial -->
    <script type='text/javascript'>
        function abrirComercial(codUSU){
            var params = {'A_CODUSU' : codUSU};
            openLevel('lvl_a1magup', params);
           }
    </script>

    <!-- abrir nivel Folha -->
    <script type='text/javascript'>
        function abrirFolha(codUSU){
            var params = {'A_CODUSU' : codUSU};
            openLevel('lvl_adkcmp6', params);
           }
    </script>
    
    <style>
      :root {
        /* Paleta principal */
        --primary-color: #2e3c50;
        --secondary-color: #66cc66;
        --accent-color: #66246b;

        /* Variações */
        --primary-light: #4a5568;
        --primary-dark: #1a202c;
        --secondary-light: #9ae6b4;
        --secondary-dark: #38a169;
        --accent-light: #9f7aea;

        /* Cores neutras */
        --white: #ffffff;
        --gray-50: #f9fafb;
        --gray-100: #f3f4f6;
        --gray-200: #e5e7eb;
        --gray-300: #d1d5db;
        --gray-500: #6b7280;
        --gray-700: #374151;

        /* Sombras */
        --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
        --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
        --shadow-xl: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);

        /* Espaçamentos */
        --spacing-md: 1rem;
        --spacing-lg: 1.5rem;
        --spacing-xl: 2rem;

        /* Transições */
        --transition-base: 0.3s ease-out;
      }

      * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
      }

      html {
        font-size: 16px;
        scroll-behavior: smooth;
      }

      body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        line-height: 1.6;
        color: var(--gray-700);
        background: linear-gradient(135deg, var(--gray-50) 0%, var(--gray-100) 100%);
        min-height: 100vh;
        display: flex;
        flex-direction: column;
        padding: var(--spacing-md);
      }

      .dashboard-header {
        background: linear-gradient(135deg, #66CC66 0%, transparent 100%);
        backdrop-filter: blur(10px);
        border-radius: 16px;
        padding: 24px 32px;
        margin-bottom: 24px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.2);
        width: 100%;
        max-width: 1200px;
        margin-left: auto;
        margin-right: auto;
      }

      .dashboard-header h1 {
        font-size: 28px;
        font-weight: 700;
        color: #1a202c;
        display: flex;
        align-items: center;
        gap: 12px;
        margin: 0;
      }

      .header-controls {
        display: flex;
        gap: 12px;
      }

      .header-controls a {
        display: flex;
        align-items: center;
      }

      .header-controls img {
        transition: all var(--transition-base);
      }

      .header-controls a:hover img {
        transform: scale(1.05);
      }

      .wrapper {
        display: flex;
        flex-direction: column;
        align-items: center;
        width: 100%;
        flex: 1;
      }

      .container {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
        gap: var(--spacing-lg);
        max-width: 700px;
        width: 100%;
      }

      .card {
        background: var(--white);
        border-radius: 16px;
        padding: var(--spacing-xl);
        box-shadow: var(--shadow-md);
        border: 1px solid var(--gray-200);
        transition: all var(--transition-base);
        position: relative;
        overflow: hidden;
        cursor: pointer;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        text-align: center;
        min-height: 180px;
      }

      .card::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 4px;
        background: var(--primary-color);
        transition: all var(--transition-base);
      }

      .card:nth-child(2)::before {
        background: var(--secondary-color);
      }

      .card:hover {
        transform: translateY(-4px);
        box-shadow: var(--shadow-xl);
        border-color: var(--gray-300);
      }

      .card:hover::before {
        height: 6px;
      }

      .card h2 {
        font-size: 1.75rem;
        font-weight: 600;
        color: var(--primary-color);
        margin: 0;
        line-height: 1.4;
      }

      .card:nth-child(2) h2 {
        color: var(--secondary-dark);
      }

      @media (max-width: 768px) {
        .dashboard-header {
          flex-direction: column;
          gap: 16px;
          text-align: center;
          padding: 20px;
          margin-bottom: 20px;
        }

        .dashboard-header h1 {
          font-size: 24px;
          justify-content: center;
        }

        .header-controls {
          width: 100%;
          justify-content: center;
        }

        .container {
          grid-template-columns: 1fr;
          max-width: 100%;
        }

        .card {
          min-height: 160px;
        }

        .card h2 {
          font-size: 1.5rem;
        }
      }

      @keyframes slideIn {
        from {
          opacity: 0;
          transform: translateY(20px);
        }
        to {
          opacity: 1;
          transform: translateY(0);
        }
      }

      .card {
        animation: slideIn 0.6s ease-out forwards;
      }

      .card:nth-child(1) { animation-delay: 0.1s; }
      .card:nth-child(2) { animation-delay: 0.2s; }
    </style>

  </head>
  <body>

    <header class="dashboard-header">
      <h1>Volumetria Deploy Agent</h1>
      <div class="header-controls">
        <a href="https://www.sankhya.com.br" target="_blank">
            <img src="${BASE_FOLDER}img/logo_sankhya.svg" height="36" width="167"></img>
        </a>
      </div>
    </header>

    <div class="wrapper">
      <div class="container">
        <div class="card">
          <h2 onclick="javascript:abrirComercial( ${CODUSU_LOG} )">Comercial</h2>
        </div>
        <div class="card">
          <h2 onclick="javascript:abrirFolha( ${CODUSU_LOG} )">Folha</h2>
        </div>
      </div>
    </div>

  </body>
</html>