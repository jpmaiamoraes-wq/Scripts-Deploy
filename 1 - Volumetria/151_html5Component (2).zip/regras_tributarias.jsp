<%@ page language="java" contentType="text/html; charset=ISO-8859-1" pageEncoding="UTF-8" isELIgnored ="false"%>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<%@ taglib prefix="snk" uri="/WEB-INF/tld/sankhyaUtil.tld" %>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Seleção de Regras</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <snk:load/>
    
    <style>
        /* Estilos baseados no seu nivel_1.jsp */
        body { font-family: 'Inter', sans-serif; background: #f3f4f6; padding: 2rem; display: flex; justify-content: center; }
        .container { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1.5rem; width: 100%; max-width: 900px; }
        .card { background: white; border-radius: 16px; padding: 2rem; text-align: center; cursor: pointer; transition: 0.3s; border-top: 4px solid #2e3c50; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
        .card:hover { transform: translateY(-5px); box-shadow: 0 10px 15px rgba(0,0,0,0.1); }
        .card i { font-size: 2.5rem; color: #2e3c50; margin-bottom: 1rem; }
        .card h2 { font-size: 1.25rem; color: #374151; }
        /* Cores variadas para os cards */
        .card.transporte { border-top-color: #66cc66; }
        .card.gerais { border-top-color: #66246b; }
    </style>

    <script type='text/javascript'>
        function abrirProdutos(codUSU){
            openLevel('lvl_produtos_regra', {'A_CODUSU' : codUSU}); // Nível que já criamos anteriormente
        }
        function abrirTransporte(codUSU){
            openLevel('lvl_transporte', {'A_CODUSU' : codUSU}); // Você precisará criar este nível no XML
        }
        function abrirServicos(codUSU){
            openLevel('lvl_servicos_gerais', {'A_CODUSU' : codUSU}); // Você precisará criar este nível no XML
        }
    </script>
</head>
<body>
    <div class="container">
        <div class="card" onclick="abrirProdutos(${CODUSU_LOG})">
            <i class="fas fa-box"></i>
            <h2>Produtos</h2>
        </div>
        <div class="card transporte" onclick="abrirTransporte(${CODUSU_LOG})">
            <i class="fas fa-truck"></i>
            <h2>Serviços Transporte</h2>
        </div>
        <div class="card gerais" onclick="abrirServicos(${CODUSU_LOG})">
            <i class="fas fa-tools"></i>
            <h2>Serviços Gerais</h2>
        </div>
    </div>
</body>
</html>