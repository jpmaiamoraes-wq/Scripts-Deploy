<%@ page language="java" contentType="text/html; charset=ISO-8859-1" pageEncoding="UTF-8" isELIgnored ="false"%>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<%@ page import="java.util.*" %>
<%@ taglib uri="http://java.sun.com/jstl/core_rt" prefix="c" %>
<%@ taglib prefix="snk" uri="/WEB-INF/tld/sankhyaUtil.tld" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/functions" prefix="fn" %>
<html lang="pt-BR">
<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Volumetria - Deploy Agent</title>
    <link rel="stylesheet" type="text/css" href="${BASE_FOLDER}/styles.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <snk:load/> <!-- essa tag deve ficar nesta posição -->

    <!-- abrir nivel Dependentes Duplicados -->
    <script type='text/javascript'>
        function abrirID_217(codUSU){
            var params = {'A_CODUSU' : codUSU};
            openLevel('lvl_admt5rf', params);
           }
    </script>

    <!-- abrir nivel Dependentes sem CPF -->
    <script type='text/javascript'>
        function abrirID_218(codUSU){
            var params = {'A_CODUSU' : codUSU};
            openLevel('lvl_admt5uh', params);
           }
    </script>

    <!-- abrir nivel Funcionarios Duplicados -->
    <script type='text/javascript'>
        function abrirID_219(codUSU){
            var params = {'A_CODUSU' : codUSU};
            openLevel('lvl_admt5wl', params);
           }
    </script>

    <!-- abrir nivel Funcionarios Duplicados sem Folha -->
    <script type='text/javascript'>
        function abrirID_220(codUSU){
            var params = {'A_CODUSU' : codUSU};
            openLevel('lvl_admt5zv', params);
           }
    </script>

    <!-- abrir nivel Vinculo Vazio -->
    <script type='text/javascript'>
        function abrirID_221(codUSU){
            var params = {'A_CODUSU' : codUSU};
            openLevel('lvl_admt514', params);
           }
    </script>

    <!-- abrir nivel Salario Base Vazio -->
    <script type='text/javascript'>
        function abrirID_222(codUSU){
            var params = {'A_CODUSU' : codUSU};
            openLevel('lvl_admt55j', params);
           }
    </script>

    <!-- abrir nivel Salario Historico x Salario Atual -->
    <script type='text/javascript'>
        function abrirID_223(codUSU){
            var params = {'A_CODUSU' : codUSU};
            openLevel('lvl_admt599', params);
           }
    </script>

    <!-- abrir nivel Sem Linhas na TFPFER -->
    <script type='text/javascript'>
        function abrirID_224(codUSU){
            var params = {'A_CODUSU' : codUSU};
            openLevel('lvl_admt6du', params);
           }
    </script>

    <!-- abrir nivel Periodo de Ferias Negativo -->
    <script type='text/javascript'>
        function abrirID_225(codUSU){
            var params = {'A_CODUSU' : codUSU};
            openLevel('lvl_admt6hi', params);
           }
    </script>

    <!-- abrir Eventos Com Indice em Media como Decimais -->
    <script type='text/javascript'>
        function abrirID_226(codUSU){
            var params = {'A_CODUSU' : codUSU};
            openLevel('lvl_admt6j1', params);
           }
    </script>

    <!-- abrir nivel Acumulados que Estão Decimal -->
    <script type='text/javascript'>
        function abrirID_227(codUSU){
            var params = {'A_CODUSU' : codUSU};
            openLevel('lvl_admt6nv', params);
           }
    </script>

    <!-- abrir nivel Ocorrencias Sem Dt. Final Preenchida -->
    <script type='text/javascript'>
        function abrirID_228(codUSU){
            var params = {'A_CODUSU' : codUSU};
            openLevel('lvl_admt6qi', params);
           }
    </script>

</head>
<body>
     
    <snk:query var="contadores">          
        WITH ALL_SELECTS AS (
            -- 1. TOTAL XML PROCESSADO ESOCIAL
            SELECT 
                1 AS ORDEM,
                'Total XML Processado Esocial' AS TIPO,
                TO_CHAR(COUNT(*), 'FM999G999G990') AS RESULTADO
            FROM TTKEVT 
            WHERE TIPO='ESOCIAL' AND STATUS='F'
            
            UNION ALL
            
            -- 2. RUBRICAS PROCESSADAS
            SELECT 
                2 AS ORDEM,
                'Rubricas Processadas' AS TIPO,
                TO_CHAR(COUNT(*), 'FM999G999G990') AS RESULTADO
            FROM TTKEVT 
            WHERE TIPO='ESOCIAL' AND STATUS='F' AND NOMEARQUIVO LIKE '%s1010%'
            
            UNION ALL
            
            -- 3. COLABORADORES PROCESSADOS
            SELECT 
                3 AS ORDEM,
                'Colaboradores Processados' AS TIPO,
                TO_CHAR(COUNT(*), 'FM999G999G990') AS RESULTADO
            FROM TTKEVT 
            WHERE TIPO='ESOCIAL' AND STATUS='F' AND NOMEARQUIVO LIKE '%s2200%'
            
            UNION ALL
            
            -- 4. COLABORADORES SEM VINCULOS PROCESSADOS
            SELECT 
                4 AS ORDEM,
                'Colaboradores Sem Vínculos Processados' AS TIPO,
                TO_CHAR(COUNT(*), 'FM999G999G990') AS RESULTADO
            FROM TTKEVT 
            WHERE TIPO='ESOCIAL' AND STATUS='F' AND NOMEARQUIVO LIKE '%s2300%'
            
            UNION ALL
            
            -- 5. ACIDENTE DO TRABALHO PROCESSADO
            SELECT 
                5 AS ORDEM,
                'Acidente Do Trabalho Processado' AS TIPO,
                TO_CHAR(COUNT(*), 'FM999G999G990') AS RESULTADO
            FROM TTKEVT 
            WHERE TIPO='ESOCIAL' AND STATUS='F' AND NOMEARQUIVO LIKE '%s2210%'
            
            UNION ALL
            
            -- 6. ASOS PROCESSADOS
            SELECT 
                6 AS ORDEM,
                'ASOS Processados' AS TIPO,
                TO_CHAR(COUNT(*), 'FM999G999G990') AS RESULTADO
            FROM TTKEVT 
            WHERE TIPO='ESOCIAL' AND STATUS='F' AND NOMEARQUIVO LIKE '%s2220%'
            
            UNION ALL
            
            -- 7. EXAMES TOXICOLOGICOS
            SELECT 
                7 AS ORDEM,
                'Exames Toxicologicos' AS TIPO,
                TO_CHAR(COUNT(*), 'FM999G999G990') AS RESULTADO
            FROM TTKEVT 
            WHERE TIPO='ESOCIAL' AND STATUS='F' AND NOMEARQUIVO LIKE '%s2221%'
            
            UNION ALL
            
            -- 8. AFASTAMENTOS PROCESSADOS
            SELECT 
                8 AS ORDEM,
                'Afastamentos Processados' AS TIPO,
                TO_CHAR(COUNT(*), 'FM999G999G990') AS RESULTADO
            FROM TTKEVT 
            WHERE TIPO='ESOCIAL' AND STATUS='F' AND NOMEARQUIVO LIKE '%s2230%'
            
            UNION ALL
            
            -- 9. AMBIENTES PROCESSADOS
            SELECT 
                9 AS ORDEM,
                'Ambientes Processados' AS TIPO,
                TO_CHAR(COUNT(*), 'FM999G999G990') AS RESULTADO
            FROM TTKEVT 
            WHERE TIPO='ESOCIAL' AND STATUS='F' AND NOMEARQUIVO LIKE '%s2240%'
            
            UNION ALL
            
            -- 10. REMUNERAÇÃO PROCESSADA
            SELECT 
                10 AS ORDEM,
                'Remuneração Processada' AS TIPO,
                TO_CHAR(COUNT(*), 'FM999G999G990') AS RESULTADO
            FROM TTKEVT 
            WHERE TIPO='ESOCIAL' AND STATUS='F' AND NOMEARQUIVO LIKE '%s1200%'
            
            UNION ALL
            
            -- 11. PAGAMENTO PROCESSADOS
            SELECT 
                11 AS ORDEM,
                'Pagamento Processados' AS TIPO,
                TO_CHAR(COUNT(*), 'FM999G999G990') AS RESULTADO
            FROM TTKEVT 
            WHERE TIPO='ESOCIAL' AND STATUS='F' AND NOMEARQUIVO LIKE '%s1210%'
            
            UNION ALL
            
            -- 12. REINTEGRAÇÃO PROCESSADAS
            SELECT 
                12 AS ORDEM,
                'Reintegração Processadas' AS TIPO,
                TO_CHAR(COUNT(*), 'FM999G999G990') AS RESULTADO
            FROM TTKEVT 
            WHERE TIPO='ESOCIAL' AND STATUS='F' AND NOMEARQUIVO LIKE '%s2298%'
            
            UNION ALL
            
            -- 13. RESCISÃO PROCESSADAS
            SELECT 
                13 AS ORDEM,
                'Rescisão Processadas' AS TIPO,
                TO_CHAR(COUNT(*), 'FM999G999G990') AS RESULTADO
            FROM TTKEVT 
            WHERE TIPO='ESOCIAL' AND STATUS='F' AND NOMEARQUIVO LIKE '%s2299%'
            
            UNION ALL
            
            -- 14. QUANTIDADE DE FUNCIONARIOS ATIVOS
            SELECT 
                14 AS ORDEM,
                'Quantidade De Funcionários Ativos' AS TIPO,
                TO_CHAR(COUNT(*), 'FM999G999G990') AS RESULTADO
            FROM TFPFUN 
            WHERE SITUACAO=1
            
            UNION ALL
            
            -- 15. QUANTIDADE DE FUNCIONARIOS AFASTADOS
            SELECT 
                15 AS ORDEM,
                'Quantidade De Funcionários Afastados' AS TIPO,
                TO_CHAR(COUNT(*), 'FM999G999G990') AS RESULTADO
            FROM TFPFUN 
            WHERE SITUACAO NOT IN (1,8,0)
            
            UNION ALL
            
            -- 16. ERROS S2200
            SELECT 
                16 AS ORDEM,
                'Erros S2200' AS TIPO,
                TO_CHAR(COUNT(*), 'FM999G999G990') AS RESULTADO
            FROM TTKEVT 
            WHERE TIPO='ESOCIAL' AND STATUS='E' AND NOMEARQUIVO LIKE '%s2200%'
            
            UNION ALL
            
            -- 17. DEPENDENTE DUPLICADOS
            SELECT 
                17 AS ORDEM,
                'Dependente Duplicados' AS TIPO,
                TO_CHAR(COUNT(*), 'FM999G999G990') AS RESULTADO
            FROM (
                SELECT 
                    F.CODEMP, 
                    F.CODFUNC, 
                    F.NOMEFUNC AS NOME_FUNCIONARIO,
                    F.CPF AS CPF_FUNCIONARIO,
                    D.NOMEDEPEND AS NOME_DEPENDENTE,
                    D.CPF AS CPF_DEPENDENTE,
                    F.DTADM, 
                    F.SITUACAO, 
                    F.MATRICULA,
                    D.DTNASC AS DT_NASC_DEPENDENTE
                FROM TFPFUN F
                INNER JOIN TFPDPD D ON F.CODEMP = D.CODEMP AND F.CODFUNC = D.CODFUNC
                WHERE (D.CODEMP, D.CODFUNC, D.CPF) IN (
                    SELECT DX.CODEMP, DX.CODFUNC, DX.CPF
                    FROM TFPDPD DX
                    GROUP BY DX.CODEMP, DX.CODFUNC, DX.CPF
                    HAVING COUNT(*) > 1
                )
            )
            
            UNION ALL
            
            -- 18. DEPENDENTE SEM CPF
            SELECT 
                18 AS ORDEM,
                'Dependente Sem CPF' AS TIPO,
                TO_CHAR(COUNT(*), 'FM999G999G990') AS RESULTADO
            FROM (
                SELECT 
                    F.CODEMP, 
                    F.CODFUNC, 
                    F.NOMEFUNC, 
                    F.CPF AS CPF_FUNCIONARIO,
                    F.SITUACAO,
                    D.SEQUENCIA,
                    D.NOMEDEPEND, 
                    D.DEPENDIRF, 
                    D.DTNASC AS DT_NASC_DEPENDENTE,
                    D.CPF AS CPF_DEPENDENTE
                FROM TFPDPD D
                INNER JOIN TFPFUN F ON D.CODEMP = F.CODEMP AND D.CODFUNC = F.CODFUNC
                WHERE F.SITUACAO IN (1, 5, 6)
                  AND (D.CPF IS NULL OR D.CPF = '' OR D.CPF = '00000000000')
            )
            
            UNION ALL
            
            -- 19. FUNCIONARIOS DUPLICADOS
            SELECT 
                19 AS ORDEM,
                'Funcionários Duplicados' AS TIPO,
                TO_CHAR(COUNT(*), 'FM999G999G990') AS RESULTADO
            FROM TFPFUN
            WHERE CPF IN (
                SELECT CPF 
                FROM TFPFUN 
                WHERE SITUACAO = 1
                GROUP BY CPF 
                HAVING COUNT(CPF) > 1
            )
            AND SITUACAO IN (1,5,6)
            
            UNION ALL
            
            -- 20. FUNCIONARIOS DUPLICADOS QUE NÃO TEM FOLHA
            SELECT 
                20 AS ORDEM,
                'Funcionários Duplicados Que Não Tem Folha' AS TIPO,
                TO_CHAR(COUNT(*), 'FM999G999G990') AS RESULTADO
            FROM (
                SELECT 
                    F.CODEMP, 
                    F.CODFUNC, 
                    F.NOMEFUNC, 
                    F.CPF,
                    F.VINCULO,
                    F.MATRICULA,
                    F.SITUACAO,
                    F.DTADM,
                    F.DTDEM
                FROM TFPFUN F
                LEFT JOIN TFPFOL L ON F.CODEMP = L.CODEMP AND F.CODFUNC = L.CODFUNC
                WHERE F.CPF IN (
                    SELECT CPF 
                    FROM TFPFUN 
                    WHERE SITUACAO = 1
                    GROUP BY CPF 
                    HAVING COUNT(CPF) > 1
                )
                AND F.SITUACAO IN (1, 5, 6)
                AND L.CODFUNC IS NULL
            )
            
            UNION ALL
            
            -- 21. VINCULO VAZIO
            SELECT 
                21 AS ORDEM,
                'Vínculo Vazio' AS TIPO,
                TO_CHAR(COUNT(*), 'FM999G999G990') AS RESULTADO
            FROM TFPFUN 
            WHERE VINCULO IS NULL AND SITUACAO IN (1,5,6)
            
            UNION ALL
            
            -- 22. SALARIO BASE VAZIO
            SELECT 
                22 AS ORDEM,
                'Salário Base Vazio' AS TIPO,
                TO_CHAR(COUNT(*), 'FM999G999G990') AS RESULTADO
            FROM TFPFUN 
            WHERE SALBASE IS NULL AND SITUACAO IN (1,5,6)
            
            UNION ALL
            
            -- 23. SALARIO HISTORICO x SALARIO ATUAL
            SELECT 
                23 AS ORDEM,
                'Salário Historico X Salário Atual' AS TIPO,
                TO_CHAR(COUNT(*), 'FM999G999G990') AS RESULTADO
            FROM (
                SELECT 
                    F.CODEMP, 
                    F.CODFUNC, 
                    F.NOMEFUNC, 
                    F.CPF,
                    F.SALBASE AS SALARIO_CADASTRO, 
                    B.SALBASE AS SALARIO_HISTORICO,
                    B.REFERENCIA AS ULTIMA_REF_HISTORICO,
                    (F.SALBASE - B.SALBASE) AS DIFERENCA
                FROM TFPFUN F
                INNER JOIN TFPBAS B ON F.CODEMP = B.CODEMP AND F.CODFUNC = B.CODFUNC
                WHERE B.REFERENCIA = (
                    SELECT MAX(REFERENCIA) 
                    FROM TFPBAS 
                    WHERE CODEMP = F.CODEMP AND CODFUNC = F.CODFUNC
                )
                AND F.SALBASE <> B.SALBASE
            )
            
            UNION ALL
            
            -- 24. NÃO TEM NENHUMA LINHA NA TFPFER
            SELECT 
                24 AS ORDEM,
                'Sem Linhas Na TFPFER' AS TIPO,
                TO_CHAR(COUNT(*), 'FM999G999G990') AS RESULTADO
            FROM TFPFUN F
            WHERE F.SITUACAO = 1
            AND NOT EXISTS (
                SELECT 1 
                FROM TFPFER E 
                WHERE E.CODEMP = F.CODEMP 
                AND E.CODFUNC = F.CODFUNC 
                AND E.DTSAIDA IS NULL
            )
            
            UNION ALL
            
            -- 25. PERIODO DE FERIAS NEGATIVO
            SELECT 
                25 AS ORDEM,
                'Período De Férias Negativo' AS TIPO,
                TO_CHAR(COUNT(*), 'FM999G999G990') AS RESULTADO
            FROM TFPFER 
            WHERE NUMDIASFER <= 0
            
            UNION ALL
            
            -- 26. EVENTOS QUE INDICE EM MÉDIA ESTÃO COMO DECIMAL
            SELECT 
                26 AS ORDEM,
                'Eventos Que Indice Em Média Estão Como Decimal' AS TIPO,
                TO_CHAR(COUNT(*), 'FM999G999G990') AS RESULTADO
            FROM (
                SELECT 
                    F.CODEMP, 
                    F.CODFUNC, 
                    F.TIPFOLHA,
                    F.REFERENCIA, 
                    F.CODEVENTO, 
                    E.DESCREVENTO,
                    E.INCSOBREMEDIAS,
                    F.SEQUENCIA, 
                    F.VLREVENTO, 
                    F.INDICE,
                    F.INDICE AS ORIGINAL_DECIMAL,
                    FLOOR(F.INDICE) + ((F.INDICE - FLOOR(F.INDICE)) * 0.60) AS SIMULACAO_SEXAGESIMAL
                FROM TFPFOL F
                INNER JOIN TFPEVE E ON F.CODEVENTO = E.CODEVENTO
                WHERE (F.INDICE - FLOOR(F.INDICE)) >= 0.60
                  AND E.INCSOBREMEDIAS = 'I'
            )
            
            UNION ALL
            
            -- 27. PARA IDENTIFICAR ACUMULADOS QUE ESTÃO DECIMAL
            SELECT 
                27 AS ORDEM,
                'Acumulados Que Estão Decimal' AS TIPO,
                TO_CHAR(COUNT(*), 'FM999G999G990') AS RESULTADO
            FROM (
                SELECT 
                    A.CODEMP, 
                    A.CODFUNC, 
                    A.CODEVENTO, 
                    E.DESCREVENTO,
                    E.INCSOBREMEDIAS,
                    A.SEQUENCIA, 
                    A.ANO, 
                    A.INDJANEIRO, 
                    A.INDFEVEREIRO, 
                    A.INDMARCO, 
                    A.INDABRIL, 
                    A.INDMAIO, 
                    A.INDJUNHO, 
                    A.INDJULHO, 
                    A.INDAGOSTO, 
                    A.INDSETEMBRO, 
                    A.INDOUTUBRO, 
                    A.INDNOVEMBRO, 
                    A.INDDEZEMBRO
                FROM TFPACU A
                INNER JOIN TFPEVE E ON A.CODEVENTO = E.CODEVENTO
                WHERE E.INCSOBREMEDIAS = 'I'
                  AND (
                       (A.INDJANEIRO   - FLOOR(A.INDJANEIRO))   >= 0.60 OR
                       (A.INDFEVEREIRO - FLOOR(A.INDFEVEREIRO)) >= 0.60 OR
                       (A.INDMARCO     - FLOOR(A.INDMARCO))     >= 0.60 OR
                       (A.INDABRIL     - FLOOR(A.INDABRIL))     >= 0.60 OR
                       (A.INDMAIO      - FLOOR(A.INDMAIO))      >= 0.60 OR
                       (A.INDJUNHO     - FLOOR(A.INDJUNHO))     >= 0.60 OR
                       (A.INDJULHO     - FLOOR(A.INDJULHO))     >= 0.60 OR
                       (A.INDAGOSTO    - FLOOR(A.INDAGOSTO))    >= 0.60 OR
                       (A.INDSETEMBRO  - FLOOR(A.INDSETEMBRO))  >= 0.60 OR
                       (A.INDOUTUBRO   - FLOOR(A.INDOUTUBRO))   >= 0.60 OR
                       (A.INDNOVEMBRO  - FLOOR(A.INDNOVEMBRO))  >= 0.60 OR
                       (A.INDDEZEMBRO  - FLOOR(A.INDDEZEMBRO))  >= 0.60
                  )
            )
            
            UNION ALL
            
            -- 28. OCO SEM DTFINALOCOR PREENCHIDA
            SELECT 
                28 AS ORDEM,
                'Ocorrências Sem Dt. Final Preenchida' AS TIPO,
                TO_CHAR(COUNT(*), 'FM999G999G990') AS RESULTADO
            FROM (
                SELECT 
                    O.CODEMP,
                    O.CODFUNC,
                    O.NUOCOR,
                    O.CODHISTOCOR,
                    H.DESCRHISTOCOR,
                    O.DESCROCOR,
                    O.DTINICOCOR,
                    O.DTFINALOCOR
                FROM TFPOCO O
                INNER JOIN TFPHIS H ON O.CODHISTOCOR = H.CODHISTOCOR
                WHERE O.DTFINALOCOR IS NULL
            )
        )
        SELECT 
            (200 + ORDEM) AS ID,
            TIPO,
            RESULTADO
        FROM ALL_SELECTS
        ORDER BY ORDEM
    </snk:query>

    <div class="container">
        <header class="dashboard-header">
            <h1><i class="fas fa-rocket"></i> Volumetria Deploy Agent - Folha</h1>
            <div class="header-controls">
                <a href="https://www.sankhya.com.br" target="_blank">
                    <img src="${BASE_FOLDER}img/logo_sankhya.svg" height="36" width="167"></img>
                </a>
            </div>
        </header>

        <main class="dashboard">
            <div class="card-grid">

                <c:forEach items="${contadores.rows}" var="row">
                    <div class="card" data-category="primary" onclick="javascript:abrirID_${row.ID}( ${CODUSU_LOG} )">
                        <div class="card-content">
                            <h3><c:out value="${row.TIPO}" /></h3>
                            <p><c:out value="${row.TIPO2}" /></p>
                        </div>
                        <div class="counter" data-count="1,247">
                            <span class="count-number"><c:out value="${row.RESULTADO}" /></span>
                            <span class="count-label">registros</span>
                        </div>
                    </div>
                </c:forEach>

            </div>
        </main>

    </div>

</body>
</html>